import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import time

from vm_utils import run_command, run_commands


def ping_test(blueprint, netns_list):
    for router in blueprint["routers"]:
        idx = router["idx"]

        for neighbor in router["neighbors"]:
            dest_ip = neighbor['neighbor_ip']
            cmd = f"ip netns exec {netns_list[idx-1]} ping -c 1 {dest_ip}"
            repeat_idx = 0
            
            while True:
                rec = run_command(cmd)

                if rec.rc == 0:
                    break

                repeat_idx += 1
                if repeat_idx == 20:
                    print(str(rec))

                time.sleep(0.5)

    print("ping test done")


def concurrent_run_command(cmds):
    with ThreadPoolExecutor() as executor:
        futures = [
            executor.submit(
                lambda c: run_commands(c),
                cmd
            )
            for cmd in cmds
        ]
        records = []
        for future in as_completed(futures):
            records += future.result()

        # records = []

        # for cmd in cmds:
        #     records += run_commands(cmd)

        return records


def set_ip_addr(blueprint, netns_list):
    all_commands = []
    for router in blueprint["routers"]:
        idx1 = router["idx"]
        netns1 = netns_list[idx1-1]

        commands = []
        for neighbor in router["neighbors"]:
            idx2 = neighbor["peeridx"]
            netns2 = netns_list[idx2-1]

            if idx1 > idx2:
                continue

            veth1_name = neighbor["ifname"]
            veth2_name = neighbor["peerifname"]

            port1 = neighbor["ifname"]
            port2 = neighbor["peerifname"]

            ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
            ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"

            commands += [
                f"ip netns exec {netns1} ip link set {veth1_name} name {port1}",
                f"ip netns exec {netns1} ip link set {port1} up",
                f"ip netns exec {netns1} ip addr add {ip1} dev {port1}",
                f"ip netns exec {netns2} ip link set {veth2_name} name {port2}",
                f"ip netns exec {netns2} ip link set {port2} up",
                f"ip netns exec {netns2} ip addr add {ip2} dev {port2}",
            ]
        all_commands.append(commands)

    records = concurrent_run_command(all_commands)

    for rec in records:
        if rec.rc != 0:
            print(str(rec))


def cleanup_link(blueprint, netns_list):
    for router in blueprint["routers"]:
        idx1 = router["idx"]
        for neighbor in router["neighbors"]:
            idx2 = neighbor["peeridx"]
            if idx1 > idx2:
                continue
            cmd = f'ip netns exec {netns_list[idx1-1]} ip link del {neighbor["ifname"]}'

            rec = run_command(cmd)

            if rec.rc != 0:
                print(str(rec))


if __name__ == "__main__":
    parser = argparse.ArgumentParser("test_fastlink")

    parser.add_argument("--topo", default="fattree2")
    parser.add_argument("--image", default="crpd")
    args = parser.parse_args()

    blueprint_path = f"conf/{args.image}/{args.topo}/blueprint.json"

    with open(blueprint_path) as f:
        blueprint = json.load(f)

    nnodes = len(blueprint["routers"])
    netns_list = []
    start = time.monotonic()
    for i in range(nnodes):
        ns_name = f"f-{i}"
        netns_list.append(ns_name)
        rec = run_command(f"ip netns add {ns_name}")
        if rec.rc != 0:
            print(str(rec))

    blueprint["netns"] = netns_list

    with open("/tmp/blueprint.json", "w") as f:
        json.dump(blueprint, f)

    rec = run_command(
        f"./docker_net_emulation/fastlink/fastlink /tmp/blueprint.json 1")
    end = time.monotonic()
    print("Total time:", end-start)
    print(str(rec))

    ping_test(blueprint, netns_list)
    ping_ts = time.monotonic()
    print("Ping time", ping_ts-start)

    try:

        time.sleep(1800)
    except BaseException as e:
        print("Catch ", e)
    cleanup_link(blueprint, netns_list)
    for netns in netns_list:
        run_command(f"ip netns del {netns}")
