#!/bin/bash
# Example: ./docker_scripts/run.sh --topo=fattree2 --image=frr --mode=baseline 
sudo bash -c 'source .venv/bin/activate; exec ./docker_emu/deploy.py "$@"' bash "$@"