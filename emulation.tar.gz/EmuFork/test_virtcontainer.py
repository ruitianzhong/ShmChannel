#!/bin/env python3
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import copy
from virtcontainer import QEMUTemplate, QEMUChild, QEMU_DEFAULT_CONFIG, TapManager
import time
from vm_utils import run_command


def test_qemu_basic_ops(test_config):
    template = QEMUTemplate(0, test_config["output_dir"], QEMU_DEFAULT_CONFIG)
    template.create()
    template.start()
    time.sleep(10)
    result = template.run_command_on_guest("echo hello world")
    assert result.rc == 0
    template.dump_log()
    input("Start ended\n")
    template.shutdown()
    template.dump_log()

    print("Done")


def test_qemu_start_multiple(test_config):
    num_vm = 100
    vm_list: list[QEMUTemplate] = []
    tap_manager = TapManager(num_vm, output_dir=test_config["output_dir"])
    tap_manager.init()
    base_config = QEMU_DEFAULT_CONFIG

    for idx in range(1, num_vm+1):
        modified_config = copy.deepcopy(base_config)
        mgmt_name, mgmt_host_ip, mgmt_guest_ip = tap_manager.get_tap_info(idx)

        modified_config["network_dev"] = mgmt_name
        base_disk_image_path = os.path.abspath(base_config["disk_image"])
        modified_config["disk_image"] = os.path.abspath(
            f'{test_config["output_dir"]}/vm_{idx}.qcow2')

        cmd = f'qemu-img create -f qcow2 -b {base_disk_image_path} -F qcow2 { modified_config["disk_image"]}'
        run_command(cmd)

        vm = QEMUTemplate(
            idx, test_config["output_dir"], modified_config, file_back_mem=True)
        vm.create()
        vm.start()
        vm.dump_log()
        vm_list.append(vm)

    input("All vms started")

    for vm in vm_list:
        vm.shutdown(graceful=False)

    tap_manager.cleanup()


def test_qemu_fork_ops(test_config: dict):
    template = QEMUTemplate(0, test_config["output_dir"], QEMU_DEFAULT_CONFIG)
    template.create()
    template.start()
    time.sleep(15)
    result = template.run_command_on_guest("echo hello world")
    template.copy_to_guest("./EmuFork/agent/server_qemu", "./")
    template.run_command_on_guest(
        "nohup ./server_qemu >/tmp/server.log 2>&1 &")
    template.dump_log()
    time.sleep(30)
    assert result.rc == 0
    print("Start ended")
    template.pause()
    template.snapshot()
    template.shutdown(graceful=False)
    template.dump_log()
    print("template saved")

    num_vm = 128
    tap_manager = TapManager(
        num_vm=num_vm, output_dir=test_config["output_dir"])
    # We must do it
    tap_manager.init()

    childs = []
    output_dir = test_config["output_dir"]

    parallel = test_config.get("parallel", False)

    fork_start = time.monotonic()

    if not parallel:
        for idx in range(1, num_vm+1):
            mgmt_name, mgmt_host_ip, mgmt_guest_ip = tap_manager.get_tap_info(
                idx)
            child = QEMUChild(idx, output_dir=output_dir, mgmt_name=mgmt_name,
                              guest_side_ip=mgmt_guest_ip, host_side_ip=mgmt_host_ip, template=template)
            childs.append(child)
            child.create()
            child.dump_log()
            child.start()

            child.run_command_on_guest("echo hello on forked vm")
            child.dump_log()

    else:
        futures = []
        records = []
        with ThreadPoolExecutor() as executor:
            for idx in range(1, num_vm+1):
                mgmt_name, mgmt_host_ip, mgmt_guest_ip = tap_manager.get_tap_info(
                    idx)
                child = QEMUChild(idx, output_dir=output_dir, mgmt_name=mgmt_name,
                                  guest_side_ip=mgmt_guest_ip, host_side_ip=mgmt_host_ip, template=template)
                childs.append(child)
                child.set_logging(False)
                futures.append(executor.submit(child.create_and_start))

        for future in as_completed(futures):
            result = future.result()
            records += result

        with open(f"{test_config['output_dir']}/fork.log", "w") as f:
            f.writelines(str(rec) for rec in records)

        for child in childs:
            child.set_logging(True)
            rec = child.run_command_on_guest("echo hello on forked vm")
            if rec.rc != 0:
                print(child.id(), "not ok")
            child.dump_log()
    fork_end = time.monotonic()
    print(f"fork time {fork_end-fork_start} s")

    input("child done\n")
    shutdown_start = time.monotonic()
    if not parallel:
        for child in childs:
            child: QEMUChild = child

            child.shutdown()

    else:
        futures = []
        with ThreadPoolExecutor() as executor:

            for child in childs:
                child: QEMUChild = child
                futures.append(executor.submit(
                    child.shutdown
                ))
        for future in as_completed(futures):
            future.result()

    tap_manager.cleanup()
    shutdown_end = time.monotonic()
    print(f"Shutdown time: {shutdown_end-shutdown_start} s")


if __name__ == "__main__":
    test_config = {"output_dir": "./test_emufork", "parallel": True}
    # test_qemu_basic_ops(test_config)
    test_qemu_fork_ops(test_config)
    # test_qemu_start_multiple(test_config)
