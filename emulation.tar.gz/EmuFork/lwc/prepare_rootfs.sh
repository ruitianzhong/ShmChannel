#!/bin/bash
set -euo pipefail

image_name=${1:-real-ubuntu}
echo "prepare ${image_name}"

if [ -d "$image_name" ];then
    echo remove ${image_name}
    rm -rf ${image_name}
fi

rootfs_dir="${image_name}/rootfs"
mkdir -p ${rootfs_dir} && (cd "$image_name" && runc spec)
docker export $( docker create "$image_name") | tar -C "$rootfs_dir" -xf -
docker save -o ${image_name}.tar ${image_name}


if [ "${image_name}" == "real-crpd" ];then
    echo "copy license"
    cp crpd-license ${rootfs_dir}/crpd-license
fi

mkdir -p ${image_name}/meta

tar xf ${image_name}.tar -C ${image_name}/meta

create_json_file=$(jq -r '.[0].Config' ${image_name}/meta/manifest.json)

cp ${image_name}/meta/${create_json_file} ${image_name}/create.json


rm ${image_name}.tar ${image_name}/meta -rf

echo "Done!"






