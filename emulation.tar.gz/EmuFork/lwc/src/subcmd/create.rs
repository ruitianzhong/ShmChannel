use nix::mount::{mount, MsFlags};
use serde_json::Value;
use std::fs::{self};
use std::io::{self};
use std::path::Path;
use std::process::Command;

use crate::common::config::{Config, BASE_PATH};
use crate::common::utils::flush_config;

fn setup_overlayfs(layers_dir: Vec<String>, rootfs_dir: &str) -> io::Result<String> {
    if Path::new(rootfs_dir).exists() {
        fs::remove_dir_all(rootfs_dir)?;
    }
    fs::create_dir_all(rootfs_dir)?;

    // Create work directories for overlay
    let overlay_workdir = format!("{}/overlay-work", rootfs_dir);
    let overlay_upperdir = format!("{}/overlay-upper", rootfs_dir);
    fs::create_dir_all(&overlay_workdir)?;
    fs::create_dir_all(&overlay_upperdir)?;

    let lowerdirs_str = layers_dir.join(":");
    let overlay_dir = format!("{}/rootfs", rootfs_dir);
    fs::create_dir_all(&overlay_dir)?;

    // Create overlay filesystem using OverlayFS
    Command::new("mount")
        .arg("--make-private")
        .arg("-t")
        .arg("overlay")
        .arg("overlay")
        .arg("-o")
        .arg(format!(
            "lowerdir={},upperdir={},workdir={}",
            lowerdirs_str, overlay_upperdir, overlay_workdir
        ))
        .arg(&overlay_dir)
        .status()
        .expect("Failed to mount overlayfs");

    Ok(overlay_dir)
}

fn setup_volume(volume_str: &str, rootfs_dir: &str) -> io::Result<()> {
    let str_list: Vec<&str> = volume_str.split(':').collect();
    if str_list.len() != 2 {
        println!("Invalid volume string");
        return Ok(());
    }

    let host_path = format!("{}/{}/{}", BASE_PATH, "volumes", &str_list[0]);
    let volume_dir = format!("{}/{}", rootfs_dir, &str_list[1][1..]);
    fs::create_dir_all(&host_path)?;
    fs::create_dir_all(&volume_dir)?;

    Command::new("mount")
        .arg("--bind")
        .arg(host_path)
        .arg(&volume_dir)
        .status()
        .expect("Failed to mount volume");

    Ok(())
}

fn setup_shm(rootfs_dir: &str) -> io::Result<()> {
    let host_path = "/dev/shm";
    let dev_dir = format!("{}/dev", rootfs_dir);
    fs::create_dir_all(&dev_dir)?;

    mount(
        Some("tmpfs"),
        dev_dir.as_str(),
        Some("tmpfs"),
        MsFlags::MS_NOEXEC | MsFlags::MS_NOSUID,
        None::<&str>,
    )?;

    let shm_dir = format!("{}/dev/shm", rootfs_dir);
    fs::create_dir_all(&shm_dir)?;
    Command::new("mount")
        .arg("--bind")
        .arg(host_path)
        .arg(&shm_dir)
        .status()
        .expect("Failed to mount shm");

    Ok(())
}
//  /crpd/create.json
// /crpd/rootfs
// /ubuntu/create.json
// ubuntu/rootfs

pub fn create_main(
    image_name: &str,
    container_name: &str,
    volumes: Vec<String>,
    cpuset: Option<String>,
) -> Result<(), Box<dyn std::error::Error>> {
    // let manifest = extract_manifest(image_name)?;

    let layer_dir_list = vec![format!("/{}/rootfs", image_name)];

    // Setup overlayfs
    println!("{:?}", layer_dir_list);
    let rootfs_dir = setup_overlayfs(
        layer_dir_list,
        &format!("{}/containers/{}", BASE_PATH, container_name),
    )?;

    println!("{}", rootfs_dir);

    // Setup volume if provided
    for volume in &volumes {
        setup_volume(&volume, &rootfs_dir)?;
    }

    setup_shm(&rootfs_dir)?;

    let config_file = format!("/{}/{}", image_name, "create.json");
    if !Path::new(&config_file).is_file() {
        println!("Config file not found: {}", config_file);
        return Err(Box::new(io::Error::new(
            io::ErrorKind::NotFound,
            "Config file not found",
        )));
    }

    let config_content = fs::read_to_string(config_file)?;
    let image_config: Value = serde_json::from_str(&config_content)?;

    let container_config = Config {
        state: Some("created".to_string()),
        exitcode: None,
        env: Some(
            image_config["config"]
                .get("Env")
                .unwrap() // Environment Variable
                .as_array()
                .unwrap() // Decode as array
                .iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect(),
        ),
        cpuset: cpuset,
        pid: None,
        volumes: Some(volumes),
    };
    let config_str = serde_json::to_string(&container_config)?;
    let container_dir = format!("{}/containers/{}/", BASE_PATH, container_name);
    flush_config(&container_dir, config_str)?;

    Ok(())
}
