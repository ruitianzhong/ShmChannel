#!/bin/bash
set -e 
IMAGE_NAME="rust:slim"
PROJECT_DIR=$(pwd)
BUILD_MODE=${1:-debug}  # 默认调试模式，传 release 则为发布模式
netns="${NETNS:-disable}"


echo "=== 开始构建 Rust 项目（模式：$BUILD_MODE）==="
docker run --rm \
  -v "$PROJECT_DIR":/app \
  $IMAGE_NAME \
  bash -c "cd /app && netns=${netns} cargo build $( [ "$BUILD_MODE" = "release" ] && echo "--release" )"

echo "=== 构建完成！产物路径：$PROJECT_DIR/target/$BUILD_MODE ==="