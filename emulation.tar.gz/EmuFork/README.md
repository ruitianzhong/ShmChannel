

# EmuFork

## Install Dependency

## Reference

* https://wiki.qemu.org/Documentation/Networking
* https://wiki.qemu.org/Documentation/CreateSnapshot
* https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/fs.md
* https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/memory.md
* https://www.kernel.org/doc/html/v4.19/admin-guide/mm/ksm.html
* https://github.com/cloud-hypervisor/cloud-hypervisor/blob/main/docs/virtiofs-root.md