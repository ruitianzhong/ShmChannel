#!/usr/bin/env python3
"""
Topology configuration parser for router network topology.

Supports JSON and YAML file formats.
Expected format:
{
    "routers": [
        {
            "name": "node1",
            "peers": [
                {
                    "name": "node2",
                    "peer_interface": "eth0",
                    "self_interface": "eth1"
                }
            ]
        }
    ]
}
"""

import json
from typing import Dict, Any
import os
import sys

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False


class TopologyParseError(Exception):
    """Raised when topology file parsing fails."""
    pass


class TopologyValidationError(Exception):
    """Raised when topology data structure is invalid."""
    pass


def parse_topology(file_path: str) -> Dict[str, Any]:
    """
    Parse a topology configuration file (JSON or YAML).

    Args:
        file_path: Path to the topology configuration file.

    Returns:
        Dictionary containing parsed topology data.

    Raises:
        FileNotFoundError: If the file does not exist.
        TopologyParseError: If the file cannot be parsed as JSON or YAML.
        TopologyValidationError: If the topology data structure is invalid.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Topology file not found: {file_path}")

    with open(file_path, 'r') as f:
        content = f.read()

    # Try to parse as JSON first
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        # If JSON fails and YAML is available, try YAML
        if HAS_YAML:
            try:
                data = yaml.safe_load(content)
            except yaml.YAMLError as e:
                raise TopologyParseError(
                    f"Failed to parse file as JSON or YAML: {e}"
                )
        else:
            raise TopologyParseError(
                "Failed to parse as JSON and YAML support is not available. "
                "Install PyYAML (pip install pyyaml) for YAML support."
            )

    # Validate the topology structure
    validate_topology(data)

    return data


def validate_topology(data: Dict[str, Any]) -> None:
    """
    Validate the topology data structure.

    Args:
        data: Parsed topology data.

    Raises:
        TopologyValidationError: If the topology data structure is invalid.
    """
    if not isinstance(data, dict):
        raise TopologyValidationError(
            f"Topology data must be a dictionary, got {type(data).__name__}"
        )

    if 'routers' not in data:
        raise TopologyValidationError(
            "Topology data must contain a 'routers' key"
        )

    routers = data['routers']
    if not isinstance(routers, list):
        raise TopologyValidationError(
            f"'routers' must be a list, got {type(routers).__name__}"
        )

    # Check for duplicate router names
    router_names = set()
    duplicate_names = []

    # Dictionary to store all connections for symmetry validation
    # Key: (from_router, from_interface), Value: (to_router, to_interface)
    connections = {}

    for i, router in enumerate(routers):
        if not isinstance(router, dict):
            raise TopologyValidationError(
                f"Router at index {i} must be a dictionary, "
                f"got {type(router).__name__}"
            )

        if 'name' not in router:
            raise TopologyValidationError(
                f"Router at index {i} must have a 'name' field"
            )

        if not isinstance(router['name'], str):
            raise TopologyValidationError(
                f"Router name at index {i} must be a string, "
                f"got {type(router['name']).__name__}"
            )

        # Check for duplicate router names
        router_name = router['name']
        if router_name in router_names:
            duplicate_names.append(router_name)
        else:
            router_names.add(router_name)

        # Peers is optional
        if 'peers' in router:
            peers = router['peers']
            if not isinstance(peers, list):
                raise TopologyValidationError(
                    f"Peers for router '{router_name}' must be a list, "
                    f"got {type(peers).__name__}"
                )

            # Check for duplicate self_interfaces within the same router
            self_interfaces = set()
            duplicate_interfaces = []

            for j, peer in enumerate(peers):
                if not isinstance(peer, dict):
                    raise TopologyValidationError(
                        f"Peer at index {j} for router '{router_name}' "
                        f"must be a dictionary, got {type(peer).__name__}"
                    )

                required_fields = ['name', 'peer_interface', 'self_interface']
                for field in required_fields:
                    if field not in peer:
                        raise TopologyValidationError(
                            f"Peer at index {j} for router '{router_name}' "
                            f"must have a '{field}' field"
                        )

                    if not isinstance(peer[field], str):
                        raise TopologyValidationError(
                            f"Field '{field}' for peer at index {j} "
                            f"for router '{router_name}' must be a string, "
                            f"got {type(peer[field]).__name__}"
                        )

                # Check for duplicate self_interface within this router
                self_interface = peer['self_interface']
                if self_interface in self_interfaces:
                    duplicate_interfaces.append(self_interface)
                else:
                    self_interfaces.add(self_interface)

                # Store connection for symmetry validation
                from_router = router_name
                from_interface = self_interface
                to_router = peer['name']
                to_interface = peer['peer_interface']

                connections[(from_router, from_interface)] = (
                    to_router, to_interface)

            if duplicate_interfaces:
                raise TopologyValidationError(
                    f"Router '{router_name}' has duplicate self_interface(s): "
                    f"{', '.join(set(duplicate_interfaces))}. "
                    f"Each interface can only connect to one peer."
                )

    # Check for duplicate router names
    if duplicate_names:
        raise TopologyValidationError(
            f"Duplicate router name(s) found: {', '.join(set(duplicate_names))}. "
            f"Router names must be unique."
        )

    # Validate connection symmetry
    missing_connections = []
    for (from_router, from_interface), (to_router, to_interface) in connections.items():
        # Check if reverse connection exists
        reverse_key = (to_router, to_interface)
        if reverse_key not in connections:
            missing_connections.append(
                f"Missing reverse connection: {from_router}:{from_interface} -> "
                f"{to_router}:{to_interface} exists, but "
                f"{to_router}:{to_interface} -> {from_router}:{from_interface} is missing"
            )
        else:
            # Check if reverse connection points back correctly
            reverse_to_router, reverse_to_interface = connections[reverse_key]
            if reverse_to_router != from_router or reverse_to_interface != from_interface:
                missing_connections.append(
                    f"Incorrect reverse connection: {from_router}:{from_interface} -> "
                    f"{to_router}:{to_interface}, but {to_router}:{to_interface} -> "
                    f"{reverse_to_router}:{reverse_to_interface} (expected -> {from_router}:{from_interface})"
                )

    if missing_connections:
        raise TopologyValidationError(
            "Connection symmetry validation failed:\n" +
            "\n".join(f"  • {msg}" for msg in missing_connections)
        )


def load_topology(file_path: str) -> Dict[str, Any]:
    """
    Alias for parse_topology for backward compatibility.
    """
    return parse_topology(file_path)


if __name__ == '__main__':
    # Simple command-line interface for testing
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <topology_file>")
        sys.exit(1)

    try:
        topology = parse_topology(sys.argv[1])
        print("Successfully parsed topology:")
        print(json.dumps(topology, indent=2))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
