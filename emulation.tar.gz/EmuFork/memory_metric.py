import json
import subprocess

from vm_utils import run_command
import re
from multiprocessing import Event, Queue, Process
import time


class MemoryMonitor:
    def __init__(self, result_dir):
        pass
        self.records = []
        self.result_dir = result_dir
        self.used_mem_pattern = re.compile(r"Mem:\s+\d+\w+\s+([\d\.]+)(\w+)")
        self.used_mem_data = []
        self.timestamp = []

    def collect(self) -> float:
        cmd = "free -h"

        record = run_command(cmd)

        self.records.append(record)
        res = self._parse_memory_metric(record.stdout)
        self.used_mem_data.append(res)
        self.timestamp.append(time.monotonic())

        return res

    def __str__(self):
        res = "Data: "
        for used in self.used_mem_data:
            res += str(used)+"GiB "
        return res

    def _parse_memory_metric(self, output: str):

        lines = output.split("\n")
        for line in lines:
            used_mem = self.used_mem_pattern.search(line)

            if used_mem:
                used_val, used_unit = used_mem.groups()
                factor = {"Gi": 1024, "Mi": 1, "Ti": 1024 * 1024}
                used = float(used_val)*factor.get(used_unit, 1)/1024
                return used

        raise RuntimeError

    def dump_log(self):
        with open(f"{self.result_dir}/mem.log", "w") as f:
            f.writelines([str(rec) for rec in self.records])

    def get_mem_usage(self):
        return self.used_mem_data


def collect_mem_data(result_dir, interval: int, event, queue: Queue):
    monitor = MemoryMonitor(result_dir)
    while not event.is_set():
        monitor.collect()
        time.sleep(interval)

    monitor.dump_log()
    queue.put((monitor.timestamp, monitor.used_mem_data))


class MemoryUsageCollector:
    def __init__(self, result_dir, interval_sec):
        self.interval = interval_sec
        self.result_dir = result_dir
        self.process = None
        self.queue = None
        self.event = None
        self.is_end = False

    def start(self):
        ev = Event()
        q = Queue()
        ev.is_set()
        p = Process(target=collect_mem_data, args=[
                    self.result_dir, self.interval, ev, q])

        p.start()
        self.process = p
        self.queue = q
        self.event = ev

    def end(self):
        if self.is_end:
            return
        self.is_end = True
        self.event.set()

        timestamp, mem_used = self.queue.get()

        self.process.join()

        with open(f"{self.result_dir}/mem_used.log", "w") as f:
            results = [f"{t}: {m} GiB\n" for t, m in zip(timestamp, mem_used)]
            f.writelines(results)

        return timestamp, mem_used


class DirtyMemoryProfiler:
    def __init__(self, interval_sec, result_dir):
        self.result_dir = result_dir
        self.ev = Event()
        self.proc = None
        self.interval_sec = interval_sec

    def get_pid_pmap_stat(self, pid):
        rec = run_command(f"pmap -X {pid}")
        assert rec.rc == 0
        result = {}
        lines = rec.stdout.splitlines()

        for line in lines:
            if "mem_file" in line:
                found = True
                fields = re.split(r'\s+', line)
                rss = int(fields[7])
                pss = int(fields[8])

                anon = int(fields[10])
                result = {"rss": rss/1024, "pss": pss/1024, "anon": anon/1024}
                return result
        assert False

    def get_vm_pids(self):
        output = subprocess.check_output(
            ["ps", "-ef"],
            encoding="utf-8",
            stderr=subprocess.STDOUT
        )

        filtered_lines = []
        for line in output.splitlines():
            line_stripped = line.strip()
            if not line_stripped:
                continue

            has_firecracker = "firecracker --enable-pci" in line_stripped
            no_vm0 = "vm_0" not in line_stripped
            no_grep = "grep" not in line_stripped

            if has_firecracker and no_vm0 and no_grep and "vm_1.sock" in line_stripped:
                filtered_lines.append(line_stripped)

        pid_list = []
        for line in filtered_lines:

            fields = re.split(r'\s+', line)
            if len(fields) >= 2:
                pid = int(fields[1])
                pid_list.append(pid)

        return pid_list

    def collect(self):
        pids = self.get_vm_pids()
        pid = pids[0]
        time_ts = []
        results = []
        ts = 0
        while not self.ev.is_set():

            time.sleep(self.interval_sec)
            ts += self.interval_sec
            results.append(self.get_pid_pmap_stat(pid))
            time_ts.append(ts)

        with open(f"{self.result_dir}/dirty.json", "w") as f:
            d = {"ts": time_ts, "dirty": results}
            json.dump(d, f)

        print("colllector done")

    def start(self):
        self.proc = Process(target=self.collect)
        self.proc.start()

    def end(self):
        self.ev.set()

        self.proc.join()


class CpuUsageProfiler(DirtyMemoryProfiler):
    def __init__(self, interval_sec, result_dir):
        super().__init__(interval_sec, result_dir)

    def get_mpstat(self, interval):
        interval = int(interval)
        assert interval > 0
        rec = run_command(
            f"LC_ALL=en_US.UTF-8 mpstat {interval} 1 | grep all | grep -v Average")

        output = rec.stdout
        output = output.strip()
        fields = re.split(r"\s+", output)

        user_time = float(fields[3])
        sys_time = float(fields[5])

        # guest_time = float(fields[10])
        guest_time = float(fields[-1])
        guest_time = 100-guest_time
        # print(output, guest_time)

        return user_time, sys_time, guest_time

    def collect(self):

        time_ts = []
        users = []
        sys_times = []
        guests = []
        ts = 0
        while not self.ev.is_set():

            # time.sleep(self.interval_sec)
            ts += self.interval_sec
            user, sys_time, guest = self.get_mpstat(self.interval_sec)
            users.append(user)
            sys_times .append(sys_time)
            time_ts.append(ts)
            guests.append(guest)

        with open(f"{self.result_dir}/cpu.json", "w") as f:
            d = {"ts": time_ts, "guest": guests}
            json.dump(d, f)

        print("colllector done")


if __name__ == "__main__":
    # profiler = DirtyMemoryProfiler(1, "abc")
    # profiler.start()
    # time.sleep(5)
    # profiler.end()
    cpu_profiler = CpuUsageProfiler(1, "test")
    cpu_profiler.start()

    time.sleep(5)
    cpu_profiler.end()
