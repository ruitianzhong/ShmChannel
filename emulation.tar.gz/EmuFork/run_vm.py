#!/bin/env python3
from datetime import datetime
from typing import Set
from memory_metric import CpuUsageProfiler, DirtyMemoryProfiler, MemoryUsageCollector
from concurrent.futures import ThreadPoolExecutor, as_completed
from enum import Enum
import json
import os
from vm_utils import run_command, CmdRecord, run_commands
import time
import argparse
from memory_metric import MemoryMonitor
import re
from check_bgp import check_node_routes_str, check_node_str, expected_prefixes
from link_pool import LinkPool, calculate_resource_demand


def idx2veth_name(node_idx, tap_idx):
    return f"v{node_idx}-{tap_idx}"


DEBUG = True

CONTAINER_NAME = "real"

IMAGE_LIST = ["crpd", "frr", "bird"]


def blueprint_sanity_check(blueprint):
    idx = 1
    for router in blueprint["routers"]:
        assert idx == router["idx"]
        idx += 1


def do_cleanup():
    run_command("pkill firecracker")


def idx2mac(vm_idx, nic_idx):

    oct0 = "00"

    oct1 = (vm_idx >> 8) & 0xff
    oct2 = (vm_idx) & 0xff
    oct4 = nic_idx & 0xff
    mac = f"{oct0}:{oct1:02x}:{oct2:02x}:02:{oct4:02x}:01"

    return mac


def ip2mac(ip_addr: str):
    pass
    parts = list(map(int, ip_addr.split('.')))
    hex_ip = ':'.join(f'{part:02X}'.upper() for part in parts)
    final_mac = "06:00:" + hex_ip

    return final_mac


def mac2ip(mac_addr: str) -> list:
    digits = mac_addr.split(':')[2:]

    ip_digits = []

    for digit in digits:
        ip_digits.append(str(int(digit, 16)))

    return ip_digits


class VM:
    def __init__(self, vm_idx, results_dir, image=None, blueprint=None, debug=False, topo=None, use_vsock=False):
        self.vm_idx = vm_idx
        self.records = []
        self.endpoint = None
        self.image = image
        self.blueprint = blueprint
        self.debug = debug
        self.config_file_name = None
        self.mgmt_ip = "172.16.0.2"
        self.netns_prefix = f"ip netns exec {self.name()} "

        if topo is not None:
            self.config_file_name = f"conf/{image}/{topo}/node_{self.vm_idx}.conf"
            if self.vm_idx != 0:
                assert os.path.exists(self.config_file_name)
        if self.image is not None:
            assert self.image in IMAGE_LIST
        if not os.path.exists(results_dir):
            os.mkdir(results_dir)

        self.results_dir = os.path.join(results_dir, self._vm_name())
        if use_vsock:
            vsock_path = f"{self.results_dir}/v.sock"
            if os.path.exists(vsock_path):
                os.remove(vsock_path)

            if os.path.exists("v.sock"):
                os.remove("v.sock")

        self.first_dump = True
        if os.path.exists(self.api_socket_path()):
            os.remove(self.api_socket_path())
            if self.debug:
                print("Remove", self.api_socket_path())
        if self.debug:
            print(f"Create {self._vm_name()}")
        if not os.path.exists(self.results_dir):
            os.mkdir(self.results_dir)
        self.route = None
        self.bgp_summary = None

    def parse_route_age(self, output: str):
        lines = output.splitlines()
        pattern = r"\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}"
        for line in lines:
            if not "RIB routes" in line:
                continue

            result = re.search(pattern, line)
            if result:
                time_str = result.group()

                time_format = "%Y-%m-%d %H:%M:%S"

                time_obj = datetime.strptime(time_str, time_format)

                return time_obj

        return None

    def get_latest_routes_ts(self):
        prefix = f"{self.netns_prefix} ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} lwc exec real "
        cmd = f'{prefix} cli -c \\"show route summary\\"'

        rec = self._run_command(cmd)

        if rec.rc != 0:
            return False, -1

        t0 = self.parse_route_age(rec.stdout)

        cmd = f'{prefix} date +\\"%Y-%m-%d %H:%M:%S\\"'

        rec = self._run_command(cmd)

        h_t1 = time.monotonic()

        if rec.rc != 0:
            return False, -1

        pattern = r"\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}"
        result = re.search(pattern, rec.stdout)
        t1 = datetime.strptime(result.group(), "%Y-%m-%d %H:%M:%S")

        delta = t1.timestamp() - t0.timestamp()

        return True, h_t1-delta

    def check_converge(self, expected):
        self.collect_route_and_bgp_summary()

        if not self.check_bgp_summary() or not self.check_route(expected):
            return False, self.vm_idx

        return True, self.vm_idx

    def start_container(self):
        # create container
        prefix = f"timeout -k 10 20 {self.netns_prefix} ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} "
        cmds = [f"lwc create real-crpd {CONTAINER_NAME}",
                f"lwc start {CONTAINER_NAME} /sbin/runit-init.sh"
                ]

        cmd = ";".join(cmds)
        cnt = 0
        while True:
            result = self._run_command(f"{prefix} '{cmd}'")
            self.dump_logs()
            if result.rc != 0:
                self.dump_logs()
                cnt += 1
            else:
                break
            if cnt == 10:
                self.dump_logs()
                raise BaseException(f"{self.name()} failed to start container")
        self.dump_logs()
        cnt = 0
        while True:
            rec = run_command(
                f'{prefix} lwc exec {CONTAINER_NAME}  cli -c \\"request system license add /crpd-license\\"')
            if "add license complete" in rec.stdout:
                if DEBUG:
                    # print("add license complete!")
                    pass
                break
            time.sleep(0.5)
            if cnt == 500:
                print("Timeout")
                raise Exception(str(rec))
            cnt += 1

    def _vm_name(self):
        return f"vm_{self.vm_idx}"

    def configure_container(self):
        # transfer config file
        assert self.config_file_name is not None
        ssh_prefix = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} "
        cmds = [
            f"scp -i id_rsa {self.config_file_name} root@{self.mgmt_ip}:/tmp/opt/lwc/containers/{CONTAINER_NAME}/rootfs/etc/crpd/crpd.conf",
            f'{ssh_prefix} "lwc exec {CONTAINER_NAME} bash -c \'cli << EOF\nconfig\nload override /etc/crpd/crpd.conf\ncommit\nEOF\'"'
        ]
        final_cmds = [f"{self.netns_prefix} {cmd} " for cmd in cmds]
        return final_cmds

    def load_base_config(self):
        assert self.config_file_name is not None
        assert os.path.exists(self.config_file_name)
        ssh_prefix = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} "
        cmds = [
            f"scp -i id_rsa {self.config_file_name} root@{self.mgmt_ip}:/tmp/opt/lwc/containers/{CONTAINER_NAME}/rootfs/etc/crpd/crpd.conf",
            f'{ssh_prefix} "lwc exec {CONTAINER_NAME} bash -c \'cli << EOF\nconfig\nload override /etc/crpd/crpd.conf\ncommit\nEOF\'"'
        ]
        final_cmds = [f"{self.netns_prefix} {cmd} " for cmd in cmds]
        self._run_commands(final_cmds)
        self.dump_logs()

    def name(self):
        return self._vm_name()

    def api_socket_path(self):
        return f"/tmp/{self._vm_name()}.sock"

    def _run_command(self, cmd: str) -> CmdRecord:
        record = run_command(cmd)
        self.records.append(record)
        return record

    def _run_commands(self, cmds: list) -> list:
        records = []
        for cmd in cmds:
            records.append(self._run_command(cmd))
        return records

    def dump_logs(self):
        with open(f"{self.results_dir}/cmd.log", "w" if self.first_dump else "a") as f:
            f.writelines([str(rec) for rec in self.records])
            self.first_dump = False

        self.records = []

    def create_vm(self):
        raise NotImplementedError

    def shutdown_vm_gracefully(self):
        cmd = f"""sudo curl -X PUT 'http://localhost/actions' \
          --unix-socket {self.api_socket_path()} \
                    --data '{{
                    "action_type":  "SendCtrlAltDel"
                        }}' """

        return self._run_command(cmd)

    def add_nic(self, iface_id: str, host_dev_name: str, guest_mac=None):
        guest_mac = "null" if guest_mac is None else f"\"{guest_mac}\""
        cmd = f"""curl -X PUT 'http://localhost/network-interfaces/{iface_id}' --unix-socket {self.api_socket_path()} \
                --data '{{
                 "iface_id": "{iface_id}",
                "guest_mac": {guest_mac},
                "host_dev_name": "{host_dev_name}"
         }}' """
        return self._run_command(cmd)

    def collect_route_and_bgp_summary(self):
        self.route = None
        self.bgp_summary = None

        prefix = f'timeout -k 60 5 ip netns exec {self.name()} ssh -o StrictHostKeyChecking=no -i id_rsa root@172.16.0.2 lwc exec {CONTAINER_NAME} '
        summary_cmd = f'{prefix} cli -c \\"show bgp summary\\"'
        route_cmd = f'{prefix} cli -c \\"show route\\"'

        summary = self._run_command(summary_cmd)
        route = self._run_command(route_cmd)

        self.route = route.stdout
        self.bgp_summary = summary.stdout

    def check_bgp_summary(self):
        assert self.bgp_summary is not None and self.image is not None

        ok, msg = check_node_str(
            self.image, self.blueprint, self.vm_idx, self.bgp_summary)

        if not ok:
            if self.debug:
                print(f"summary: {self.bgp_summary}")
                print(f"{self.name()} summary:", msg)
            return False

        return True

    def check_route(self, expected):
        assert self.route is not None and self.image is not None

        ok, msg = check_node_routes_str(expected, self.image, self.route)
        if not ok:
            if self.debug:
                print(f"routes: {self.route}")
                print(f"{self.name()} msg:", msg)
            return False

        return True


class NetworkEndpoint:
    def __init__(self, netns, num_max_nics, vm=None):
        self.nics = [None]*num_max_nics
        self.commands = [None]*num_max_nics
        self.netns = netns
        self.vm: VM | None = vm
        self.nics_dev_name = [None]*num_max_nics
        self.mgmt = None

    def set_nic_dev_name(self, idx, info, dev_name):
        if self.nics[idx] is not None:
            print(idx)
        assert self.nics[idx] is None
        assert self.nics_dev_name[idx] is None
        assert info is not None
        self.nics[idx] = info
        self.nics_dev_name[idx] = dev_name

    def set_unused_nic_name(self, pool: LinkPool):
        for idx in range(len(self.nics)):
            if self.nics[idx] == None:
                name = pool.get_unused_tap()
                self.nics_dev_name[idx] = name

    def set_mgmt_nic_name(self, mgmt):
        self.mgmt = mgmt

    def remap_tap(self):
        override_list = []
        for idx, dev_name in enumerate(self.nics_dev_name):
            record = {"iface_id": f"tap{idx+1}",
                      "host_dev_name": f"{dev_name}"}
            override_list.append(record)

        record = {"iface_id": f"mgmt",
                  "host_dev_name": f"{self.mgmt}"}

        override_list.append(record)

        return override_list

    def set_nic_info(self, idx, info):
        if self.nics[idx] is not None:
            print(idx)
        assert self.nics[idx] is None
        assert info is not None
        self.nics[idx] = info
        tap = f"tap{idx+1}"

        netns = self.netns
        veth = idx2veth_name(self.vm.vm_idx, idx+1)
        seperate_cmds = [
            f"ip tuntap add dev {tap} mode tap",
            f"ip link set {tap} up",
            f"ip link add br-{tap} type bridge",
            f"ip link set {tap} master br-{tap}",
            f"ip link set {veth} master br-{tap}",
            f"ip link set br-{tap} up",
            f"ip link set {veth} up",
        ]

        long_cmd = ";".join(seperate_cmds)

        cmds = [f"ip netns exec {netns} bash -c '{long_cmd}'"]

        self.commands.append(cmds)

    def set_mgmt_nic_info(self):
        cmd = [
            f"ip netns exec {self.netns} bash -c 'ip tuntap add dev tap0 mode tap;ip addr add 172.16.0.1/30 dev tap0;ip link set tap0 up'"]

        self.commands.append(cmd)

    def guest_network_commands(self, reset_mac=True):
        cmds = []

        for idx, nic_info in enumerate(self.nics):
            if nic_info == None:
                cmd = [f"ip link set eth{idx+1} down"]
                cmds += cmd
                continue

            interface = f"eth{idx+1}"
            mac = nic_info[1]
            ip = nic_info[0]
            if reset_mac:
                cmd = [f"ip link set {interface} down",
                       f"ip link set {interface} address {mac}",
                       f"ip link set {interface} up",
                       f"ip addr add {ip} dev {interface}",
                       ]
            else:
                cmd = [f"ip link set {interface} up",
                       f"ip addr add {ip} dev {interface}",
                       ]
            cmds += cmd
        return ";".join(cmds)


class VMBase(VM):
    def __init__(self, vm_idx, config_file, result_dirs, blueprint=None, image=None, topo=None, init_network=True, use_vsock=False):
        super().__init__(vm_idx, result_dirs, image,
                         blueprint, topo=topo, use_vsock=use_vsock)
        if init_network:
            self.create_netns_and_mgmt()

        self.config_file = config_file

        self.config_dict = None

        if blueprint:
            self.update_vm_config(blueprint, config_file)

        if self.config_file is not None:
            assert os.path.exists(self.config_file)
            with open(self.config_file) as f:
                self.config_dict = json.load(f)
            if blueprint and init_network:

                for nic in self.config_dict["network-interfaces"]:
                    if "tap" not in nic["iface_id"]:
                        continue

                    name = nic["host_dev_name"]

                    cmds = [f"{self.netns_prefix} ip tuntap add dev {name} mode tap",
                            f"{self.netns_prefix} ip link set {name} up"]

                    self._run_commands(cmds)

        assert isinstance(vm_idx, int)

    def copy_and_start_agent(self):
        from_path = "./docker_net_emulation/agent/server"
        to_path = "/tmp"
        cmd = f"{self.netns_prefix} scp -i id_rsa {from_path} root@172.16.0.2:{to_path}"
        self._run_command(cmd)
        cmd = f"{self.netns_prefix} ssh -i id_rsa root@172.16.0.2 'nohup /tmp/server >/tmp/server.log 2>&1 &'"
        self._run_command(cmd)

    def update_vm_config(self, blueprint, config_file, padding=True):
        if padding:
            max_num_nics = 1

            for router in blueprint["routers"]:
                max_num_nics = max(max_num_nics, len(router["neighbors"]))

        else:
            max_num_nics = len(blueprint["routers"]
                               [self.vm_idx-1]["neighbors"])

        with open(config_file, "r") as f:
            config = json.load(f)
        network_config: list = config["network-interfaces"]

        for i in range(max_num_nics):
            new_nic = {"iface_id": f"tap{i+1}",
                       "guest_mac": None, "host_dev_name": f"tap{i+1}"}
            network_config.append(new_nic)
        new_config_file = f"{self.results_dir}/{self.name()}.json"
        self.config_file = new_config_file
        with open(new_config_file, "w") as f:
            json.dump(config, f)

    def create_netns_and_mgmt(self):
        cmds = [f"ip netns del {self.name()} || true",
                f"ip netns add {self.name()}"]

        self._run_commands(cmds)

        self.netns_prefix = f"ip netns exec {self.name()} "

        self._run_commands(
            [f"{self.netns_prefix} ip tuntap add dev tap0 mode tap",
             f"{self.netns_prefix} ip link set tap0 up",
             f"{self.netns_prefix} ip addr add 172.16.0.1/30 dev tap0"])

    def create_vm(self):
        if self.config_file is not None:
            cmd = f"{self.netns_prefix} nohup firecracker --enable-pci --api-sock {self.api_socket_path()} --config-file {self.config_file} > {self.results_dir}/{self._vm_name()}.log 2>&1 & "
            return self._run_command(cmd)
        cmd = f"{self.netns_prefix} nohup firecracker --api-sock {self.api_socket_path()} > {self.results_dir}/{self._vm_name()}.log 2>&1 & "
        return self._run_command(cmd)

    def pause_vm(self):
        cmd = f"""curl --unix-socket {self.api_socket_path()} -i \
            -X PATCH 'http://localhost/vm' \
            -H 'Accept: application/json' \
            -H 'Content-Type: application/json' \
            -d '{{
            "state": "Paused"
            }}'"""
        record = run_command(cmd)
        self.records.append(record)
        return record

    def resume_vm(self):
        cmd = f"""curl --unix-socket {self.api_socket_path()} -i \
                -X PATCH 'http://localhost/vm' \
                -H 'Accept: application/json' \
                -H 'Content-Type: application/json' \
                -d '{{
                        "state": "Resumed"
                 }}'"""

        return self._run_command(cmd)

    def snapshot_vm(self):
        cmd = f"""curl --unix-socket {self.api_socket_path()} -i \
                -X PUT 'http://localhost/snapshot/create' \
                -H  'Accept: application/json' \
                -H  'Content-Type: application/json' \
                -d '{{
                    "snapshot_type": "Full",
                    "snapshot_path": "{self.results_dir}/snapshot_file",
                    "mem_file_path": "{self.results_dir}/mem_file"
        }}'"""
        return self._run_command(cmd)

    def start_from_snapshot(self, other_vm: VM) -> CmdRecord:
        snapshot_prefix = other_vm.results_dir

        cmd = f"""curl --unix-socket {self.api_socket_path()} -i \
                -X PUT 'http://localhost/snapshot/load' \
                -H  'Accept: application/json' \
                -H  'Content-Type: application/json' \
                -d '{{
                    "snapshot_path": "{snapshot_prefix}/snapshot_file",
                    "mem_backend": {{
                    "backend_path": "{snapshot_prefix}/mem_file",
                    "backend_type": "File"
                    }},
            "track_dirty_pages": true,
            "resume_vm": true
            }}'"""

        return self._run_command(cmd)

    def wait_ready(self):
        cnt = 0
        while cnt < 100:
            rec = run_command(
                f"{self.netns_prefix} ssh -o StrictHostKeyChecking=no -i id_rsa root@172.16.0.2 echo ok"
            )
            if "ok" in rec.stdout:
                break
            time.sleep(0.5)
            cnt += 1
            if cnt == 100:
                raise BaseException("VM is not ready")


class VMForked(VM):
    def __init__(self, vm_idx, results_dir, from_vm: VMBase, init_network=True, topo=None, image=None, use_vsock=False):
        super().__init__(vm_idx, results_dir, image,
                         from_vm.blueprint, topo=topo, use_vsock=use_vsock)

        self.mem_file = os.path.join(from_vm.results_dir, "mem_file")
        self.snapshot_file = os.path.join(from_vm.results_dir, "snapshot_file")
        self.mem_file = os.path.abspath(self.mem_file)
        self.snapshot_file = os.path.abspath(self.snapshot_file)

        # set up network namespace (it's needed for vm clone)
        self.net_ns = self._vm_name()
        self.netns_prefix = f"ip netns exec {self.net_ns} "

        self.mgmt_ip = None

        self.other_vm_config = from_vm.config_dict
        self.network_init = False

        if init_network:
            self.create_network()

        self.config_file_name = None

        if topo is not None:
            self.config_file_name = f"conf/{image}/{topo}/node_{self.vm_idx}.conf"

    def create_network(self):
        if self.network_init:
            return
        self._create_net_ns()
        net_interfaces = self.other_vm_config["network-interfaces"]
        for nic in net_interfaces:
            iface_id = nic["iface_id"]
            tap_name = nic["host_dev_name"]
            ip_addr = None

            if iface_id == "mgmt" and nic["guest_mac"] and nic["guest_mac"][0:2] == "06":
                guest_mac = nic["guest_mac"]

                ip_digits = mac2ip(guest_mac)
                self.mgmt_ip = '.'.join(ip_digits)
                ip_digits[-1] = "1"
                ip = '.'.join(ip_digits)

                ip_addr = f"{ip}/30"

            self._create_net_tap(tap_name=tap_name, tap_ip=ip_addr)

    def _create_net_ns(self):

        cmds = [f"ip netns delete {self.net_ns} || true",
                f"ip netns add {self.net_ns}"]
        self._run_commands(cmds)

    def _create_net_tap(self, tap_name, tap_ip=None):
        cmds = [
            f"{self.netns_prefix} ip tuntap add dev {tap_name} mode tap",

        ]
        if tap_ip is not None:
            cmds.append(
                f"{self.netns_prefix} ip addr add {tap_ip} dev {tap_name}")

        cmds.append(f"{self.netns_prefix} ip link set dev {tap_name} up")

        self._run_commands(cmds)

    def create_vm(self):
        cmd = f"{self.netns_prefix} nohup firecracker --enable-pci --api-sock {self.api_socket_path()} > {self.results_dir}/{self._vm_name()}.log 2>&1 & "
        return self._run_command(cmd)

    def fork(self):
        cmd = f"""curl --unix-socket {self.api_socket_path()} -i \
                        -X PUT 'http://localhost/snapshot/load' \
                        -H  'Accept: application/json' \
                        -H  'Content-Type: application/json' \
                        -d '{{
                                "snapshot_path": "{self.snapshot_file}",
                                "mem_file_path": "{self.mem_file}",
                        "track_dirty_pages": true,
                        "resume_vm": true}}'"""

        return self._run_command(cmd)

    def check(self) -> bool:
        if self.mgmt_ip is None:
            return False

        cmd = self._run_command(
            f"{self.netns_prefix} timeout -k 10 5 ssh -o StrictHostKeyChecking=no -i id_rsa {self.mgmt_ip} pwd")
        if cmd.rc != 0:
            print(f"{self.name()}")
        return cmd.rc == 0

    def create_and_fork(self):
        records = []
        records.append(self.create_vm())

        for i in range(10):
            record = self.fork()
            if record.rc == 0:
                records.append(record)
                break
            else:
                print(f"retry {self.vm_idx}")
                time.sleep(0.5)

        return records


SHARED_NETNS = "fork"


class SingleNamespaceBaseVM(VMBase):
    def __init__(self, vm_idx, config_file, result_dirs, netns, blueprint=None, image=None, topo=None, use_vsock=False):
        super().__init__(vm_idx, config_file, result_dirs,
                         None, image, topo, False, use_vsock=False)

        self.netns_prefix = f"ip netns exec {netns} "
        assert image and topo
        self.config_file_name = f"conf/{image}/{topo}/node_{self.vm_idx}.conf"


class SingleNamespaceForkedVM(VMForked):
    def __init__(self, vm_idx, results_dir, from_vm: VMBase, init_network=True, topo=None, image=None):
        super().__init__(vm_idx, results_dir, from_vm,
                         init_network, topo, image, use_vsock=True)
        # make
        self.work_dir = self.results_dir
        if os.path.exists(f"{self.work_dir}/v.sock"):
            os.remove(f"{self.work_dir}")

        self.net_ns = SHARED_NETNS
        self.netns_prefix = f"ip netns exec {self.net_ns} "

        self.override_mapping_list = None

    def collect_route_and_bgp_summary(self):
        self.route = None
        self.bgp_summary = None

        prefix = f'timeout -k 60 5 ip netns exec {SHARED_NETNS} ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} lwc exec {CONTAINER_NAME} '
        summary_cmd = f'{prefix} cli -c \\"show bgp summary\\"'
        route_cmd = f'{prefix} cli -c \\"show route\\"'

        summary = self._run_command(summary_cmd)
        route = self._run_command(route_cmd)

        self.route = route.stdout
        self.bgp_summary = summary.stdout

    def reset_mgmt_interface(self):
        cmd = f"./docker_net_emulation/agent/client {self.mgmt_ip} {self.results_dir}/v.sock"

        return cmd

    def fork(self):
        assert self.override_mapping_list is not None
        override = json.dumps(self.override_mapping_list)
        cmd = f"""cd {self.results_dir}; curl --unix-socket {self.api_socket_path()} -i \
                        -X PUT 'http://localhost/snapshot/load' \
                        -H  'Accept: application/json' \
                        -H  'Content-Type: application/json' \
                        -d '{{
                                "snapshot_path": "{self.snapshot_file}",
                                "mem_file_path": "{self.mem_file}",
                        "track_dirty_pages": true,
                        "resume_vm": true,
                        "network_overrides": {override}
                        }}'"""

        return self._run_command(cmd)

    def create_vm(self):
        abs_path = os.path.abspath(f"{self.results_dir}")

        cmd = f"cd {self.results_dir};{self.netns_prefix} nohup firecracker --enable-pci --api-sock {self.api_socket_path()} > {abs_path}/{self._vm_name()}.log 2>&1 & "
        return self._run_command(cmd)

    def setup_all_after_fork(self):
        self.setup_guest_network()

        self.configure_container()


class VMGroup:
    def __init__(self, blueprint=None, result_dir=None, topo=None, image=None):
        self.records = []
        self.vms: list[VM] = []
        self.registered = set()
        self.first_log = True
        self.result_dir = result_dir
        self.topo = topo
        self.image = image
        self.blueprint = blueprint

    def dump_all(self):
        # Slow implementation
        for vm in self.vms:
            vm.dump_logs()

    def start_container(self):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.start_container(),
                    vm
                )
                for vm in self.vms
            ]
            for future in as_completed(futures):
                future.result()

    def configure_container(self):
        cmds = []
        for vm in self.vms:
            cmds.append(vm.configure_container())

        self.records += self.cocurrent_run_command(cmds)

    def setup_host_tap(self):
        records = []

        # for cmd in self.create_veth_cmds:
        #     records += run_commands(cmd)
        veth_start_ts = time.monotonic()

        # create_veth_cmds = [[cmd[0]] for cmd in self.create_veth_cmds]

        # move_veth_cmds = [[cmd[1], cmd[2]] for cmd in self.create_veth_cmds]

        # records += self.cocurrent_run_command(create_veth_cmds)

        # records += self.cocurrent_run_command(move_veth_cmds)

        records += self.cocurrent_run_command(self.create_veth_cmds)
        veth_finish_ts = time.monotonic()
        print(
            f"create veth {veth_finish_ts-veth_start_ts}")
        cmds = []

        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint

            cmds += [commands for commands in ep.commands if commands is not None]

        records += self.cocurrent_run_command(cmds)

        tap_finish_ts = time.monotonic()

        print(f"create tap: {tap_finish_ts-veth_finish_ts}")
        self.records += records

    def setup_guest_network(self):
        cmds = []
        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint
            bash = ep.guest_network_commands()
            cmds.append(
                [f"ip netns exec {vm.name()} ssh -o StrictHostKeyChecking=no -i id_rsa root@172.16.0.2 '{bash}'"])
        records = []

        records += self.cocurrent_run_command(cmds)

        if self.result_dir:
            with open(f"{self.result_dir}/guest.log", "w") as f:
                f.writelines([str(rec) for rec in records])

    def wait_converge(self, timeout=None):
        expected = expected_prefixes(self.blueprint)
        start = time.monotonic()
        while True:
            ok = True
            not_ready = []
            with ThreadPoolExecutor() as executor:
                futures = [
                    executor.submit(
                        lambda v: v.check_converge(expected),
                        vm
                    )
                    for vm in self.vms
                ]
            not_ok_cnt = 0
            for future in as_completed(futures):
                converged, idx = future.result()
                if not converged:
                    ok = False
                    not_ok_cnt += 1
                    not_ready.append(idx)

            if ok:
                return True, time.monotonic()

            time.sleep(5)
            if DEBUG and False:
                print("len for not_ready", len(not_ready))
            if timeout and time.monotonic()-start > timeout:
                print("timeout exit")
                return False, -1

    def register_vm(self, vm: VM):

        if vm.name() in self.registered:
            return

        self.registered.add(vm.name())
        self.vms.append(vm)

    def cocurrent_run_command(self, cmds):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda c: run_commands(c),
                    cmd
                )
                for cmd in cmds
            ]
        records = []
        for future in as_completed(futures):
            records += future.result()

        # records = []

        # for cmd in cmds:
        #     records += run_commands(cmd)

        return records

    def setup_netns(self):
        cmds = []
        for vm in self.vms:

            cmd = [f"ip netns del {vm.name()} || true",
                   f"ip netns add {vm.name()}"]
            cmds.append(cmd)

        self.records += self.cocurrent_run_command(cmds)

    def teardown_netns(self):
        cmds = []
        for vm in self.vms:
            cmd = [f"ip netns del {vm.name()}"]
            cmds.append(cmd)

        self.records += self.cocurrent_run_command(cmds)

    def dump_logs(self):
        if self.result_dir:

            if self.first_log:
                self.first_log = False
                flag = "w"
            else:
                flag = "a"
            with open(f"{self.result_dir}/fork_group.log", flag) as f:
                f.writelines([str(rec) for rec in self.records])
                self.records = []

    def register_all(self):
        raise NotImplemented

    def init(self):
        # Must be implemented

        self.register_all()
        for router in self.blueprint["routers"]:
            m = {}
            for idx, neighbor in enumerate(router["neighbors"]):
                m[neighbor["peeridx"]] = idx

            router["peer_map"] = m

        self.create_veth_cmds = []
        routers = self.blueprint["routers"]

        for router in routers:
            idx1 = router["idx"]
            for idx, neighbor in enumerate(router["neighbors"]):
                idx2 = neighbor["peeridx"]

                if idx1 > idx2:
                    continue

                vm1 = self.vms[idx1-1]
                vm2 = self.vms[idx2-1]
                # Assumption: SEQUENTIAL

                nic_idx2 = routers[idx2-1]["peer_map"][idx1]
                nic_idx1 = idx
                # print(idx1, nic_idx1, idx2, nic_idx2)
                ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
                ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"
                mac1 = idx2mac(idx1, nic_idx1)

                mac2 = idx2mac(idx2, nic_idx2)
                vm1.endpoint.set_nic_info(
                    nic_idx1, (f"{ip1}", f"{mac1}"))

                vm2.endpoint.set_nic_info(
                    nic_idx2, (f"{ip2}", f"{mac2}"))

                ns0 = vm1.name()
                ns1 = vm2.name()

                veth1 = idx2veth_name(vm1.vm_idx, nic_idx1+1)
                veth2 = idx2veth_name(vm2.vm_idx, nic_idx2+1)
                create_veth_cmd = [f"ip link add {veth1} type veth peer name {veth2};"
                                   f"ip link set {veth1} netns {ns0};"
                                   f"ip link set {veth2} netns {ns1}"]

                self.create_veth_cmds.append(create_veth_cmd)


class SingleNamespaceBaseVMGroup(VMGroup):
    def __init__(self, pool: LinkPool, netns, config_file, blueprint=None, result_dir=None, topo=None, image=None):
        super().__init__(blueprint, result_dir, topo, image)
        self.vms: list[SingleNamespaceBaseVM] = []
        self.pool = pool
        self.conf_path = f"{result_dir}/conf"
        if not os.path.exists(self.conf_path):
            os.mkdir(self.conf_path)

        self.base_config = config_file
        self.netns = netns

    def register_all(self):

        num_vms = len(self.blueprint["routers"])
        for idx in range(num_vms):
            vm = SingleNamespaceBaseVM(
                idx+1, self.base_config, self.result_dir, self.netns, self.blueprint, image=self.image, topo=self.topo)
            num_nics = len(self.blueprint["routers"][idx]["neighbors"])
            vm.endpoint = NetworkEndpoint(vm.name(), num_nics, vm)
            self.vms.append(vm)

    def init(self):

        # Must be implemented

        self.register_all()
        for router in self.blueprint["routers"]:
            m = {}
            for idx, neighbor in enumerate(router["neighbors"]):
                m[neighbor["peeridx"]] = idx

            router["peer_map"] = m

        self.create_veth_cmds = []
        routers = self.blueprint["routers"]

        for router in routers:
            idx1 = router["idx"]
            for idx, neighbor in enumerate(router["neighbors"]):
                idx2 = neighbor["peeridx"]

                if idx1 > idx2:
                    continue

                vm1: SingleNamespaceBaseVM = self.vms[idx1-1]
                vm2: SingleNamespaceBaseVM = self.vms[idx2-1]
                # Assumption: SEQUENTIAL

                nic_idx2 = routers[idx2-1]["peer_map"][idx1]
                nic_idx1 = idx
                # print(idx1, nic_idx1, idx2, nic_idx2)
                ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
                ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"
                mac1 = idx2mac(idx1, nic_idx1)

                mac2 = idx2mac(idx2, nic_idx2)
                ep1: NetworkEndpoint = vm1.endpoint
                ep2: NetworkEndpoint = vm2.endpoint

                normal_link = self.pool.get_link()
                ep1.set_nic_dev_name(
                    nic_idx1, (f"{ip1}", f"{mac1}"), normal_link.tap0_name)

                ep2.set_nic_dev_name(
                    nic_idx2, (f"{ip2}", f"{mac2}"), normal_link.tap1_name)
        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint

            mgmt = self.pool.get_mgmt_link()
            ep.set_mgmt_nic_name(mgmt.tap_name)
            vm.mgmt_ip = mgmt.guest_side_ip

        with open(self.base_config) as f:
            config_dict = json.load(f)

        for vm in self.vms:
            network_config = []
            ep: NetworkEndpoint = vm.endpoint
            # mgmt
            network_config.append(
                {
                    "iface_id": "mgmt",
                    "guest_mac": ip2mac(vm.mgmt_ip),
                    "host_dev_name": ep.mgmt
                }
            )

            for idx, nic in enumerate(ep.nics_dev_name):
                network_config.append(
                    {
                        "iface_id": f"tap{idx}",
                        "guest_mac": None,
                        "host_dev_name": nic
                    }
                )
            config_dict["network-interfaces"] = network_config

            with open(f"{self.conf_path}/vm_{vm.vm_idx}.json", "w") as f:
                json.dump(config_dict, f)

            vm.config_file = f"{self.conf_path}/vm_{vm.vm_idx}.json"

    def start_all(self):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.create_vm(),
                    vm
                )
                for vm in self.vms
            ]
            records = []
            for future in as_completed(futures):
                records += [future.result()]

    def setup_guest_network(self):
        cmds = []
        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint
            bash = ep.guest_network_commands()
            cmds.append(
                [f"ip netns exec {SHARED_NETNS} ssh -o StrictHostKeyChecking=no -i id_rsa root@{vm.mgmt_ip} '{bash}'"])
        records = []

        records += self.cocurrent_run_command(cmds)

        if self.result_dir:
            with open(f"{self.result_dir}/guest.log", "w") as f:
                f.writelines([str(rec) for rec in records])


class SingleNamespaceForkedVMGroup(VMGroup):
    def __init__(self, base_vm: VMBase, blueprint=None, result_dir=None, topo=None, image=None, pool=None):
        super().__init__(blueprint, result_dir, topo, image)
        self.vms: list[SingleNamespaceForkedVM] = []
        self.pool = pool

        assert base_vm is not None
        self.base_vm = base_vm

    def setup_guest_network(self):
        cmds = []
        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint
            bash = ep.guest_network_commands()
            cmds.append(
                [f"ip netns exec {SHARED_NETNS} ssh -o StrictHostKeyChecking=no -i id_rsa root@{vm.mgmt_ip} '{bash}'"])
        records = []

        records += self.cocurrent_run_command(cmds)

        if self.result_dir:
            with open(f"{self.result_dir}/guest.log", "w") as f:
                f.writelines([str(rec) for rec in records])

    def register_all(self):

        num_vms = len(self.blueprint["routers"])

        for idx in range(num_vms):
            forked_vm = SingleNamespaceForkedVM(
                idx+1, self.result_dir, from_vm=self.base_vm, init_network=False, topo=self.topo, image=self.image)
            self.vms.append(forked_vm)

        max_num_nics = 1
        for router in self.blueprint["routers"]:
            max_num_nics = max(max_num_nics, len(router["neighbors"]))

        for vm in self.vms:
            vm.endpoint = NetworkEndpoint(vm.name(), max_num_nics, vm)

    def start_all(self):
        # records = []
        # for vm in self.vms:
        #     records +=vm.create_and_fork()
        # return records

        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.create_and_fork(),
                    vm
                )
                for vm in self.vms
            ]
            records = []
            for future in as_completed(futures):
                records += future.result()
    # def start_all(self):
    #     with ThreadPoolExecutor() as executor:
    #         futures = [
    #             executor.submit(
    #                 lambda v: v.create_vm(),
    #                 vm
    #             )
    #             for vm in self.vms
    #         ]
    #         records = []
    #         for future in as_completed(futures):
    #             records.append(future.result())

    #     def run_until_success(v):
    #         records = []

    #         for i in range(10):
    #             record = v.fork()
    #             if record.rc == 0:
    #                 records.append(record)
    #                 break
    #             else:
    #                 print(f"retry {v.vm_idx}")
    #                 time.sleep(0.5)

    #     with ThreadPoolExecutor() as executor:
    #         futures = [
    #             executor.submit(
    #                 lambda v: run_until_success(v),
    #                 vm
    #             )
    #             for vm in self.vms
    #         ]
    #         for future in as_completed(futures):
    #             records.append(future.result())

    def reset_mgmt(self):
        cmds = []
        for vm in self.vms:
            cmd = [vm.reset_mgmt_interface()]
            cmds.append(cmd)

        self.records += self.cocurrent_run_command(cmds)

    def init(self):

        # Must be implemented

        self.register_all()
        for router in self.blueprint["routers"]:
            m = {}
            for idx, neighbor in enumerate(router["neighbors"]):
                m[neighbor["peeridx"]] = idx

            router["peer_map"] = m

        self.create_veth_cmds = []
        routers = self.blueprint["routers"]

        for router in routers:
            idx1 = router["idx"]
            for idx, neighbor in enumerate(router["neighbors"]):
                idx2 = neighbor["peeridx"]

                if idx1 > idx2:
                    continue

                vm1: SingleNamespaceForkedVM = self.vms[idx1-1]
                vm2: SingleNamespaceForkedVM = self.vms[idx2-1]
                # Assumption: SEQUENTIAL

                nic_idx2 = routers[idx2-1]["peer_map"][idx1]
                nic_idx1 = idx
                # print(idx1, nic_idx1, idx2, nic_idx2)
                ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
                ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"
                mac1 = idx2mac(idx1, nic_idx1)

                mac2 = idx2mac(idx2, nic_idx2)
                ep1: NetworkEndpoint = vm1.endpoint
                ep2: NetworkEndpoint = vm2.endpoint

                normal_link = self.pool.get_link()
                ep1.set_nic_dev_name(
                    nic_idx1, (f"{ip1}", f"{mac1}"), normal_link.tap0_name)

                ep2.set_nic_dev_name(
                    nic_idx2, (f"{ip2}", f"{mac2}"), normal_link.tap1_name)
        for vm in self.vms:
            ep: NetworkEndpoint = vm.endpoint
            ep.set_unused_nic_name(self.pool)

            mgmt = self.pool.get_mgmt_link()
            ep.set_mgmt_nic_name(mgmt.tap_name)
            vm.mgmt_ip = mgmt.guest_side_ip

            vm.override_mapping_list = ep.remap_tap()


class VMForkedGroup(VMGroup):
    # Collective op
    def __init__(self, blueprint=None, result_dir=None, topo=None, image=None, base_vm=None):
        super().__init__(blueprint, result_dir, topo, image)
        self.vms: list[VMForked] = []

        assert base_vm is not None
        self.base_vm = base_vm

    def register_all(self):

        num_vms = len(self.blueprint["routers"])

        for idx in range(num_vms):
            forked_vm = VMForked(
                idx+1, self.result_dir, from_vm=self.base_vm, init_network=False, topo=self.topo, image=self.image)
            self.vms.append(forked_vm)

        max_num_nics = 1
        for router in self.blueprint["routers"]:
            max_num_nics = max(max_num_nics, len(router["neighbors"]))

        for vm in self.vms:
            vm.endpoint = NetworkEndpoint(vm.name(), max_num_nics, vm)
            vm.endpoint.set_mgmt_nic_info()

    def start_all(self):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.create_and_fork(),
                    vm
                )
                for vm in self.vms
            ]
            records = []
            for future in as_completed(futures):
                records += future.result()

    def check_all(self):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.check(), vm
                )
                for vm in self.vms
            ]
        for future in as_completed(futures):
            if future.result() != True:
                return False

        return True

    def shutdown_all(self):
        [vm.shutdown_vm_gracefully() for vm in self.vms]


class BaseVMGroup(VMGroup):
    def __init__(self, config_file, blueprint=None, result_dir=None, topo=None, image=None):
        super().__init__(blueprint, result_dir, topo, image)
        self.config_file = config_file

    def register_all(self):

        num_vms = len(self.blueprint["routers"])

        for idx in range(num_vms):
            basevm = VMBase(
                idx+1, config_file=self.config_file, result_dirs=self.result_dir, blueprint=self.blueprint, topo=self.topo, image=self.image, init_network=False)
            basevm.update_vm_config(
                self.blueprint, config_file=self.config_file, padding=False)

            self.vms.append(basevm)

        for vm in self.vms:
            vm.endpoint = NetworkEndpoint(
                vm.name(), len(self.blueprint["routers"][vm.vm_idx-1]["neighbors"]), vm)
            vm.endpoint.set_mgmt_nic_info()

    def start_container(self):

        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.start_container(),
                    vm
                )
                for vm in self.vms
            ]
            for future in as_completed(futures):
                future.result()

    def start_all(self):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda v: v.create_vm(),
                    vm
                )
                for vm in self.vms
            ]
            for future in as_completed(futures):
                future.result()


def safe_sleep(seconds):
    try:
        time.sleep(seconds)

    except BaseException as e:
        print('Catch exception', e)


def test_deploy_forked_vm(args):
    blueprint_path = f"./conf/{args.image}/{args.topo}/blueprint.json"
    with open(blueprint_path) as f:
        blueprint = json.load(f)

    base_vm = VMBase(0, config_file=args.config_file,
                     result_dirs=args.result_dir, blueprint=blueprint, image="crpd", topo=args.topo)

    # start timestamp
    start = time.monotonic()
    base_vm.create_vm()

    if DEBUG:
        base_vm.dump_logs()

    base_vm.wait_ready()

    print("base vm is ready")
    if args.mode == "share_all":
        base_vm.start_container()
        base_vm.load_base_config()
    # Warm up the machine
    print("warmup")
    safe_sleep(15)
    # time.sleep(10)

    base_vm_setup_ts = time.monotonic()

    base_vm.pause_vm()
    base_vm.snapshot_vm()

    snapshot_ts = time.monotonic()

    collector = MemoryUsageCollector(args.result_dir, 1)

    collector.start()

    forked_group = VMForkedGroup(
        result_dir=args.result_dir, blueprint=blueprint, topo=args.topo, image=args.image, base_vm=base_vm)

    if DEBUG:
        base_vm.dump_logs()

    forked_group.init()

    forked_group.setup_netns()
    forked_group.setup_host_tap()

    setup_network_ts = time.monotonic()

    forked_group.start_all()

    if args.mode == "share_vm":
        forked_group.start_container()

    if DEBUG:
        forked_group.dump_logs()
    print("Start all!")

    print("Start up end")
    if DEBUG:
        forked_group.dump_logs()
        forked_group.dump_all()
    # safe_sleep(1800)

    forked_group.setup_guest_network()

    forked_group.configure_container()

    resume_ts = time.monotonic()

    print("waiting")
    # converge timestamp
    # ok, converge_ts = forked_group.wait_converge()
    converge_ts = time.monotonic()
    # To collect more memory usage
    time.sleep(60)
    max_converge_time = 0
    for vm in forked_group.vms:
        ok, ts = vm.get_latest_routes_ts()

        print(ok, ts-resume_ts, vm.vm_idx)
        max_converge_time = max(max_converge_time, ts-resume_ts)
    print("final print result", max_converge_time)
    collector.end()

    forked_group.dump_all()
    base_vm.dump_logs()
    forked_group.dump_logs()

    if not ok:
        print("timeout")
        do_cleanup()
        exit(1)
    stat = {
        "setup_base_vm": base_vm_setup_ts-start,
        "snapshot": snapshot_ts-base_vm_setup_ts,
        "setup_host_network": setup_network_ts-snapshot_ts,
        "resume": resume_ts-setup_network_ts,
        "converge": converge_ts - resume_ts
    }

    base_vm.resume_vm()

    forked_group.dump_all()

    base_vm.dump_logs()

    print(stat)
    safe_sleep(1200)
    # print("sampled route",
    #       forked_group.vms[0].route, forked_group.vms[0].bgp_summary)
    do_cleanup()
    forked_group.teardown_netns()
    forked_group.dump_logs()

    with open(f"{args.result_dir}/stat.log", "w") as f:
        json.dump(stat, f)


def test_no_vm_fork(args):
    blueprint_path = f"./conf/{args.image}/{args.topo}/blueprint.json"
    with open(blueprint_path) as f:
        blueprint = json.load(f)

    blueprint_sanity_check(blueprint)
    collector = MemoryUsageCollector(args.result_dir, 1)

    collector.start()
    # start timestamp
    base_group = BaseVMGroup(config_file=args.config_file, result_dir=args.result_dir,
                             blueprint=blueprint, topo=args.topo, image=args.image)
    start = time.monotonic()

    base_group.init()
    init_end = time.monotonic()
    print("init ", init_end-start)
    base_group.setup_netns()
    print("netns", time.monotonic()-init_end)
    base_group.setup_host_tap()
    network_setup_ts = time.monotonic()
    # base goroup
    base_group.start_all()
    if DEBUG:
        base_group.dump_all()
        base_group.dump_logs()
    print("start container")
    base_group.start_container()
    print("setup guest network")
    base_group.setup_guest_network()
    print("configure container")
    base_group.configure_container()
    boot_ts = time.monotonic()

    ok, converge_ts = base_group.wait_converge(timeout=360)
    # To collect more memory usage data
    time.sleep(4)
    collector.end()
    if not ok:
        do_cleanup()
        exit(1)
    stat = {
        "setup_network": network_setup_ts-start,
        "boot": boot_ts-network_setup_ts,
        "converge": converge_ts-boot_ts
    }
    base_group.dump_logs()
    base_group.dump_all()
    print(stat)
    print("done")
    do_cleanup()
    base_group.teardown_netns()
    base_group.dump_logs()

    with open(f"{args.result_dir}/stat.log", "w") as f:
        json.dump(stat, f)


def test_single_netns_fork(args):
    blueprint_path = f"./conf/{args.image}/{args.topo}/blueprint.json"
    with open(blueprint_path) as f:
        blueprint = json.load(f)

    base_vm = VMBase(0, config_file=args.config_file,
                     result_dirs=args.result_dir, blueprint=blueprint, image="crpd", topo=args.topo, use_vsock=True)
    profile_dirty = args.profile_dirty
    profile_cpu = args.profile_cpu
    if args.profile_dirty:
        dirty_profiler = DirtyMemoryProfiler(0.5, args.result_dir)

    if args.profile_cpu:
        cpu_profiler = CpuUsageProfiler(1, args.result_dir)

    # start timestamp
    base_vm.create_vm()

    if DEBUG:
        base_vm.dump_logs()

    base_vm.wait_ready()
    print("base vm is ready")
    init_start = time.monotonic()
    base_vm.copy_and_start_agent()

    base_vm.dump_logs()

    if args.mode == "share_all" or args.mode == "single_ns":
        print("start container in base vm")
        base_vm.start_container()

    init_end = time.monotonic()
    print("init time", init_end - init_start)

    # base_vm.load_base_config()
    # Warm up the machine
    print("warmup")
    safe_sleep(15)
    # time.sleep(10)

    base_vm.pause_vm()
    base_vm.snapshot_vm()
    collector = MemoryUsageCollector(args.result_dir, 1)

    num_normal_links, num_mgmt_links, num_unused = calculate_resource_demand(
        blueprint)

    pool = LinkPool(SHARED_NETNS, num_mgmt_links=num_mgmt_links, num_normal_links=num_normal_links,
                    result_dir=args.result_dir, num_unused_tap=num_unused)
    allocate_start = time.monotonic()
    pool.preallocate()
    allocate_end = time.monotonic()
    start = time.monotonic()
    collector.start()
    print("stop")

    group = SingleNamespaceForkedVMGroup(
        base_vm, blueprint, args.result_dir, topo=args.topo, image=args.image, pool=pool)

    group.init()
    t0 = time.monotonic()

    if profile_cpu:
        cpu_profiler.start()

    group.start_all()
    profile_ts = time.monotonic()

    print("profile ts", profile_ts-allocate_start)

    if profile_dirty:
        dirty_profiler.start()

    # group.dump_logs()
    # group.dump_all()
    t1 = time.monotonic()
    group.reset_mgmt()
    # group.dump_logs()
    # group.dump_all()
    t2 = time.monotonic()
    group.setup_guest_network()
    if args.mode == "single_ns_share_vm":
        group.start_container()

    # group.dump_logs()
    # group.dump_all()
    t3 = time.monotonic()
    group.configure_container()
    t4 = time.monotonic()
    print(t1-t0, t2-t1, t3-t2, t4-t3)
    resume_ts = time.monotonic()
    if profile_dirty:
        safe_sleep(30)
        dirty_profiler.end()
        # collector.end()
        # do_cleanup()
        # exit(0)

    if profile_cpu:
        safe_sleep(30)
        cpu_profiler.end()
    safe_sleep(30)

    collector.end()
    max_converge_time = 0
    for vm in group.vms:
        ok, ts = vm.get_latest_routes_ts()
        if not ok:
            print("not ok")
        if ts < 0:
            print(f"Warning not converge: vm idx={vm.vm_idx}")

        # print(ok, ts-resume_ts, vm.vm_idx)
        max_converge_time = max(max_converge_time, ts-resume_ts)
    print("final print result", max_converge_time)
    stat = {
        "resume": resume_ts-start,
        "converge": max_converge_time,
        "network": allocate_end - allocate_start
    }
    print(stat)
    group.dump_all()
    group.dump_logs()
    with open(f"{args.result_dir}/stat.log", "w") as f:
        json.dump(stat, f)

    print("sleep")
    safe_sleep(18000)

    do_cleanup()


def test_single_netns_no_fork(args):
    blueprint_path = f"./conf/{args.image}/{args.topo}/blueprint.json"

    if not os.path.exists(args.result_dir):
        os.mkdir(args.result_dir)

    with open(blueprint_path) as f:
        blueprint = json.load(f)

    collector = MemoryUsageCollector(args.result_dir, 1)
    profile_cpu = args.profile_cpu

    if profile_cpu:
        cpu_profiler = CpuUsageProfiler(1, args.result_dir)

    num_normal_links, num_mgmt_links, num_unused = calculate_resource_demand(
        blueprint)

    pool = LinkPool(SHARED_NETNS, num_mgmt_links=num_mgmt_links, num_normal_links=num_normal_links,
                    result_dir=args.result_dir, num_unused_tap=num_unused)
    allocate_start = time.monotonic()
    pool.preallocate()
    allocate_end = time.monotonic()
    start_ts = time.monotonic()
    collector.start()

    group = SingleNamespaceBaseVMGroup(
        pool, SHARED_NETNS, args.config_file, blueprint, args.result_dir, topo=args.topo, image=args.image)

    group.init()
    if profile_cpu:
        cpu_profiler.start()
    group.start_all()
    guest_os_boot_ts = time.monotonic()
    group.dump_all()
    group.dump_logs()
    guest_network_start = time.monotonic()
    group.setup_guest_network()
    guest_network_end = time.monotonic()
    print("guest network", guest_network_end-guest_network_start)
    group.start_container()
    config_agnostic_ts = time.monotonic()
    group.configure_container()

    boot_ts = time.monotonic()
    print("config agnostic", config_agnostic_ts-guest_os_boot_ts, "guest os",
          guest_os_boot_ts-start_ts, "config specific", boot_ts-config_agnostic_ts)
    group.dump_all()
    group.dump_logs()
    print("Waiting")

    collector.end()
    resume_ts = time.monotonic()
    max_converge_time = 0
    if profile_cpu:
        safe_sleep(30)
        cpu_profiler.end()

    time.sleep(60)

    print("check route")
    for vm in group.vms:
        ok, ts = vm.get_latest_routes_ts()

        max_converge_time = max(max_converge_time, ts-resume_ts)

    print(max_converge_time, "Done")

    stat = {"network": allocate_end-allocate_start,
            "boot": boot_ts-start_ts,
            "converge": max_converge_time,
            }
    with open(f"{args.result_dir}/stat.json", "w") as f:
        json.dump(stat, f)
    print(stat)
    do_cleanup()


REGISTRY = {
    "share_all": test_deploy_forked_vm,
    "share_none": test_no_vm_fork,
    "share_vm": test_deploy_forked_vm,
    "single_ns": test_single_netns_fork,
    "single_ns_no_fork": test_single_netns_no_fork,
    "single_ns_share_vm": test_single_netns_fork
}

if __name__ == "__main__":
    parser = argparse.ArgumentParser("run_vm")

    parser.add_argument("--config-file", type=str)
    parser.add_argument("--result-dir", type=str, default="result")
    parser.add_argument("--topo", type=str, default=None)
    parser.add_argument("--image", type=str, default=None)
    # fork / no fork / fork before create container
    parser.add_argument("--mode", default="share_all", type=str)
    parser.add_argument("--profile-dirty",
                        action="store_true",  default=False)
    parser.add_argument("--profile-cpu", action="store_true", default=False)
    args = parser.parse_args()

    # test_base_vm(args)

    # test_fork_one_vm(args=args)

    # test_fork_multiple_vm(args)

    # test_create_multiple_vm(args)

    # test_launch_speed(args)

    args.result_dir = f"{args.image}_{args.topo}_{args.mode}_result_mitigation"
    print("result directory is ", args.result_dir)
    func = REGISTRY[args.mode]
    assert args.mode in REGISTRY.keys()
    func(args)

    print("Done")
