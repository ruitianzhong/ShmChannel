#!/bin/bash
git clone git@github.com:firecracker-microvm/firecracker.git
wget https://github.com/firecracker-microvm/firecracker/releases/download/v1.14.1/firecracker-v1.14.1-x86_64.tgz
wget https://s3.amazonaws.com/spec.ccfc.min/firecracker-ci/v1.14/x86_64/vmlinux-6.1.155
wget -O ubuntu-24.04.squashfs.upstream https://s3.amazonaws.com/spec.ccfc.min/firecracker-ci/v1.14/x86_64/ubuntu-24.04.squashfs
wget -O ubuntu-24.04
wget -O ubuntu-24.04
sudo ln -s  `pwd`/release-v1.14.1-x86_64/firecracker-v1.14.1-x86_64 /usr/bin/firecracker 
git clone git@github.com:ants-xjtu/REAL-artifact-evaluation.git
git clone git@github.com:ruitianzhong/docker_net_emulation.git
unsquashfs ubuntu-24.04.squashfs
ssh-keygen -f id_rsa -N ""
cp -v id_rsa.pub squashfs-root/root/.ssh/authorized_keys
sudo chown -R root:root squashfs-root
truncate -s 512M ubuntu-base.ext4
sudo mkfs.ext4 -d squashfs-root -F ubuntu-base.ext4
e2fsck -fn ubuntu-base.ext4 

TAP_DEV="tap0"
TAP_IP="172.16.0.1"
MASK_SHORT="/30"

sudo ip link del "$TAP_DEV" 2> /dev/null || true
sudo ip tuntap add dev "$TAP_DEV" mode tap
sudo ip addr add "${TAP_IP}${MASK_SHORT}" dev "$TAP_DEV"
sudo ip link set dev "$TAP_DEV" up

ssh -i id_rsa root@172.16.0.2

python3.9 -m pip install networkx

# Load kernel module
sudo modprobe kvm_intel

# Configure packet forwarding
sudo sysctl -w net.ipv4.conf.all.forwarding=1

# Avoid "nf_conntrack: table full, dropping packet"
sudo sysctl -w net.ipv4.netfilter.ip_conntrack_max=99999999

# Avoid "neighbour: arp_cache: neighbor table overflow!"
sudo sysctl -w net.ipv4.neigh.default.gc_thresh1=1024
sudo sysctl -w net.ipv4.neigh.default.gc_thresh2=2048
sudo sysctl -w net.ipv4.neigh.default.gc_thresh3=4096

# Add CAP_NET_ADMIN to firecracker (for TUNSETIFF ioctl)
sudo setcap cap_net_admin=eip firecracker


bundle_dir="bundle"
rootfs_dir="$bundle_dir/rootfs"
image="busybox"
mkdir -p "$rootfs_dir" && (cd "$bundle_dir" && runc spec)
sudo docker export $(sudo docker create "$image") | tar -C "$rootfs_dir" -xvf -

docker save -o busybox.tar busybox

for name in $(sudo ip netns ls); do
sudo ip netns del "${name}"
done

for ((i=0;i<=245;i++));do sudo ip netns del vm_${i} ; done

for ((i=1;i<=5;i++)); do docker stop emu-real-${i} ; done
for ((i=1;i<=5;i++)); do docker rm emu-real-${i} ; done


sudo rm -f  v.sock && sudo rm -r  /tmp/vsock.sock
scp -i id_rsa ./docker_net_emulation/agent/server  root@172.16.0.2:/tmp  
sudo ip tuntap add dev tap1 mode tap 
sudo ip link set tap1 up
sudo rm v.sock /tmp/vsock.sock 
sudo python3.9 ./docker_net_emulation/example.py --result-dir=log --config-file=./docker_net_emulation/firecracker_config/vm_vsock.json
nohup /tmp/server >/tmp/server.log 2>&1 &
ssh  -o StrictHostKeyChecking=no  -i id_rsa root@172.16.0.6 ls
sudo ip netns del fork && sudo ip netns add fork && sudo rm -f pool.json
sudo python3.9 ./docker_net_emulation/run_vm.py --config-file=./docker_net_emulation/firecracker_config/vm_vsock.json  --image=crpd --topo=fattree2 --result-dir=result --mode=single_ns 

docker run -v ./REAL-artifact-evaluation:/REAL   -itd  --privileged --name ubuntu-real22 ubuntu:22.04 
sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1 &&sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
sysctl net.ipv6.conf.all.disable_ipv6 &&  sysctl net.ipv6.conf.default.disable_ipv6

sudo python3.9 ./docker_net_emulation/run_vm.py --config-file=./docker_net_emulation/firecracker_config/vm_vsock.json  --image=crpd --topo=fattree18 --result-dir=result --mode=single_ns 

sudo python3.9 ./docker_net_emulation/run_vm.py --config-file=./docker_net_emulation/firecracker_config/vm_crpd.json  --image=crpd --topo=fattree18 --result-dir=result --mode=single_ns_no_fork 
sudo ip netns exec fork bash -c 'sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1 &&sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1'
sudo python3.9 ./docker_net_emulation/run_vm.py --config-file=./docker_net_emulation/firecracker_config/vm_vsock.json  --image=crpd --topo=fattree2 --result-dir=result --mode=single_ns
sudo smem

pip install psutil matplotlib

./docker_net_emulation/confgen.py crpd topozoo Kdl
sudo smem -t -k -u -P firecracker 


#  tap setup
# Load kernel module
sudo modprobe kvm_intel

# Configure packet forwarding
sudo sysctl -w net.ipv4.conf.all.forwarding=1

# Avoid "nf_conntrack: table full, dropping packet"
sudo sysctl -w net.ipv4.netfilter.ip_conntrack_max=99999999

# Avoid "neighbour: arp_cache: neighbor table overflow!"
sudo sysctl -w net.ipv4.neigh.default.gc_thresh1=1024
sudo sysctl -w net.ipv4.neigh.default.gc_thresh2=2048
sudo sysctl -w net.ipv4.neigh.default.gc_thresh3=4096

# Add CAP_NET_ADMIN to firecracker (for TUNSETIFF ioctl)
sudo setcap cap_net_admin=eip firecracker



set -euo pipefail

SB_ID="${1:-0}" # Default to 0
TAP_DEV="fc-${SB_ID}-tap0"

# Setup TAP device that uses proxy ARP
MASK_SHORT="/30"
TAP_IP="$(printf '169.254.%s.%s' $(((4 * SB_ID + 2) / 256)) $(((4 * SB_ID + 2) % 256)))"

ip link del "$TAP_DEV" 2> /dev/null || true
ip tuntap add dev "$TAP_DEV" mode tap
sysctl -w net.ipv4.conf."$TAP_DEV".proxy_arp=1 > /dev/null
sysctl -w net.ipv6.conf."$TAP_DEV".disable_ipv6=1 > /dev/null
ip addr add "${TAP_IP}${MASK_SHORT}" dev "$TAP_DEV"
ip link set dev "$TAP_DEV" up


sudo python3.9 ./docker_net_emulation/virtcontainer.py --hypervisor_config=./docker_net_emulation/firecracker_config/vm_vxlan.json --output_dir=./emufork_log
for ((i=1;i<=4;i++));do sudo ip link del mgmt_$i ; done

# clean up NAT table
# For inter-vm communication
sudo iptables -t nat -F
sudo iptables -t nat -X
sudo iptables -t nat -L -n
sudo iptables -F FORWARD
sudo iptables -P FORWARD ACCEPT

sudo python3.9 ./docker_net_emulation/virtcontainer.py --hypervisor_config=./docker_net_emulation/firecracker_config/vm_vxlan.json --output_dir=./emufork_log --topo=fattree2 --containers_per_vm=1

# topology zoo Kdl
sudo python3.9 ./docker_net_emulation/virtcontainer.py --hypervisor_config=./docker_net_emulation/firecracker_config/vm_vxlan.json --output_dir=./emufork_log --topo=topozoo_Kdl --containers_per_vm=1 

# CloudHypervisor Shutdown !! Dangerous !!
# sudo shutdown -h now

qemu-img create -f qcow2 -b jammy-server-cloudimg-amd64.img -F qcow2 vm1.qcow2

wget https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img

echo 1 | sudo tee /proc/sys/vm/drop_caches
rm -r ./test_emufork/hypervisor


sudo ip tuntap add dev tap0 mode tap
sudo ip addr add 172.16.0.1/30 dev tap0
sudo ip link set tap0 up
# mem-merge=off mem-merge=on
 echo "KSM scan interval (sleep_millisecs):"; cat /sys/kernel/mm/ksm/sleep_millisecs 2>/dev/null; echo -e "\nPages to scan per interval:"; cat /sys/kernel/mm/ksm/pages_to_scan 2>/dev/null
 echo "KSM run status:"; cat /sys/kernel/mm/ksm/run 2>/dev/null; echo -e "\nInterpretation:"; if [ "$(cat /sys/kernel/mm/ksm/run 2>/dev/null)" = "1" ]; then echo "KSM is ENABLED and running"; elif [ "$(cat /sys/kernel/mm/ksm/run 2>/dev/null)" = "0" ]; then echo "KSM is DISABLED (stopped)"; else echo
      "Cannot determine KSM status"; fi
ls -la /sys/kernel/mm/ksm/ 2>/dev/null || echo "KSM not available"
# enable KSM
echo 1 | sudo tee /sys/kernel/mm/ksm/run
# check interval
 cat /sys/kernel/mm/ksm/sleep_millisecs
#  set interval
echo 100 | sudo tee /sys/kernel/mm/ksm/sleep_millisecs
# set page to scan
echo 200 | sudo tee /sys/kernel/mm/ksm/pages_to_scan
# check page to scan
cat /sys/kernel/mm/ksm/pages_to_scan

# KSM stat
for f in pages_shared pages_sharing pages_unshared pages_volatile; do echo -n "$f: "; cat /sys/kernel/mm/ksm/$f 2>/dev/null; done
echo -n "run: "; cat /sys/kernel/mm/ksm/run 2>/dev/null; echo -n ", full_scans: "; cat /sys/kernel/mm/ksm/full_scans 2>/dev/null
# VM 0
ip netns exec ns_0 ip addr add 192.168.0.2/24 dev eth1
ip netns exec ns_1 ip addr add 192.168.0.3/24 dev eth0

ip netns exec ns_0 ip addr add 192.168.1.2/24 dev eth2


# VM 1
ip netns exec ns_0 ip addr add 192.168.1.3/24 dev eth0