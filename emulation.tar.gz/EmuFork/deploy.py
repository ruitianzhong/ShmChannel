#!/bin/env python3
import argparse
import json
from runner import BirdBaseline, FrrBaseline, CrpdBaseline, UbuntuRunner
from runner import Runner
import os
import time
from check_bgp import check_bgp
from memory_metric import MemoryUsageCollector


REGISTRY = {
    ("crpd", "baseline"): CrpdBaseline,
    ("frr", "baseline"): FrrBaseline,
    ("bird", "baseline"): BirdBaseline,
    ("ubuntu", "baseline"): UbuntuRunner
}


def create_runner(args) -> Runner:
    topo = args.topo
    image = args.image
    mode = args.mode

    blueprint_path = f"./conf/{image}/{topo}/blueprint.json"

    with open(blueprint_path) as f:
        blueprint = json.load(f)
    # container name here
    runner: Runner = REGISTRY[(image, mode)](image, topo, blueprint)

    return runner


def prepare(args):
    if not os.path.exists(args.output_dir):
        os.mkdir(args.output_dir)
        print(f"Create directory {args.output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        "deploy", description="deploy a topolody via docker")
    parser.add_argument("--topo", type=str)
    parser.add_argument("--image", type=str)
    parser.add_argument("--mode", type=str, default="baseline")
    parser.add_argument("--output-dir", type=str, default="./log")

    args = parser.parse_args()
    args.output_dir = f"docker_{args.image}_{args.topo}"
    prepare(args)

    runner = create_runner(args)
    records = []
    try:
        mem_collector = MemoryUsageCollector(
            result_dir=args.output_dir, interval_sec=2)
        mem_collector.start()
        start = time.monotonic()
        records += runner.create_containers()
        print("boot done")
        boot_ts = time.monotonic()
        records += runner.create_network()
        network_ts = time.monotonic()
        print("network done")
        records += runner.start_daemons()

        with open(f"{args.output_dir}/runner.cmd", mode="w") as f:
            f.writelines([str(record) for record in records])
        print("wait to converge")
        time.sleep(60)

        records = []
        converged_ts = None
        print("Start to check log")
        if args.image not in ['ubuntu']:
            records += check_bgp(runner, f"{args.output_dir}/log")
            converged_ts = time.monotonic()
            with open(f"{args.output_dir}/runner.cmd", mode="a") as f:
                f.writelines([str(record) for record in records])

        stat = {
            "boot": boot_ts-start,
            "network": network_ts-boot_ts,
            "converge": converged_ts-network_ts if converged_ts else 0
        }
        print(stat)
        with open(f"{args.output_dir}/stat.log", "w") as f:
            json.dump(stat, f)
        mem_collector.end()
        print("Done")
        time.sleep(1200)
    except BaseException as e:
        print("Catch exception", e)

    finally:
        records += runner.stop_container()
        records += runner.remove_container()
        # it's safe to call end() twice
        mem_collector.end()
        print("Tear down all the containers")
