#!/bin/env python3
import time
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import subprocess


def run_command(cmd):
    for c in cmd:

        result = subprocess.run(
            c, capture_output=True, shell=True, text=True)
        if result.returncode != 0:
            print(c, result.stdout, result.stderr)
            return


def parallel_run_commands(cmds):
    with ThreadPoolExecutor() as executor:
        futures = []
        for cmd in cmds:
            future = executor.submit(run_command, cmd)
            futures.append(future)

        for result in as_completed(futures):
            pass
    # for cmd in cmds:
    #     run_command(cmd)


def create_vxlan_link_using_ip_command(config_file):
    with open(config_file) as f:
        config = json.load(f)

    num_links = config["num_links"]
    peerip = config["peerip"]
    mynic = config["mynic"]
    backbone_ns = "backbone"
    netns_list = config["netns"]
    subprocess.run(f"ip netns add {backbone_ns}", shell=True)
    cmds = []
    base_vni = 100

    for link_idx in range(num_links):
        veth_in = f"vi_{link_idx}"
        veth_out = f"vo_{link_idx}"
        vxlan = f"vxlan_{link_idx}"
        br_name = f"vx_br_{link_idx}"
        vid = link_idx+base_vni
        cmd = [
            f"ip link add {vxlan} type vxlan id {vid} dev {mynic} dstport 4789 remote {peerip} learning",
            f"ip link set {vxlan} up",
            f"ip link set {vxlan} netns {backbone_ns}",
            f"ip netns exec {backbone_ns} ip link add {br_name} type bridge",
            f"ip link add {veth_in} type veth peer name {veth_out}",
            f"ip link set {veth_in} netns {netns_list[link_idx]}",
            f"ip link set {veth_out} netns {backbone_ns}",
            f"ip netns exec {backbone_ns} ip link set {vxlan} master {br_name}",
            f"ip netns exec {backbone_ns} ip link set {vxlan} up",
            f"ip netns exec {backbone_ns} ip link set {veth_out} master {br_name}",
            f"ip netns exec {backbone_ns} ip link set {br_name} up",
            f"ip netns exec {backbone_ns} ip link set {veth_out} up",
            f"ip netns exec {netns_list[link_idx]} ip link set {veth_in} up",
        ]
        cmds.append(cmd)

    parallel_run_commands(cmds)


def dump_config_file(args):

    config = {}
    num_links = args.num_links

    for link_idx in range(num_links):
        subprocess.run(
            f"ip netns del vxlan_{link_idx}", shell=True, capture_output=True)
    netns = []
    for link_idx in range(num_links):
        result = subprocess.run(
            f"ip netns add vxlan_{link_idx}", shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"linkidx_{result.returncode}", result.stdout, result.stderr)
        netns.append(f"vxlan_{link_idx}")

    config["netns"] = netns
    config["peerip"] = args.peer_ip
    config["mynic"] = args.my_nic
    config["num_links"] = num_links

    with open("/tmp/vxlan.json", "w") as f:
        json.dump(config, f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser("vxlan benchmark")

    parser.add_argument("--my-ip", type=str)
    parser.add_argument("--peer-ip", type=str)
    parser.add_argument("--my-nic", type=str)

    parser.add_argument("--num_links", type=int)
    parser.add_argument(
        "--mode", choices=["naive", "per_netns", "splitnn", "naive_ip"], default="naive")

    args = parser.parse_args()

    dump_config_file(args)

    start = time.monotonic()

    if args.mode != "naive_ip":

        result = subprocess.run(f"./fastlink vxlan /tmp/vxlan.json {args.mode}",
                                text=True, shell=True, capture_output=True)
        print("stdout", result.stdout)
        print("stderr", result.stderr)
    else:
        create_vxlan_link_using_ip_command("/tmp/vxlan.json")

    end = time.monotonic()

    print("Total time", end-start)

    print("Go to sleep")

    try:
        time.sleep(1800)
    except BaseException as e:
        print(e, "Catch")

    for link_idx in range(args.num_links):
        subprocess.run(
            f"ip netns del vxlan_{link_idx}", shell=True, text=True, capture_output=True)

    subprocess.run(f"ip netns del backbone", shell=True)
    subprocess.run(
        f"ip netns list | grep 'backbone' | awk '{{print $1}}' | xargs -r ip netns delete", shell=True)

    print("Done!")
