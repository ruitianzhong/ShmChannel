package main

// import "C"

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"runtime"
	"strconv"
	"syscall"
	"time"

	"github.com/vishvananda/netlink"
	"github.com/vishvananda/netns"
)

var VXLAN_ID_START = 100
var LINK_PER_BACKBONE = 200

var g_ip_map map[string]bool = make(map[string]bool)

func create_network(blueprint map[string]any, parallel int) {
	var threadPool *ThreadPool
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	if parallel > 1 {
		threadPool = NewThreadPool(parallel)
		threadPool.Run()
	}

	routers, ok := blueprint["routers"].([]interface{})
	if !ok {
		log.Fatalf("Can not parse routers")
	}
	handles := get_netns_handles(blueprint)

	for _, router := range routers {
		router_m := router.(map[string]any)
		idx1 := int(router_m["idx"].(float64))
		handle1 := handles[idx1-1]

		neighbors := router_m["neighbors"].([]any)

		for _, neighbor := range neighbors {
			neighbor := neighbor.(map[string]any)
			idx2 := int(neighbor["peeridx"].(float64))
			if idx1 > idx2 {
				continue
			} else if idx1 == idx2 {
				panic("Unexpected")
			}

			handle2 := handles[idx2-1]

			veth1 := neighbor["ifname"].(string)
			veth2 := neighbor["peerifname"].(string)

			ip1 := neighbor["self_ip"].(string)
			ip2 := neighbor["neighbor_ip"].(string)

			prefix_len1 := int(neighbor["selfip_prefixlen"].(float64))
			prefix_len2 := int(neighbor["peerip_prefixlen"].(float64))

			full_ip1 := fmt.Sprintf("%s/%d", ip1, prefix_len1)
			full_ip2 := fmt.Sprintf("%s/%d", ip2, prefix_len2)

			if g_ip_map[full_ip1] || g_ip_map[full_ip2] {
				panic("dup")
			}

			g_ip_map[full_ip1] = true
			g_ip_map[full_ip2] = true

			addr1, err := netlink.ParseAddr(full_ip1)
			if err != nil {
				log.Fatalf("addr %s have errors:%s", full_ip1, err)
			}

			addr2, err := netlink.ParseAddr(full_ip2)

			if err != nil {
				log.Fatalf("addr %s have errors: %s", full_ip2, err)
			}
			if parallel > 1 {
				threadPool.AddTask(
					func(args ...any) error {
						return create_link_internal(handle1, handle2, veth1, veth2, addr1, addr2)
					})
			} else {
				if err := create_link_internal(handle1, handle2, veth1, veth2, addr1, addr2); err != nil {
					fmt.Printf("err: %s\n", err)
				}

			}
		}
	}

	if parallel > 1 {
		threadPool.Wait()
		if threadPool.hasError {
			for err := range threadPool.errors {
				fmt.Printf("Error: %s", err)
			}
		}
	}

}

func get_netns_handles(blueprint map[string]any) []netns.NsHandle {
	var handles []netns.NsHandle

	netns_list, ok := blueprint["netns"].([]any)

	if !ok {
		log.Fatalf("netns does not exist")
	}

	for _, ns := range netns_list {
		switch v := ns.(type) {
		case float64:
			handle, err := netns.GetFromPid(int(v))
			if err != nil {
				log.Fatalf("Failed to get netns handle from pid: %s", err)
			}
			handles = append(handles, handle)

		case string:
			handle, err := netns.GetFromName(v)
			if err != nil {
				log.Fatalf("Failed to get netns handle from name: %s", err)
			}
			handles = append(handles, handle)
		default:
			fmt.Printf("%T\n", v)
			panic("Unexpected result")
		}

	}

	return handles

}

func create_link_internal(netns1, netns2 netns.NsHandle, veth1_name, veth2_name string, ip1, ip2 *netlink.Addr) error {
	orig, err := netns.Get()
	if err != nil {
		return fmt.Errorf("failed to get netns: %s", err)
	}

	netns.Set(netns1)

	veth1 := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  veth1_name,
			MTU:   1450,
			Flags: net.FlagUp,
			Group: 1,
			// MasterIndex: br.Index,
		},
		PeerName:      veth2_name,
		PeerNamespace: netlink.NsFd(netns2),
	}

	veth2 := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  veth2_name,
			Group: 1,
		},
	}
	if err := netlink.LinkAdd(veth1); err != nil {
		return fmt.Errorf("failed to add link: %s", err)
	}

	if err := netlink.AddrAdd(veth1, ip1); err != nil {
		return fmt.Errorf("failed to add addr ip1=%s for %s: %s", ip1, veth1_name, err)
	}

	veth1_link, err := netlink.LinkByName(veth1_name)

	if err != nil {
		return fmt.Errorf("failed to get veth1: %s", err)
	}

	mac1 := veth1_link.Attrs().HardwareAddr

	if len(mac1) == 0 {
		return fmt.Errorf("failed to get mac1")
	}

	if err := netns.Set(netns2); err != nil {
		return fmt.Errorf("failed to set netns: %s", err)
	}

	if err := netlink.LinkSetUp(veth2); err != nil {
		return fmt.Errorf("failed to setup veth2 %s : %s", veth2_name, err)
	}

	if err := netlink.AddrAdd(veth2, ip2); err != nil {
		return fmt.Errorf("failed to add addr ip2=%s for %s: %s", ip2, veth2_name, err)
	}

	veth2_link, err := netlink.LinkByName(veth2_name)

	if err != nil {
		return fmt.Errorf("failed to get veth2: %s", err)
	}

	mac2 := veth2_link.Attrs().HardwareAddr

	if len(mac2) == 0 {
		return fmt.Errorf("failed to get mac2")
	}

	neigh1 := &netlink.Neigh{
		LinkIndex:    veth1_link.Attrs().Index,
		IP:           ip2.IP,
		HardwareAddr: mac2,
		State:        netlink.NUD_PERMANENT,
		Family:       syscall.AF_INET,
	}

	neigh2 := &netlink.Neigh{
		LinkIndex:    veth2_link.Attrs().Index,
		IP:           ip1.IP,
		HardwareAddr: mac1,
		State:        netlink.NUD_PERMANENT,
		Family:       syscall.AF_INET,
	}

	if err := netlink.NeighSet(neigh2); err != nil {
		return fmt.Errorf("failed to set neigh2: %s", err)
	}

	if err := netns.Set(netns1); err != nil {
		return fmt.Errorf("Failed to set netns1: %s", err)
	}

	if err := netlink.NeighSet(neigh1); err != nil {
		return fmt.Errorf("failed to set neigh1: %s", err)
	}

	if err := netns.Set(orig); err != nil {
		return fmt.Errorf("Failed to set netns: %s", err)
	}

	return nil
}

func get_netns_handle_pid_or_name(netns_list []any) []netns.NsHandle {
	var handles []netns.NsHandle

	for _, ns := range netns_list {
		switch v := ns.(type) {
		case float64:
			handle, err := netns.GetFromPid(int(v))
			if err != nil {
				log.Fatalf("Failed to get netns handle from pid: %s", err)
			}
			handles = append(handles, handle)

		case string:
			handle, err := netns.GetFromName(v)
			if err != nil {
				log.Fatalf("Failed to get netns handle from name: %s", err)
			}
			handles = append(handles, handle)
		default:
			fmt.Printf("%T\n", v)
			panic("Unexpected result")
		}

	}

	return handles
}

func create_external_network_splitnn(peerip net.IP, num_links int, nic_link *netlink.Link, netns_handles []netns.NsHandle) error {
	host_ns, err := netns.Get()

	if err != nil {
		return fmt.Errorf("Failed to get original netns:%v", err)
	}

	if err := netns.Set(host_ns); err != nil {
		return fmt.Errorf("Failed to set orig netns: %v", err)
	}
	var backbone_handle netns.NsHandle
	for link_idx := range num_links {

		if (link_idx+LINK_PER_BACKBONE)%LINK_PER_BACKBONE == 0 {
			backbone_name := fmt.Sprintf("backbone_%v", link_idx/LINK_PER_BACKBONE)
			backbone_handle, err = netns.NewNamed(backbone_name)
			if err != nil {
				return fmt.Errorf("Failed to create backbone netns %s: %v", backbone_name, err)
			}
		}

		vxlanName := fmt.Sprintf("vxlan_%v", link_idx)
		vxlanID := VXLAN_ID_START + link_idx
		vethOutName := fmt.Sprintf("vo_%v", link_idx)
		brName := fmt.Sprintf("vx_br_%v", link_idx)
		vethInName := fmt.Sprintf("vi_%v", link_idx)

		vxlan := &netlink.Vxlan{
			LinkAttrs: netlink.LinkAttrs{
				Name: vxlanName,
			},
			VxlanId:      vxlanID,
			VtepDevIndex: (*nic_link).Attrs().Index,
			Port:         4789,
			Group:        peerip,
			Learning:     true,
		}

		vethOuti := &netlink.Veth{
			LinkAttrs: netlink.LinkAttrs{
				Name:  vethOutName,
				MTU:   1450,
				Flags: net.FlagUp,
			},
			PeerName:      vethInName,
			PeerNamespace: netlink.NsFd(netns_handles[link_idx]),
		}
		vethIni := &netlink.Veth{
			LinkAttrs: netlink.LinkAttrs{
				Name: vethInName,
			},
		}

		br := &netlink.Bridge{
			LinkAttrs: netlink.LinkAttrs{
				Name:  brName,
				MTU:   1450,
				Flags: net.FlagUp,
			},
		}

		if err := netns.Set(host_ns); err != nil {
			return fmt.Errorf("Failed to set host netns: %v", err)
		}

		err = netlink.LinkAdd(vxlan)

		if err != nil {
			return fmt.Errorf("Failed to add vxlan: %v", err)
		}

		if err = netlink.LinkSetNsFd(vxlan, int(backbone_handle)); err != nil {
			return fmt.Errorf("failed to move link to netns: %s", err)
		}

		if err := netns.Set(backbone_handle); err != nil {
			return fmt.Errorf("failed to set backbone netns:%s", err)
		}

		if err := netlink.LinkAdd(br); err != nil {
			return fmt.Errorf("failed to create bridge: %s", err)
		}
		vethOuti.Attrs().MasterIndex = br.Index
		if err := netlink.LinkAdd(vethOuti); err != nil {
			return fmt.Errorf("failed to create veth in backbone netns: %s", err)

		}

		var newVxlan netlink.Link
		newVxlan, err = netlink.LinkByName(vxlanName)
		if err != nil {
			return fmt.Errorf("failed to LinkByName: %s", err)
		}

		err = netlink.LinkSetMaster(newVxlan, br)

		if err != nil {
			return fmt.Errorf("Failed to set vxlan master: %s", err)
		}

		if err := netlink.LinkSetUp(newVxlan); err != nil {
			return fmt.Errorf("Failed to set up vxlan: %s", err)
		}

		if err := netns.Set(netns_handles[link_idx]); err != nil {
			return fmt.Errorf("Failed to set to node netns: %s", err)
		}

		if err := netlink.LinkSetUp(vethIni); err != nil {
			return fmt.Errorf("Failed to set veth_in up: %s", err)
		}

	}
	if err := netns.Set(host_ns); err != nil {
		return fmt.Errorf("Failed to set orig netns: %v", err)
	}

	return nil
}

// use bridge to connected two namespace
func create_one_internal_link(netns1, netns2, linkidx int, ip1, ip2 net.IP, ifname1, ifname2 string) error {

	// Get original namespace
	orig, err := netns.Get()
	if err != nil {
		log.Fatalf("failed to get netns: %s", err)
	}

	ns1_handle, err := netns.GetFromPid(netns1)
	if err != nil {
		log.Fatalf("failed to get netns handle from pid %d: %s", netns1, err)
	}
	ns2_handle, err := netns.GetFromPid(netns2)
	if err != nil {
		log.Fatalf("failed to get netns handle from pid %d: %s", netns1, err)
	}

	brName := "br-" + strconv.Itoa(linkidx)
	veth1_out := "v1_" + strconv.Itoa(linkidx)
	veth2_out := "v2_" + strconv.Itoa(linkidx)

	br := &netlink.Bridge{
		LinkAttrs: netlink.LinkAttrs{
			Name:  brName,
			MTU:   1450,
			Flags: net.FlagUp,
			Group: 1,
		},
	}
	vethOuti := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  veth1_out,
			MTU:   1450,
			Flags: net.FlagUp,
			Group: 1,
			// MasterIndex: br.Index,
		},
		PeerName:      ifname1,
		PeerNamespace: netlink.NsFd(ns1_handle),
	}
	vethOutj := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  veth2_out,
			MTU:   1450,
			Flags: net.FlagUp,
			Group: 1,
			// MasterIndex: br.Index,
		},
		PeerName:      ifname2,
		PeerNamespace: netlink.NsFd(ns2_handle),
	}
	vethIni := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  ifname1,
			Group: 1,
		},
	}
	vethInj := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  ifname2,
			Group: 1,
		},
	}

	/* Create a bridge and two veth pairs */
	if err := netlink.LinkAdd(br); err != nil {
		return fmt.Errorf("failed to create bridge: %s", err)
	}
	vethOuti.Attrs().MasterIndex = br.Index
	err = netlink.LinkAdd(vethOuti)
	if err != nil {
		return fmt.Errorf("failed to create veth: %s", err)
	}
	vethOutj.Attrs().MasterIndex = br.Index
	err = netlink.LinkAdd(vethOutj)
	if err != nil {
		return fmt.Errorf("failed to create veth: %s", err)
	}

	/* Set the other sides of veths up */
	err = netns.Set(ns1_handle)
	if err != nil {
		return fmt.Errorf("failed to netns.Set: %s", err)
	}
	err = netlink.LinkSetUp(vethIni)
	if err != nil {
		return fmt.Errorf("failed to LinkSetUp: %s", err)
	}
	err = netns.Set(ns2_handle)
	if err != nil {
		return fmt.Errorf("failed to netns.Set: %s", err)
	}
	err = netlink.LinkSetUp(vethInj)
	if err != nil {
		return fmt.Errorf("failed to LinkSetUp: %s", err)
	}

	/* Set NetNs Back */
	err = netns.Set(orig)
	if err != nil {
		return fmt.Errorf("failed to netns.Set: %s", err)
	}
	return nil

}

// use vxlan
func create_one_external_link(netns_pid, linkidx, vid int, router_ip, remote_ip net.IP, router_ifname string, nic_link *netlink.Link) error {

	// Get original namespace
	orig, err := netns.Get()
	if err != nil {
		log.Fatalf("failed to get netns: %s", err)
	}

	// Get netns handle from PID
	handle, err := netns.GetFromPid(netns_pid)
	if err != nil {
		log.Fatalf("failed to get netns handle from pid %d: %s", netns_pid, err)
	}

	vxlanName := fmt.Sprintf("vxlan_%v", linkidx)
	vxlanID := vid
	vethOutName := fmt.Sprintf("vo_%v", linkidx)
	brName := fmt.Sprintf("vx_br_%v", linkidx)
	vethInName := router_ifname

	vxlan := &netlink.Vxlan{
		LinkAttrs: netlink.LinkAttrs{
			Name: vxlanName,
		},
		VxlanId:      vxlanID,
		VtepDevIndex: (*nic_link).Attrs().Index,
		Port:         4789,
		Group:        remote_ip,
		Learning:     true,
	}

	vethOuti := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name:  vethOutName,
			MTU:   1450,
			Flags: net.FlagUp,
		},
		PeerName:      vethInName,
		PeerNamespace: netlink.NsFd(handle),
	}
	vethIni := &netlink.Veth{
		LinkAttrs: netlink.LinkAttrs{
			Name: vethInName,
		},
	}

	br := &netlink.Bridge{
		LinkAttrs: netlink.LinkAttrs{
			Name:  brName,
			MTU:   1450,
			Flags: net.FlagUp,
		},
	}

	if err := netns.Set(orig); err != nil {
		return fmt.Errorf("Failed to set host netns: %v", err)
	}

	err = netlink.LinkAdd(vxlan)

	if err := netlink.LinkAdd(br); err != nil {
		return fmt.Errorf("failed to create bridge: %s", err)
	}
	vethOuti.Attrs().MasterIndex = br.Index
	if err := netlink.LinkAdd(vethOuti); err != nil {
		return fmt.Errorf("failed to create veth in backbone netns: %s", err)

	}

	var newVxlan netlink.Link
	newVxlan, err = netlink.LinkByName(vxlanName)
	if err != nil {
		return fmt.Errorf("failed to LinkByName: %s", err)
	}

	err = netlink.LinkSetMaster(newVxlan, br)

	if err != nil {
		return fmt.Errorf("Failed to set vxlan master: %s", err)
	}

	if err := netlink.LinkSetUp(newVxlan); err != nil {
		return fmt.Errorf("Failed to set up vxlan: %s", err)
	}

	if err := netns.Set(handle); err != nil {
		return fmt.Errorf("Failed to set to node netns: %s", err)
	}

	if err := netlink.LinkSetUp(vethIni); err != nil {
		return fmt.Errorf("Failed to set veth_in up: %s", err)
	}

	// Restore original namespace
	if err := netns.Set(orig); err != nil {
		log.Fatalf("failed to set original netns: %s", err)
	}

	return nil
}

func create_external_network_backbone_ns(peerip net.IP, num_links int, nic_link *netlink.Link, netns_handles []netns.NsHandle) error {

	host_ns, err := netns.Get()

	if err != nil {
		return fmt.Errorf("Failed to get original netns:%v", err)
	}

	backbone_handle, err := netns.NewNamed("backbone")
	if err != nil {
		return fmt.Errorf("Failed to create backbone netns: %v", err)
	}

	if err := netns.Set(host_ns); err != nil {
		return fmt.Errorf("Failed to set orig netns: %v", err)
	}

	for link_idx := range num_links {

		vxlanName := fmt.Sprintf("vxlan_%v", link_idx)
		vxlanID := VXLAN_ID_START + link_idx
		vethOutName := fmt.Sprintf("vo_%v", link_idx)
		brName := fmt.Sprintf("vx_br_%v", link_idx)
		vethInName := fmt.Sprintf("vi_%v", link_idx)

		vxlan := &netlink.Vxlan{
			LinkAttrs: netlink.LinkAttrs{
				Name: vxlanName,
			},
			VxlanId:      vxlanID,
			VtepDevIndex: (*nic_link).Attrs().Index,
			Port:         4789,
			Group:        peerip,
			Learning:     true,
		}

		vethOuti := &netlink.Veth{
			LinkAttrs: netlink.LinkAttrs{
				Name:  vethOutName,
				MTU:   1450,
				Flags: net.FlagUp,
			},
			PeerName:      vethInName,
			PeerNamespace: netlink.NsFd(netns_handles[link_idx]),
		}
		vethIni := &netlink.Veth{
			LinkAttrs: netlink.LinkAttrs{
				Name: vethInName,
			},
		}

		br := &netlink.Bridge{
			LinkAttrs: netlink.LinkAttrs{
				Name:  brName,
				MTU:   1450,
				Flags: net.FlagUp,
			},
		}

		if err := netns.Set(host_ns); err != nil {
			return fmt.Errorf("Failed to set host netns: %v", err)
		}

		err = netlink.LinkAdd(vxlan)

		if err != nil {
			return fmt.Errorf("Failed to add vxlan: %v", err)
		}

		if err = netlink.LinkSetNsFd(vxlan, int(backbone_handle)); err != nil {
			return fmt.Errorf("failed to move link to netns: %s", err)
		}

		if err := netns.Set(backbone_handle); err != nil {
			return fmt.Errorf("failed to set backbone netns:%s", err)
		}

		if err := netlink.LinkAdd(br); err != nil {
			return fmt.Errorf("failed to create bridge: %s", err)
		}
		vethOuti.Attrs().MasterIndex = br.Index
		if err := netlink.LinkAdd(vethOuti); err != nil {
			return fmt.Errorf("failed to create veth in backbone netns: %s", err)

		}

		var newVxlan netlink.Link
		newVxlan, err = netlink.LinkByName(vxlanName)
		if err != nil {
			return fmt.Errorf("failed to LinkByName: %s", err)
		}

		err = netlink.LinkSetMaster(newVxlan, br)

		if err != nil {
			return fmt.Errorf("Failed to set vxlan master: %s", err)
		}

		if err := netlink.LinkSetUp(newVxlan); err != nil {
			return fmt.Errorf("Failed to set up vxlan: %s", err)
		}

		if err := netns.Set(netns_handles[link_idx]); err != nil {
			return fmt.Errorf("Failed to set to node netns: %s", err)
		}

		if err := netlink.LinkSetUp(vethIni); err != nil {
			return fmt.Errorf("Failed to set veth_in up: %s", err)
		}

	}
	if err := netns.Set(host_ns); err != nil {
		return fmt.Errorf("Failed to set orig netns: %v", err)
	}

	return nil
}

func create_external_network(config map[string]any, mode string) error {

	num_links := int(config["num_links"].(float64))

	peerip := config["peerip"].(string)
	nic_name := config["mynic"].(string)

	netns_handles := get_netns_handle_pid_or_name(config["netns"].([]any))

	nic_link, err := netlink.LinkByName(nic_name)

	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	if err != nil {
		return fmt.Errorf("Failed to get NIC %v: %v", nic_name, err)
	}

	switch mode {
	case "naive":
		return create_external_network_backbone_ns(net.ParseIP(peerip), num_links, &nic_link, netns_handles)
	case "splitnn":
		return create_external_network_splitnn(net.ParseIP(peerip), num_links, &nic_link, netns_handles)
	}

	return fmt.Errorf("Unsupported mode %v", mode)

}

func create_in_network_vm(config map[string]any) {
	runtime.LockOSThread()

	defer runtime.UnlockOSThread()

	start := time.Now()

	nic_link, err := netlink.LinkByName("eth0")

	if err != nil {
		fmt.Printf("Can not find eth0")
		os.Exit(1)
	}

	meta_arr := config["meta"].([]any)

	for _, meta_any := range meta_arr {
		meta := meta_any.(map[string]any)

		net_type := meta["type"].(string)
		var err error
		switch net_type {
		case "internal":
			peer1, peer2 := meta["peer1"].(map[string]any), meta["peer2"].(map[string]any)
			peer1_netns := int(peer1["netns"].(float64))
			ip1, ip2 := net.ParseIP(peer1["ip"].(string)), net.ParseIP(peer2["ip"].(string))
			peer2_netns := int(peer2["netns"].(float64))
			linkidx := int(meta["linkidx"].(float64))
			ifname1, ifname2 := peer1["ifname"].(string), peer2["ifname"].(string)
			err = create_one_internal_link(peer1_netns, peer2_netns, linkidx, ip1, ip2, ifname1, ifname2)

		case "external":
			linkidx := int(meta["linkidx"].(float64))
			vid := int(meta["vid"].(float64))
			netns := int(meta["netns"].(float64))
			ifname := meta["ifname"].(string)
			ip := net.ParseIP(meta["ip"].(string))
			remote_ip := net.ParseIP(meta["remote_ip"].(string))
			err = create_one_external_link(netns, linkidx, vid, ip, remote_ip, ifname, &nic_link)

		}
		if err != nil {
			fmt.Printf("Failed to create nic")
			os.Exit(1)
		}
	}
	elapsed := time.Since(start)

	fmt.Printf("SUCCEED\n")
	fmt.Printf("It takes %v seconds\n", elapsed.Seconds())

}

func main() {
	if len(os.Args) < 3 {
		fmt.Println("./fastlink <blueprint file path> <parallel> [mode]")
		os.Exit(1)
	}

	if len(os.Args) > 3 {
		submodule := os.Args[1]

		switch submodule {
		case "vxlan":
			mode := os.Args[3]
			configPath := os.Args[2]

			configFile, err := os.ReadFile(configPath)

			if err != nil {
				fmt.Printf("Failed to read conf %v\n", err)
				os.Exit(1)
			}

			var config map[string]any

			if err := json.Unmarshal(configFile, &config); err != nil {
				fmt.Printf("json unmarshal %v\n", err)
				os.Exit(1)
			}
			if err := create_external_network(config, mode); err != nil {
				fmt.Printf("Create external network failed: %v", err)
				os.Exit(1)
			}
		case "vm-network":
			configPath := os.Args[2]
			placeholder := os.Args[3]
			if placeholder != "placeholder" {
				fmt.Printf("Unexpected placeholder %v\n", placeholder)
			}
			configFile, err := os.ReadFile(configPath)

			if err != nil {
				fmt.Printf("Failed to read conf %v\n", err)
				os.Exit(1)
			}

			var config map[string]any
			if err := json.Unmarshal(configFile, &config); err != nil {
				fmt.Printf("json unmarshal %v\n", err)
				os.Exit(1)
			}

			create_in_network_vm(config)

		}

		return
	}

	configPath := os.Args[1]
	parallel, err := strconv.Atoi(os.Args[2])

	if err != nil {
		fmt.Printf("Illegal number %v", os.Args[2])
	}

	configFile, err := os.ReadFile(configPath)

	if err != nil {
		fmt.Printf("Failed to read conf %v\n", err)
		os.Exit(1)
	}

	var blueprint map[string]any

	if err := json.Unmarshal(configFile, &blueprint); err != nil {
		fmt.Printf("json.Unmarshal %v", err)
		os.Exit(1)
	}

	start := time.Now()
	create_network(blueprint, parallel)
	elapse := time.Since(start)

	fmt.Printf("elapsed %f", elapse.Seconds())
}
