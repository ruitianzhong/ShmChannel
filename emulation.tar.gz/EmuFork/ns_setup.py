import subprocess


def debug_run_comamnd(cmd):
    result = subprocess.run(cmd, shell=True, capture_output=False, text=True)

    if result.returncode != 0:
        print(cmd)
        raise "return code non zero"


TAP_DEV = "tap0"
TAP_IP = "172.16.0.1"
MASK_SHORT = "/30"


def create_netns(netns):
    debug_run_comamnd(f"ip netns del {netns} || true")
    debug_run_comamnd(f"ip netns add {netns}")


def setup_mgmt(netns, tap):
    debug_run_comamnd(
        f"ip netns exec {netns} ip tuntap add dev {tap} mode tap")

    debug_run_comamnd(
        f"ip netns exec {netns} ip link set {tap} up"
    )
    debug_run_comamnd(
        f"ip netns exec {netns} ip addr add {TAP_IP}{MASK_SHORT} dev {tap}")


def prepare_one_side(netns, tap):

    cmds = [
        f"ip netns exec {netns} ip tuntap add dev {tap} mode tap",
        f"ip netns exec {netns} ip link set {tap} up",
        f"ip netns exec {netns} ip link add br-{tap} type bridge",
        f"ip netns exec {netns} ip link set {tap} master br-{tap}",
        f"ip netns exec {netns} ip link set veth-{netns}-{tap} master br-{tap}",
        f"ip netns exec {netns} ip link set br-{tap} up",
        f"ip netns exec {netns} ip link set veth-{netns}-{tap} up",
    ]

    for cmd in cmds:
        debug_run_comamnd(cmd)


def connect_tap(ns0, tap0, ns1, tap1):
    cmds = [f"ip link add veth-{ns0}-{tap0} type veth peer name veth-{ns1}-{tap1}",
            f"ip link set veth-{ns0}-{tap0} netns {ns0}",
            f"ip link set veth-{ns1}-{tap1} netns {ns1}"]

    for cmd in cmds:
        debug_run_comamnd(cmd)

    prepare_one_side(ns0, tap0)
    prepare_one_side(ns1, tap1)


if __name__ == "__main__":
    create_netns("vm1")
    create_netns("vm0")

    connect_tap("vm0", "tap1", "vm1", "tap1")

    setup_mgmt("vm0", "tap0")
    setup_mgmt("vm1", "tap0")

# sudo rm /tmp/vm0.sock &&  sudo ip netns exec vm0  firecracker --api-sock /tmp/vm0.sock --config-file ./docker_net_emulation/firecracker_config/vm0.json
#
