import time
from memory_metric import MemoryMonitor
from run_vm import VMBase, VMForked, safe_sleep, VMForkedWithVsock
import argparse


def test_fork_multiple_vm(args):
    num_forked_vm = 20
    stride = 2
    assert num_forked_vm % stride == 0
    base_vm = VMBase(num_forked_vm, config_file=args.config_file,
                     result_dirs=args.result_dir)
    mem_monitor = MemoryMonitor(args.result_dir)
    result_dir = args.result_dir

    base_vm.create_vm()
    time.sleep(10)
    base_vm.pause_vm()
    base_vm.snapshot_vm()

    # Snapshot done!
    # begin to fork vm
    forked_vms = []
    x = []

    num_cur_vm = 0

    for _ in range(num_forked_vm//stride):
        for vm_idx in range(stride):
            forked_vm = VMForked(
                num_cur_vm+vm_idx, result_dir, from_vm=base_vm)
            forked_vms.append(forked_vm)

            forked_vm.create_vm()
            forked_vm.fork()
            forked_vm.dump_logs()

        num_cur_vm += stride
        x.append(num_cur_vm)
        time.sleep(2)

        mem_used = mem_monitor.collect()
        print(f"Number of VM:{num_cur_vm} MemUsed:{mem_used} GiB")

    mem_monitor.dump_log()

    base_vm.resume_vm()

    safe_sleep(360)
    for forked_vm in forked_vms:
        forked_vm.shutdown_vm_gracefully()
        forked_vm.dump_logs()
    base_vm.shutdown_vm_gracefully()
    base_vm.dump_logs()


def test_base_vm(args):
    results_dir = "./test"
    if not os.path.exists(results_dir):
        os.mkdir(results_dir)

    base_vm = VMBase(0, config_file=args.config_file,
                     result_dirs=results_dir)

    base_vm.create_vm()

    base_vm.dump_logs()
    time.sleep(10)

    record = base_vm.pause_vm()
    base_vm.dump_logs()
    assert record.rc == 0

    record = base_vm.snapshot_vm()
    base_vm.dump_logs()
    assert record.rc == 0

    record = base_vm.resume_vm()
    assert record.rc == 0
    base_vm.dump_logs()

    safe_sleep(1000)

    record = base_vm.shutdown_vm_gracefully()

    base_vm.dump_logs()

    assert record.rc == 0

    print("Test base vm done!")


def test_fork_one_vm(args):
    result_dir = args.result_dir

    base_vm = VMBase(0, config_file=args.config_file,
                     result_dirs=args.result_dir)

    base_vm.create_vm()
    time.sleep(5)
    base_vm.pause_vm()
    base_vm.snapshot_vm()
    base_vm.resume_vm()

    base_vm.dump_logs()
    print("Base vm done")
    safe_sleep(360)
    forked_vm = VMForked(1, results_dir=result_dir, from_vm=base_vm)
    forked_vm.create_vm()
    time.sleep(1)
    forked_vm.dump_logs()

    forked_vm.fork()

    forked_vm.dump_logs()
    print("fork done")
    safe_sleep(1800)

    forked_vm.shutdown_vm_gracefully()
    base_vm.shutdown_vm_gracefully()


def test_create_multiple_vm(args):

    num_created_vm = 20
    stride = 2
    assert num_created_vm % stride == 0

    mem_monitor = MemoryMonitor(args.result_dir)
    result_dir = args.result_dir
    created_vms = []
    x = []

    num_cur_vm = 0

    for _ in range(num_created_vm//stride):
        for vm_idx in range(stride):
            base_vm = VMBase(num_cur_vm+vm_idx, config_file=args.config_file,
                             result_dirs=result_dir)
            base_vm.create_vm()

            created_vms.append(base_vm)

        num_cur_vm += stride
        x.append(num_cur_vm)
        time.sleep(2)

        mem_used = mem_monitor.collect()
        print(f"Number of VM:{num_cur_vm} MemUsed:{mem_used} GiB")

    mem_monitor.dump_log()

    safe_sleep(360)
    for vm in created_vms:
        vm.shutdown_vm_gracefully()

    print("Done!")


def test_fork_one_vsock_vm(args: dict):
    result_dir = args.result_dir

    base_vm = VMBase(0, config_file=args.config_file,
                     result_dirs=args.result_dir, init_network=False, use_vsock=True)

    base_vm.create_vm()

    safe_sleep(1200)
    base_vm.pause_vm()
    base_vm.snapshot_vm()

    base_vm.dump_logs()
    print("Base vm done")
    safe_sleep(360)
    forked_vm = VMForkedWithVsock(1, results_dir=result_dir,
                                  from_vm=base_vm)
    
    forked_vm.create_vm()
    time.sleep(1)
    forked_vm.dump_logs()

    forked_vm.fork()

    forked_vm.dump_logs()
    print("fork done")
    safe_sleep(1800)

    forked_vm.shutdown_vm_gracefully()
    base_vm.shutdown_vm_gracefully()


if __name__ == "__main__":
    parser = argparse.ArgumentParser("example")

    parser.add_argument("--config-file", type=str)
    parser.add_argument("--result-dir", type=str, default="result")

    args = parser.parse_args()
    test_fork_one_vsock_vm(args)
