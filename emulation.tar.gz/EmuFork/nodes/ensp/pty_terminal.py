#!/bin/env python3
import time
import sys

time.sleep(1)

print("Connected to device")
print("Please press Enter to continue...")
sys.stdout.flush()

# 等待回车
try:
    input_line = sys.stdin.readline()
    if input_line.strip() == "":
        print("Password:", end="", flush=True)
        password = sys.stdin.readline().strip()
        if password == "password":
            print("Login successful")
        else:
            print("Login failed")
            sys.exit(1)
except EOFError:
    sys.exit(1)

time.sleep(0.5)

while True:
    try:
        first = input("<HUAWEI> ")
        print(f"Executing: {first}")
        time.sleep(0.5)
        print(f"Command '{first}' completed successfully")

    except EOFError as e:
        break
    first = first.strip()

    if first == "exit":
        break
