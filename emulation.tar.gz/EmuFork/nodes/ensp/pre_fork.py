#!/usr/bin/env python3
"""
Guest OS script to prepare environment before forking.

This script is executed inside the template VM before forking to child VMs.
It starts vpnf devices for network emulation.

Usage:
    python3 pre_fork.py --count 10
    python3 pre_fork.py -c 5
"""

import subprocess
import sys
import os
import time
import logging
import argparse

# Import PtyInitiator for password initialization
# The pty_control.py is in the same directory
from pty_control import PtyInitiator

def run_command(cmd: str, timeout: int = 30) -> tuple[int, str, str]:
    """Run a shell command and return (returncode, stdout, stderr)."""
    logging.debug(f"Running command: {cmd}")
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        logging.error(f"Command timed out: {cmd}")
        return -1, "", "Command timed out"
    except Exception as e:
        logging.error(f"Command failed with exception: {e}")
        return -1, "", str(e)

def start_vpnf_device(device_id: int, max_retries: int = 5) -> bool:
    """
    Start a vpnf device with retry logic.

    Args:
        device_id: The device ID (i in ne8000-{i})
        max_retries: Maximum number of retry attempts

    Returns:
        True if successful, False otherwise
    """
    device_name = f"ne8000-{device_id}"
    cmd = f"vpnf startup -d {device_name}"

    for attempt in range(1, max_retries + 1):
        logging.info(f"Starting device {device_name}, attempt {attempt}/{max_retries}")

        rc, stdout, stderr = run_command(cmd)
        success = rc == 0 and "succeed" in stdout.lower()

        if success:
            logging.info(f"Device {device_name} started successfully")
            return True
        else:
            logging.warning(f"Failed to start device {device_name} (attempt {attempt}): rc={rc}, stdout={stdout}, stderr={stderr}")
            # Try to stop the device (cleanup) even if startup failed
            try:
                stop_vpnf_device(device_id)
            except Exception as e:
                logging.debug(f"Failed to stop device {device_name} after failed startup: {e}")
                # Ignore stop failures as requested

            if attempt < max_retries:
                time.sleep(1)  # Wait before retry

    logging.error(f"Failed to start device {device_name} after {max_retries} attempts")
    # Final attempt to stop the device before returning failure
    try:
        stop_vpnf_device(device_id)
    except Exception as e:
        logging.debug(f"Failed to stop device {device_name} after all attempts: {e}")
        # Ignore stop failures as requested

    return False

def stop_vpnf_device(device_id: int) -> bool:
    """
    Stop a vpnf device.

    Args:
        device_id: The device ID (i in ne8000-{i})

    Returns:
        True if successful, False otherwise
    """
    device_name = f"ne8000-{device_id}"
    cmd = f"vpnf stop -d {device_name}"

    rc, stdout, stderr = run_command(cmd)
    success = rc == 0

    if success:
        logging.info(f"Device {device_name} stopped successfully")
    else:
        logging.warning(f"Failed to stop device {device_name}: rc={rc}, stdout={stdout}, stderr={stderr}")

    return success

def create_veth_pairs_for_device(device_id: int, count_per_device: int = 15) -> bool:
    """
    Create veth pairs for a vpnf device.

    Creates pairs:
        v{veth_idx}_{device_id}_in <-> eth{veth_idx}_{device_id}
    where veth_idx ranges from 0 to count_per_device-1.

    Args:
        device_id: The device ID (i in ne8000-{i})
        count_per_device: Number of veth pairs to create per device

    Returns:
        True if all veth pairs created successfully, False otherwise
    """
    for veth_idx in range(count_per_device):
        veth_in = f"v{veth_idx}_{device_id}_in"
        veth_out = f"eth{veth_idx}_{device_id}"

        cmd = f"ip link add {veth_in} type veth peer name {veth_out}"
        rc, stdout, stderr = run_command(cmd)

        if rc != 0:
            logging.error(f"Failed to create veth pair {veth_in}<->{veth_out}: {stderr}")
            # Clean up any veth pairs that were already created for this device
            for cleanup_idx in range(veth_idx):
                cleanup_veth_in = f"v{cleanup_idx}_{device_id}_in"
                cleanup_cmd = f"ip link del {cleanup_veth_in}"
                run_command(cleanup_cmd)  # Ignore result, best effort cleanup
            return False

        logging.debug(f"Created veth pair {veth_in}<->{veth_out}")

    logging.info(f"Created {count_per_device} veth pairs for device ne8000-{device_id}")
    return True

def cleanup_veth_pairs_for_device(device_id: int, count_per_device: int = 15):
    """
    Clean up veth pairs for a vpnf device.

    Args:
        device_id: The device ID (i in ne8000-{i})
        count_per_device: Number of veth pairs to clean up per device
    """
    for veth_idx in range(count_per_device):
        veth_in = f"v{veth_idx}_{device_id}_in"
        cmd = f"ip link del {veth_in}"
        rc, stdout, stderr = run_command(cmd)
        if rc != 0:
            logging.debug(f"Failed to delete veth pair {veth_in}: {stderr}")
        else:
            logging.debug(f"Cleaned up veth pair {veth_in}")

def cleanup_started_devices(started_ids: list[int]):
    """
    Clean up devices that were successfully started.

    Args:
        started_ids: List of device IDs that were successfully started
    """
    if not started_ids:
        return

    logging.info(f"Cleaning up {len(started_ids)} started devices: {started_ids}")

    for device_id in started_ids:
        stop_vpnf_device(device_id)
        # Also clean up veth pairs for this device
        cleanup_veth_pairs_for_device(device_id)

def main():
    """Command-line entry point."""
    # Setup argument parser
    parser = argparse.ArgumentParser(description="Start vpnf devices for network emulation")
    parser.add_argument("-c", "--count", type=int, required=True,
                       help="Number of vpnf devices to start (starting from 1)")
    parser.add_argument("-r", "--retries", type=int, default=5,
                       help="Maximum retry attempts per device (default: 5)")
    parser.add_argument("-v", "--verbose", action="store_true",
                       help="Enable verbose logging")

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=log_level,
                       format='%(asctime)s - %(levelname)s - %(message)s')

    logging.info(f"Starting {args.count} vpnf devices with up to {args.retries} retries each")

    # First, create veth pairs for all devices
    logging.info(f"Creating veth pairs for {args.count} devices")
    for i in range(1, args.count + 1):
        if not create_veth_pairs_for_device(i):
            logging.error(f"Failed to create veth pairs for device ne8000-{i}")
            # Clean up veth pairs for devices that were already created
            for cleanup_i in range(1, i):
                cleanup_veth_pairs_for_device(cleanup_i)
            sys.exit(1)

    logging.info(f"Successfully created veth pairs for all {args.count} devices")

    started_devices = []
    failed = False

    # Start devices from 1 to count
    for i in range(1, args.count + 1):
        if start_vpnf_device(i, max_retries=args.retries):
            started_devices.append(i)
        else:
            logging.error(f"Failed to start device ne8000-{i}, cleaning up and exiting")
            failed = True
            # Clean up any devices that were successfully started
            cleanup_started_devices(started_devices)
            # Clean up veth pairs for all devices (since they were all created)
            for cleanup_i in range(1, args.count + 1):
                cleanup_veth_pairs_for_device(cleanup_i)
            sys.exit(1)

    if failed:
        # This should not be reached since we exit above, but keep for safety
        cleanup_started_devices(started_devices)
        for cleanup_i in range(1, args.count + 1):
            cleanup_veth_pairs_for_device(cleanup_i)
        sys.exit(1)
    else:
        logging.info(f"Successfully started {len(started_devices)} vpnf devices: {started_devices}")

        # Wait for devices to fully boot up
        logging.info("Waiting 3 minutes for devices to fully boot up...")
        time.sleep(180)

        # Initialize passwords for each device
        for device_id in started_devices:
            try:
                # TODO: Adjust program_path based on actual program location
                # The program to run for password initialization
                program_path = "./time_client"  # TODO: Update with actual program path

                # Working directory for this device
                working_dir = f"/workspace/containers/ne8000-{device_id}/TOR"

                # Initial password to set
                new_password = "huawei123"

                logging.info(f"Initializing password for device ne8000-{device_id}")
                logging.info(f"  Working directory: {working_dir}")
                logging.info(f"  Program: {program_path}")
                logging.info(f"  Password: {new_password}")

                # Initialize password using PtyInitiator
                initiator = PtyInitiator(
                    program_path=program_path,
                    new_password=new_password,
                    working_dir=working_dir,
                    debug=True  # Enable debug for verbose output
                )
                initiator.close()

                logging.info(f"Successfully initialized password for device ne8000-{device_id}")

            except Exception as e:
                logging.error(f"Failed to initialize password for device ne8000-{device_id}: {e}")
                # Continue with other devices even if one fails
                continue

        sys.exit(0)

if __name__ == "__main__":
    main()