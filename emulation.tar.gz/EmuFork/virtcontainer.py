#!/bin/env python3

from topo.topology_loader import load_topology
from abc import ABC, abstractmethod
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from enum import Enum
import os
import re
from memory_metric import MemoryUsageCollector

from vm_utils import run_command, CmdRecord, run_commands, QMPClient
import json

import argparse
import time
from check_bgp import check_node_routes_str, check_node_str, expected_prefixes

MINIMUM_CID = 3
TS_DICT = {}

VM_NETWORK_START = "vm_network_start"
VM_NETWORK_END = "vm_network_end"
CONTAINER_NETWORK_START = "container_net_start"
CONNTAINER_NETWORK_END = "container_net_end"
RESUME_START = "resume_start"
RESUME_END = "resume_end"
CONVERGE_START = "converge_start"
CONVERGE_END = "converge_end"
DEBUG = False
COMMAND_SPLIT_THRESHOLD = 128
SMP = 4
QEMU_MEM_GB = 4

QEMU_DEFAULT_CONFIG = {
    "network_dev": "tap0",
    "disk_image": "base.qcow2",
    "mgmt_ip": "172.16.0.2",
    "host_side_ip": "172.16.0.1"
}


def idx2mac(global_idx):

    oct0 = 0x00
    oct1 = (global_idx >> 32) & 0xFF
    oct2 = (global_idx >> 16) & 0xFF
    oct3 = (global_idx >> 8) & 0xFF
    oct4 = global_idx & 0xFF

    mac = f"{oct0:02x}:{oct1:02x}:{oct2:02x}:{oct3:02x}:{oct4:02x}:01"

    return mac


def record_ts(ts_key):
    ts = time.monotonic()
    assert ts_key not in TS_DICT
    TS_DICT[ts_key] = ts


class LoggingMixin:
    def init_logging(self, log_path, record_log_name):
        self.logging_path = log_path
        self.logging_records = []
        self.logging_dump = False
        self.reocrd_log_name = record_log_name
        self.enable_log = True

    def dump_log(self):
        flag = "a"
        if not self.logging_dump:
            flag = "w"
            self.logging_dump = True
        with open(f"{self.logging_path}/{self.reocrd_log_name}", flag) as f:
            f.writelines([str(rec) for rec in self.logging_records])
            self.logging_records = []

    def append_record(self, record: CmdRecord):
        if self.enable_log:
            self.logging_records.append(record)

    def append_records(self, records: list[CmdRecord]):
        self.logging_records += records
    # Call it when logging is not needed (e.g., run in parallel)

    def set_logging(self, enable=True):
        self.enable_log = enable


class TapManager(LoggingMixin):
    def __init__(self, num_vm, output_dir):
        self.num_vm = num_vm
        self.idx2tap = {}
        self.output_dir = output_dir
        for idx in range(1, num_vm+1):
            mgmt_host_ip, mgmt_guest_ip = self.idx2mgmt_ip(idx)
            mgmt_name = f"mgmt_{idx}"

            self.idx2tap[idx] = (
                mgmt_name, mgmt_host_ip, mgmt_guest_ip)

        self.init_logging(self.output_dir, "tap_manager.log")

    def init(self) -> bool:
        def create_mgmt_and_comm(host_ips, tap_names) -> CmdRecord:

            cmds = []
            for host_ip, tap_name in zip(host_ips, tap_names):
                pass

                cmd = [f"ip tuntap add dev {tap_name} mode tap", f"sysctl -w net.ipv6.conf.{tap_name}.disable_ipv6=1",
                       f"ip addr add {host_ip}/30 dev {tap_name}", f"ip link set {tap_name} up"]

                cmds.extend(cmd)

            cmds = ";".join(cmds)

            return run_command(cmds)

        with ThreadPoolExecutor() as executor:
            futures = []

            for idx in range(1, 1+self.num_vm):
                info = self.idx2tap[idx]
                mgmt_host_ip = info[1]

                mgmt_name = info[0]
                future = executor.submit(
                    create_mgmt_and_comm, [mgmt_host_ip], [
                        mgmt_name]
                )
                futures.append(future)

            ok = True

        for future in as_completed(futures):

            record: CmdRecord = future.result()
            if record.rc != 0:
                ok = False

            self.append_record(record)

        return ok

    def cleanup(self):
        for idx in range(1, self.num_vm+1):
            rec = run_command(f"ip link del mgmt_{idx} ")
            if rec.rc != 0:
                print(str(rec))

    def get_tap_info(self, idx):
        return self.idx2tap[idx]

    def idx2mgmt_ip(self, idx):
        offset0 = idx // 64
        offset1 = idx % 64
        host_side = f"172.17.{offset0}.{4*offset1+1}"
        guest_side = f"172.17.{offset0}.{4*offset1+2}"
        return host_side, guest_side


class EmuForkConfig:
    pass


class HypervisorType(Enum):
    Firecracker = 0
    QEMU = 1
    CloudHypervisor = 2


class Hypervisor(ABC, LoggingMixin):
    def __init__(self, idx, output_dir):
        self.output_dir = output_dir
        self.idx = idx
        assert os.path.exists(self.output_dir)

        workdir_path = os.path.join(
            self.output_dir, "hypervisor", self.vm_name())

        if not os.path.exists(workdir_path):
            os.makedirs(workdir_path, exist_ok=True)

        self.work_dir_path = os.path.abspath(workdir_path)

        self.init_logging(self.work_dir_path, "cmd.log")

    def work_dir(self):
        return self.work_dir_path

    @abstractmethod
    def create(self) -> list[CmdRecord]:
        ...

    @abstractmethod
    def start(self) -> list[CmdRecord]:
        ...

    def create_and_start(self) -> list[CmdRecord]:
        records = []
        records.extend(self.create())
        records.extend(self.start())
        return records

    def _run_command(self, cmd, timeout=80):
        rec = run_command(cmd, timeout=timeout)
        self.append_record(rec)

        return rec

    @abstractmethod
    def snapshot(self):
        ...

    @abstractmethod
    def vm_name(self):
        ...

    @abstractmethod
    def add_drive(self):
        ...

    @abstractmethod
    def pause(self):
        pass

    @abstractmethod
    def resume(self):
        ...

    @abstractmethod
    def shutdown(self):
        pass

    @abstractmethod
    def run_command_on_guest(self, cmds):
        ...

    @abstractmethod
    def copy_to_guest(self, host_path, guest_path):
        ...

    @abstractmethod
    def copy_from_guest(self, guest_path, host_path):
        ...

    def id(self):
        return self.idx

    @abstractmethod
    def ip_addr(self):
        pass


class VirtContainer(ABC):

    def __init__(self, global_idx, local_idx, output_dir, executor: Hypervisor, pid=None):
        self.output_dir = output_dir
        # idx in a VM , start from zero
        self.local_idx = local_idx
        # global idx, start from zero
        self.global_idx = global_idx
        self.pid = pid
        self.executor = executor

    @abstractmethod
    def create(self):
        pass

    @abstractmethod
    def start_daemons(self):
        pass

    @abstractmethod
    def container_name(self):
        return f"emufork-{self.local_idx}"

    @abstractmethod
    def hypervisor_id(self):
        """return hypervisor id which starts"""
        pass

    @abstractmethod
    def load_config(self):
        ...

    @abstractmethod
    def check_converge(self, expected, blueprint: dict):
        ...

    def global_id(self):
        return self.global_idx

    def container_pid(self):
        return self.pid

    @staticmethod
    def get_converge_ts(self):
        pass


class FRRouting(VirtContainer):
    def __init__(self, global_idx, local_idx, output_dir, executor, pid=None):
        super().__init__(global_idx, local_idx, output_dir, executor, pid)

    def container_name(self):
        return f"frr_{self.local_idx}"

    def create(self):
        pass

    def load_config(self, topo):
        conf_file = f"conf/frr/{topo}/node_{self.global_id()+1}.conf"
        cmds = [
            f"scp -i id_rsa {conf_file} root@{self.executor.ip_addr()}:/tmp/opt/lwc/containers/{self.container_name()}/rootfs/etc/crpd/crpd.conf",
            f'ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.executor.ip_addr()} "lwc exec {self.container_name()} bash -c \'cli << EOF\nconfig\nload override /etc/crpd/crpd.conf\ncommit\nEOF\'"'
        ]
        records = [run_command(cmd, timeout=360) for cmd in cmds]

        return records


class SoNiCContainer(VirtContainer):
    pass


class CrpdContainer(VirtContainer, LoggingMixin):
    def __init__(self, global_idx, local_idx, output_dir, executor: Hypervisor, pid=None):
        super().__init__(global_idx, local_idx, output_dir, executor, pid)

    def container_name(self):
        return f"crpd_{self.local_idx}"

    def parse_route_age(self, output: str):
        lines = output.splitlines()
        pattern = r"\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}"
        for line in lines:
            if not "RIB routes" in line:
                continue

            result = re.search(pattern, line)
            if result:
                time_str = result.group()

                time_format = "%Y-%m-%d %H:%M:%S"

                time_obj = datetime.strptime(time_str, time_format)

                return time_obj

        return None

    def get_converge_ts(self):
        # calibrate the time
        prefix = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.executor.ip_addr()} lwc exec {self.container_name()} "
        cmd = f'{prefix} cli -c \\"show route summary\\"'

        rec = run_command(cmd)

        if rec.rc != 0:
            return False, -1

        t0 = self.parse_route_age(rec.stdout)

        cmd = f'{prefix} date +\\"%Y-%m-%d %H:%M:%S\\"'

        rec = run_command(cmd)

        h_t1 = time.monotonic()

        if rec.rc != 0:
            return False, -1

        pattern = r"\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}"
        result = re.search(pattern, rec.stdout)
        t1 = datetime.strptime(result.group(), "%Y-%m-%d %H:%M:%S")

        delta = t1.timestamp() - t0.timestamp()

        return True, h_t1-delta

    def check_converge(self, expected, blueprint: dict) -> bool:
        route, bgp_summary = self.collect_route_and_bgp_summary()
        # print(route, bgp_summary, expected)
        if not self.check_bgp_summary(bgp_summary, blueprint) or not self.check_route(expected, route):
            return False, self.global_idx+1
        return True, self.global_idx+1

    def collect_route_and_bgp_summary(self):

        prefix = f'ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.executor.ip_addr()} lwc exec {self.container_name()} '
        summary_cmd = f'{prefix} cli -c \\"show bgp summary\\"'
        route_cmd = f'{prefix} cli -c \\"show route\\"'

        summary = run_command(summary_cmd)
        route = run_command(route_cmd, timeout=240)

        route = route.stdout
        bgp_summary = summary.stdout

        if not bgp_summary.strip() or "Down peers" not in bgp_summary:
            print(str(summary))
        return route, bgp_summary

    def check_bgp_summary(self, bgp_summary, blueprint):

        ok, msg = check_node_str(
            "crpd", blueprint, self.global_id()+1, bgp_summary)

        if not ok:
            if self.global_idx % 50 == 0:
                print(f"{self.global_id()+1} summary: {bgp_summary}")
                print(f"{self.container_name()} summary:", msg)
            return False

        return True

    def check_route(self, expected, route):

        ok, msg = check_node_routes_str(expected, "crpd", route)
        if not ok:
            if DEBUG or True:
                print(f"{self.global_idx+1} msg:", msg)
            return False

        return True

    # TODO: Need retry logic here
    def create(self) -> list[str]:
        cmds = [f"lwc create real-crpd {self.container_name()}",
                f"lwc start {self.container_name()} /sbin/runit-init.sh"
                ]
        cmds = ";".join(cmds)
        records = []

        records += [self.executor.run_command_on_guest(cmds)]

        # record: CmdRecord = self.executor.run_command_on_guest(
        #     f'jq \'.pid\' /tmp/opt/lwc/containers/{self.container_name()}/config.json')

        record: CmdRecord = self.executor.run_command_on_guest(
            f'cat /tmp/opt/lwc/containers/{self.container_name()}/config.json '
        )

        data = json.loads(record.stdout)

        self.pid = int(data["pid"])
        print("pid is", self.pid)
        assert self.pid >= 0
        # Needed to execute commands
        records += [self.executor.run_command_on_guest(
            f"mkdir -p /run/netns; ln -sf /proc/{self.pid}/ns/net /run/netns/{self.pid}")]

        cnt = 0

        while True:
            cmd = f'lwc exec {self.container_name()} cli -c \\"request system license add /crpd-license\\"'
            record: CmdRecord = self.executor.run_command_on_guest(
                cmd,
                quoted=False
            )
            if "add license complete" in record.stdout:
                records += [record]
                print("license done")
                break
            time.sleep(0.5)
            if cnt == 100:
                print("Timeout")
                raise BaseException(str(record))
            cnt += 1

        return records

    def start_daemons(self):
        raise NotImplementedError()

    def hypervisor_id(self):
        return self.executor.id()

    def load_config(self, topo):
        conf_file = f"conf/crpd/{topo}/node_{self.global_id()+1}.conf"
        cmds = [
            f"scp -i id_rsa {conf_file} root@{self.executor.ip_addr()}:/tmp/opt/lwc/containers/{self.container_name()}/rootfs/etc/crpd/crpd.conf",
            f'ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.executor.ip_addr()} "lwc exec {self.container_name()} bash -c \'cli << EOF\nconfig\nload override /etc/crpd/crpd.conf\ncommit\nEOF\'"'
        ]
        records = [run_command(cmd, timeout=360) for cmd in cmds]

        return records


class DummyContainer(VirtContainer, LoggingMixin):
    """Dummy container for testing network configuration without actual services."""

    def __init__(self, global_idx, local_idx, output_dir, executor: Hypervisor, pid=None):
        super().__init__(global_idx, local_idx, output_dir, executor, pid)

    def create(self) -> list:
        """Create dummy container with network namespace and veth pairs."""
        print(
            f"DummyContainer {self.container_name()}: creating network namespace and veth pairs")

        records = []
        global_idx = self.global_idx
        ns_name = f"ns_{global_idx}"

        # 1. Create network namespace (similar to lwc container creation)
        ns_cmd = f"ip netns add {ns_name}"
        record = self.executor.run_command_on_guest(ns_cmd)
        records.append(record)

        # 2. Create 10 veth pairs
        for i in range(0, 10):
            # veth pair: eth{i}_{global_idx} (in root ns) <-> eth{i}_temp (to be moved to ns)
            veth_outside = f"eth{i}_{global_idx}"
            veth_temp = f"eth{i}_temp"
            veth_inside = f"eth{i}"

            # Create veth pair
            cmd1 = f"ip link add {veth_outside} type veth peer name {veth_temp}"
            record = self.executor.run_command_on_guest(cmd1)
            records.append(record)

            # Move one end to network namespace
            cmd2 = f"ip link set {veth_temp} netns {ns_name}"
            record = self.executor.run_command_on_guest(cmd2)
            records.append(record)

            # Rename inside the namespace
            cmd3 = f"ip netns exec {ns_name} ip link set {veth_temp} name {veth_inside}"
            record = self.executor.run_command_on_guest(cmd3)
            records.append(record)

            # Bring up interfaces
            cmd4 = f"ip netns exec {ns_name} ip link set {veth_inside} up"
            record = self.executor.run_command_on_guest(cmd4)
            records.append(record)

            cmd5 = f"ip link set {veth_outside} up"
            record = self.executor.run_command_on_guest(cmd5)
            records.append(record)

        # 3. Set dummy pid and create symlink for netns (similar to CrpdContainer)
        # Using a unique number based on global_idx
        self.pid = 10000 + global_idx

        # Create symlink so netns can be accessed via pid (like real containers)
        symlink_cmd = f"mkdir -p /run/netns; ln -sf /var/run/netns/{ns_name} /run/netns/{self.pid}"
        record = self.executor.run_command_on_guest(symlink_cmd)
        records.append(record)

        print(
            f"DummyContainer {self.container_name()}: created ns={ns_name}, pid={self.pid}")
        return records

    def start_daemons(self):
        """Start daemons - no daemons to start."""
        print(
            f"DummyContainer {self.container_name()}: start_daemons() called, no-op")
        # No daemons to start for dummy container

    def container_name(self):
        """Return container name."""
        return f"dummy_{self.local_idx}"

    def hypervisor_id(self):
        """Return hypervisor ID."""
        return self.executor.id()

    def load_config(self, topo=None):
        """Load configuration - no actual config to load."""
        print(
            f"DummyContainer {self.container_name()}: load_config() called, no-op")
        return []

    def check_converge(self, expected, blueprint: dict):
        """Check convergence - always return True for dummy container."""
        print(
            f"DummyContainer {self.container_name()}: check_converge() called, returning True")
        return True, self.global_idx + 1


class Firecracker(Hypervisor):
    def __init__(self, idx, output_dir, mgmt_ip="172.16.0.2"):
        super().__init__(idx, output_dir)
        self.api_sock_path = f"/tmp/{self.vm_name()}.sock"
        self.mgmt_ip = mgmt_ip
        self.pid = -1
        run_command(f"rm {self.api_sock_path}; rm v.sock")

    def vm_name(self):
        return f"fc_{self.idx}"

    def api_sock(self):
        return self.api_sock_path

    def _run_command(self, cmd, timeout=80):
        rec = run_command(cmd, timeout=timeout)
        self.append_record(rec)

        return rec

    def pause(self) -> CmdRecord:
        cmd = f"""curl --unix-socket {self.api_sock()} -i \
            -X PATCH 'http://localhost/vm' \
            -H 'Accept: application/json' \
            -H 'Content-Type: application/json' \
            -d '{{
            "state": "Paused"
            }}'"""

        return self._run_command(cmd)

    def resume(self) -> CmdRecord:
        cmd = f"""curl --unix-socket {self.api_sock()} -i \
                -X PATCH 'http://localhost/vm' \
                -H 'Accept: application/json' \
                -H 'Content-Type: application/json' \
                -d '{{
                        "state": "Resumed"
                 }}'"""
        return self._run_command(cmd)

    def snapshot(self) -> CmdRecord:
        cmd = f"""curl --unix-socket {self.api_sock()} -i \
                -X PUT 'http://localhost/snapshot/create' \
                -H  'Accept: application/json' \
                -H  'Content-Type: application/json' \
                -d '{{
                    "snapshot_type": "Full",
                    "snapshot_path": "{self.work_dir()}/snapshot_file",
                    "mem_file_path": "{self.work_dir()}/mem_file"
        }}'"""
        # Avoid spurious timeout for VM that occupies large memory
        return self._run_command(cmd, timeout=360)

    def create(self):
        cmd = f"nohup firecracker --api-sock {self.api_sock()} > {self.work_dir()}/hypervisor.log 2>&1 & echo $!"
        rec: CmdRecord = self._run_command(cmd)
        self.pid = int(rec.stdout)

        return [rec]

    def shutdown(self):
        cmd = f"""sudo curl -X PUT 'http://localhost/actions' \
          --unix-socket {self.api_sock()} \
                    --data '{{
                    "action_type":  "SendCtrlAltDel"
                        }}' """

        self._run_command(cmd)
        if self.pid != -1:
            self._run_command(f'kill -9 {self.pid}')

    def run_command_on_guest(self, cmds, quoted=True):
        if isinstance(cmds, list):
            cmds = ";".join(cmds)
        if quoted:
            guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} '{cmds}'"
        else:
            guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} {cmds}"

        return self._run_command(guest_cmd)

    def add_drive(self):
        raise NotImplementedError()

    def copy_from_guest(self, guest_path, host_path):
        raise NotImplementedError()

    def copy_to_guest(self, host_path, guest_path):
        cmd = f"scp -i id_rsa {host_path} root@{self.mgmt_ip}:{guest_path}"

        return self._run_command(cmd)

    def ip_addr(self):
        return self.mgmt_ip


class CloudHypervisor(Hypervisor):
    pass


class QEMU(Hypervisor):
    def __init__(self, idx, output_dir, mgmt_ip, host_side_ip):
        super().__init__(idx, output_dir)
        self.mgmt_ip = mgmt_ip
        self.host_side_ip = host_side_ip
        self.vm_mem_path = None
        self.vm_state_path = None
        self.vsock_cid = self.idx + MINIMUM_CID

        self.api_sock_path = f"/tmp/qemu_{self.id()}"

    def get_qmp_client(self):
        qmp_client = QMPClient(self.api_sock())
        qmp_client.connect()
        return qmp_client

    def create(self):
        raise NotImplementedError("create")

    def start(self):
        raise NotImplementedError("start")

    def run_command_on_guest(self, cmds, quoted=True):
        if isinstance(cmds, list):
            cmds = ";".join(cmds)
        if quoted:
            guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} '{cmds}'"
        else:
            guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{self.mgmt_ip} {cmds}"

        return self._run_command(guest_cmd)

    def _wait_migration(self, qmp_client: QMPClient):
        for _ in range(100):
            result = qmp_client.execute("query-migrate")
            if "status" in result and result["status"] == "completed":
                return

            time.sleep(0.1)

        print("Wait migration ERROR")

    def snapshot(self):
        qmp_client = self.get_qmp_client()
        arguments = {"capabilities": [
            {"capability": "x-ignore-shared", "state": True}]}
        qmp_client.execute(
            "migrate-set-capabilities", arguments=arguments)

        arguments = {"uri": f"exec:cat>{self.vm_state_path}"}

        qmp_client.execute("migrate", arguments=arguments)

        self._wait_migration(qmp_client)
        qmp_client.close()

        return []

    def resume(self, qmp_client=None):
        need_close = True
        if qmp_client == None:
            qmp_client = self.get_qmp_client()
            need_close = False

        res = qmp_client.execute("cont")
        if need_close:
            qmp_client.close()

        return []

    def pause(self, qmp_client=None):
        need_close = True
        if qmp_client == None:
            qmp_client = self.get_qmp_client()
            need_close = False
        qmp_client.execute("stop")
        qmp_client.close()
        if need_close:
            qmp_client.close()
        return []

    def copy_from_guest(self, guest_path, host_path):
        raise NotImplementedError

    def copy_to_guest(self, host_path, guest_path):
        cmd = f"scp -i id_rsa {host_path} root@{self.mgmt_ip}:{guest_path}"

        return self._run_command(cmd)

    def vm_name(self):
        return f"qemu_{self.idx}"

    def api_sock(self):
        return self.api_sock_path

    def ip_addr(self):
        return self.mgmt_ip

    def shutdown(self, graceful=True):
        if graceful:
            self.run_command_on_guest("shutdown -h now")
            return []

        qmp_client = self.get_qmp_client()
        qmp_client.execute("quit")
        qmp_client.close()
        return []

    def add_drive(self):
        raise NotImplementedError


class QEMUTemplate(QEMU):
    def __init__(self, idx, output_dir, config_dict: dict, file_back_mem=True):
        assert "disk_image" in config_dict
        assert "mgmt_ip" in config_dict
        assert "host_side_ip" in config_dict
        assert "network_dev" in config_dict

        super().__init__(idx, output_dir,
                         mgmt_ip=config_dict["mgmt_ip"], host_side_ip=config_dict["host_side_ip"])

        self.disk_image_path = os.path.abspath(config_dict["disk_image"])
        self.network_dev = config_dict["network_dev"]
        self.vm_state_path = os.path.join(self.work_dir(), "vm_state")
        self.vm_mem_path = os.path.join(self.work_dir(), "vm_mem")

        if file_back_mem:
            # TODO: adjust mem size
            self.mem_option = f" -object memory-backend-file,id=mem0,size={QEMU_MEM_GB}G,mem-path={self.vm_mem_path},share=on -machine memory-backend=mem0"
        else:
            self.mem_option = " "

        run_command(f"rm {self.api_sock()}")

    def create(self):
        return []

    def start(self):
        qemu_cmd = f"nohup qemu-system-x86_64 \
                -enable-kvm \
                -m {QEMU_MEM_GB}G \
                -smp {SMP} \
                -nographic \
                -serial mon:stdio \
                -drive file={self.disk_image_path},format=qcow2,if=virtio \
                {self.mem_option} \
                -netdev tap,id=net0,ifname={self.network_dev},script=no,downscript=no \
                -device virtio-net-pci,netdev=net0 \
                    -device vhost-vsock-pci,id=vhost-vsock0,guest-cid={self.vsock_cid} \
                -qmp unix:{self.api_sock()},server,nowait > {self.work_dir()}/{self.vm_name()}.log 2>&1 &"
        records = []

        record = self._run_command(qemu_cmd)
        records.append(record)
        if record.rc != 0:
            return records

        return records


class QEMUChild(QEMU):
    def __init__(self, idx, output_dir, mgmt_name, guest_side_ip, host_side_ip, template: QEMUTemplate):
        super().__init__(idx, output_dir, guest_side_ip, host_side_ip)
        self.net_dev_name = mgmt_name
        self.vm_mem_path = template.vm_mem_path
        self.vm_state_path = template.vm_state_path
        self.template_disk_path = template.disk_image_path
        self.disk_image_path = f"{self.work_dir()}/{self.vm_name()}.qcow2"

    def create(self):
        # prepare rootfs
        records = []
        cmd = f"qemu-img create -f qcow2 -b {self.template_disk_path} -F qcow2 {self.disk_image_path}"
        records.append(self._run_command(cmd))

        cmd = f"nohup qemu-system-x86_64 \
                -enable-kvm \
                -m {QEMU_MEM_GB}G \
                -smp {SMP} \
                -nographic \
                -serial mon:stdio \
                -drive file={self.disk_image_path},format=qcow2,if=virtio \
                -object memory-backend-file,id=mem0,size={QEMU_MEM_GB}G,mem-path={self.vm_mem_path},share=off \
                -machine memory-backend=mem0 \
                 -netdev tap,id=net0,ifname={self.net_dev_name},script=no,downscript=no \
                -device virtio-net-pci,netdev=net0 \
                -S -incoming defer \
                -device vhost-vsock-pci,id=vhost-vsock0,guest-cid={self.vsock_cid} \
                -qmp unix:{self.api_sock()},server,nowait > {self.work_dir()}/{self.vm_name()}.log 2>&1 & "

        records.append(self._run_command(cmd))
        # Wait the UNIX domain socket
        time.sleep(0.1)
        return records

    def start(self):
        qmp_client = self.get_qmp_client()

        arguments = {"capabilities": [
            {"capability": "x-ignore-shared", "state": True}]}
        qmp_client.execute(
            "migrate-set-capabilities", arguments=arguments)

        qmp_client.execute("migrate-incoming",
                           {"uri": f"exec:cat {self.vm_state_path}"})

        self._wait_migration(qmp_client)
        self.resume(qmp_client)

        qmp_client.close()
        results = []
        results.append(self._reset_mgmt())
        results.append(self._setup_mgmt_gateway())

        return results

    def _reset_mgmt(self):
        cmd = f"./EmuFork/agent/client_qemu {self.mgmt_ip} {self.vsock_cid}"
        return self._run_command(cmd)

    def _setup_mgmt_gateway(self) -> bool:
        # TODO: modify NIC name (i.e., ens3)
        cmd = f"ip route add default via {self.host_side_ip} dev ens3"
        return self.run_command_on_guest(cmd)


class FirecrackerTemplate(Firecracker):
    def __init__(self, idx, output_dir, config_file, mgmt_ip):
        super().__init__(idx, output_dir, mgmt_ip)
        self.config_file = config_file
        assert os.path.exists(config_file)

    def start(self):
        # TODO: enable pci here for now. Tweak it later
        cmd = f"nohup firecracker  --api-sock {self.api_sock()} --config-file {self.config_file} > {self.work_dir()}/{self.vm_name()}.log 2>&1 & echo $!"

        rec: CmdRecord = self._run_command(cmd)
        self.pid = int(rec.stdout)
        return [rec]

    def create(self):
        # Do nothing
        return []

    def fork(self, num_vm):
        pass


class FirecrackerChild(Firecracker):
    def __init__(self, idx, output_dir, template: Firecracker, mgmt_name, guest_mgmt_ip, host_mgmt_ip):
        super().__init__(idx, output_dir, guest_mgmt_ip)

        self.template_workdir = template.work_dir()

        self.network_override_list = [{"iface_id": f"mgmt",
                                       "host_dev_name": f"{mgmt_name}"}]

        self.host_mgmt_ip = host_mgmt_ip
        self.mgmt_mac = None
        self._run_command(f"rm {self.work_dir()}/v.sock")

    def create(self):
        cmd = f"cd {self.work_dir()}; nohup firecracker --api-sock {self.api_sock()} > {self.work_dir()}/hypervisor.log 2>&1 & echo $!"
        rec: CmdRecord = self._run_command(cmd)
        self.pid = int(rec.stdout)
        return [rec]

    def start(self):
        override = json.dumps(self.network_override_list)

        template_workdir = self.template_workdir
        snapshot_file = f"{template_workdir}/snapshot_file"
        mem_file = f"{template_workdir}/mem_file"
        # TODO: tweak track_dirty_pages option
        cmd = f"""cd {self.work_dir()}; curl --unix-socket {self.api_sock()} -i \
                        -X PUT 'http://localhost/snapshot/load' \
                        -H  'Accept: application/json' \
                        -H  'Content-Type: application/json' \
                        -d '{{
                                "snapshot_path": "{snapshot_file}",
                                "mem_file_path": "{mem_file}",
                        "track_dirty_pages": true,
                        "resume_vm": true,
                        "network_overrides": {override}
                        }}'"""

        results = []
        for i in range(10):
            record = run_command(cmd)
            if record.rc == 0:
                results.append(record)
                break
            else:
                print(f"retry {self.vm_name()}")
                time.sleep(0.5)

        results.append(self._reset_mgmt())

        results.append(self._setup_mgmt_gateway())
        return results

    def _reset_mgmt(self) -> bool:
        cmd = f"./docker_net_emulation/agent/client {self.mgmt_ip} {self.work_dir()}/v.sock"
        return self._run_command(cmd)

    def _setup_mgmt_gateway(self) -> bool:
        # to avoid mac address conflict
        cmd = f"ip route add default via {self.host_mgmt_ip} dev eth0"
        return self.run_command_on_guest(cmd)


class VirtContainerController(LoggingMixin):

    def __init__(self, output_dir, vm_list: list[Hypervisor], container_list: list[VirtContainer], use_fastlink=False):
        self.output_dir = output_dir
        self.init_logging(f"{self.output_dir}", "controller.log")
        self.use_fastlink = use_fastlink
        self.id2vm = {vm.id(): vm for vm in vm_list}
        self.id2container = {}
        self.mac_idx = 0

        self.vm2container = defaultdict(list)

        for container in container_list:
            self.vm2container[container.hypervisor_id()].append(container)
            self.id2container[container.global_id()] = container
            assert container.hypervisor_id() in self.id2vm

        # for debug
        lines = []
        for idx, container in self.id2container.items():
            container: VirtContainer = container
            line = f"{idx+1} {container.container_name()} {container.executor.ip_addr()} \n"
            lines.append(line)

        with open(f"{output_dir}/mappinng.txt", "w") as f:
            f.writelines(lines)

    def get_max_converge_ts(self):
        max_converge_ts = 0
        for idx, container in enumerate(self.id2container.values()):
            container: VirtContainer = container
            ok, converge_ts = container.get_converge_ts()
            if not ok:
                print(f"{container.container_name()} failed")
                continue
            max_converge_ts = max(max_converge_ts, converge_ts)
            if idx % 50 == 0:
                print(f"[{idx}/{len(self.id2container)}] Checking converge ts")

        return max_converge_ts

    def wait_converge(self, blueprint, timeout=600000, parallel=False, max_loop_cnt=5):

        expected = expected_prefixes(blueprint)
        cur_loop = 0
        start = time.monotonic()
        while True:
            ok = True
            not_ready = []
            if parallel:
                with ThreadPoolExecutor() as executor:
                    futures = []

                    for container in self.id2container.values():
                        container: VirtContainer = container
                        future = executor.submit(container.check_converge,
                                                 expected, blueprint)
                        futures.append(future)

                not_ok_cnt = 0
                for future in as_completed(futures):
                    converged, idx = future.result()
                    if not converged:
                        ok = False
                        not_ok_cnt += 1
                        not_ready.append(idx)

                if ok:
                    print("wait converge time: ", time.monotonic()-start)
                    return True
            else:
                def parallel_hypervior_check_converge(containers):
                    is_converged = True
                    not_readys = []
                    for container in containers:
                        container: VirtContainer = container
                        con, idx = container.check_converge(
                            expected,
                            blueprint
                        )
                        if not con:
                            is_converged = False
                            not_readys.append(idx)
                    return is_converged, not_readys
                not_ok_cnt = 0
                with ThreadPoolExecutor() as executor:

                    futures = []
                    assert len(self.vm2container) > 0
                    total_container = 0
                    for container_list in self.vm2container.values():
                        futures.append(executor.submit(
                            parallel_hypervior_check_converge, container_list))
                        total_container += len(container_list)
                    assert len(futures) > 0
                    assert total_container > 0
                    print("Total container", total_container)
                    checked_cnt = 0
                    for future in as_completed(futures):
                        converged, not_readys = future.result()
                        checked_cnt += 1
                        if checked_cnt % 100 == 0:
                            print(
                                f"[{checked_cnt}/{total_container}] check converge")
                        if not converged:
                            ok = False
                            not_ok_cnt += len(not_readys)
                            not_ready.extend(not_readys)

                    if ok:
                        print("wait converge time: ", time.monotonic()-start)
                        return True

                # not_ok_cnt = 0
                # for container_idx, container in enumerate(self.id2container.values()):
                #     container: VirtContainer = container
                #     converged, idx = container.check_converge(
                #         expected, blueprint)
                #     if not converged:
                #         print(converged)
                #         ok = False
                #         not_ok_cnt += 1
                #         not_ready.append(idx)
                #     if container_idx % 50 == 0:
                #         print(
                #             f"[{container_idx}/{len(self.id2container)}] wait converge")

                # if ok:
                #     return True

            time.sleep(10)
            if cur_loop == max_loop_cnt:
                print("timeout")
                return False
            cur_loop += 1
            if True:
                print("# of not ready routers", len(not_ready), not_ready)
            if timeout and time.monotonic()-start > timeout:
                print("timeout exit")
                return False

    def load_config(self, topo):

        def start_container_in_hypervisor(container_list: list, topo_name):
            records = []
            for container in container_list:
                records += container.load_config(topo_name)

            return records

        with ThreadPoolExecutor() as executor:
            futures = []
            for container_id, container_list in self.vm2container.items():

                future = executor.submit(
                    start_container_in_hypervisor, container_list, topo)
                futures.append(future)

            records = []

            for future in as_completed(futures):
                records += future.result()

        self.append_records(records)
        self.dump_log()

        print("load_config done")

    def create_network(self, blueprint: dict):
        assert len(blueprint["routers"]) == len(self.id2container)
        routers = blueprint["routers"]

        hypervisors_dict = defaultdict(list)
        link_idx = 0
        for router in routers:
            idx1 = router["idx"]
            for idx, neighbor in enumerate(router["neighbors"]):
                idx2 = neighbor["peeridx"]

                if idx1 > idx2:
                    continue

                container1: VirtContainer = self.id2container[idx1-1]
                container2: VirtContainer = self.id2container[idx2-1]

                internal = (container1.hypervisor_id() ==
                            container2.hypervisor_id())

                ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
                ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"
                ifname1 = neighbor['ifname']
                ifname2 = neighbor['peerifname']

                if internal:
                    meta = {"type": "internal", "linkidx": link_idx, "peer1": {
                        "netns": container1.container_pid(), "ifname": ifname1, "ip": ip1}, "peer2": {
                        "netns": container2.container_pid(), "ifname": ifname2, "ip": ip2}}

                    hypervisors_dict[container1.hypervisor_id()].append(meta)

                else:

                    vm1_ip = self.id2vm[container1.hypervisor_id()].ip_addr()
                    vm2_ip = self.id2vm[container2.hypervisor_id()].ip_addr()
                    container1_side_meta = {
                        "type": "external", "linkidx": link_idx, "vid": link_idx+100,
                        "netns": container1.container_pid(), "ifname": ifname1, "ip": ip1, 'local_ip': vm1_ip, 'remote_ip': vm2_ip, "vlanif": "eth0"}

                    container2_side_meta = {
                        "type": "external", "linkidx": link_idx, "vid": link_idx+100,
                        "netns": container2.container_pid(), "ifname": ifname2, "ip": ip2, 'local_ip': vm2_ip, 'remote_ip': vm1_ip, "vlanif": "eth0"}

                    hypervisors_dict[container1.hypervisor_id()].append(
                        container1_side_meta)
                    hypervisors_dict[container2.hypervisor_id()].append(
                        container2_side_meta)

                link_idx += 1

        if not self.use_fastlink:
            vm2cmds = self.network_setup_commands(hypervisors_dict)

            with ThreadPoolExecutor() as executor:
                futures = []
                for vm_id, cmd in vm2cmds.items():
                    vm = self.id2vm[vm_id]

                    futures.append(executor.submit(
                        VirtContainerController.run_command_on_guest, vm.ip_addr(), cmd))

                for future in as_completed(futures):

                    result = future.result()

                    if isinstance(result, list):
                        self.append_records(result)
                    else:
                        self.append_record(future.result())
        else:
            self.append_records(
                self.create_network_with_fastlink(hypervisors_dict))

        self.dump_log()

    def create_network_with_fastlink(self, meta_dict: dict):
        def _fastlink_create(hypervisor: Hypervisor, meta_list):
            saved_dict = {"meta": meta_list}
            filename = f"net_{hypervisor.id()}.json"
            with open(f"/tmp/{filename}", "w") as f:
                json.dump(saved_dict, f)
            recs = []
            recs.append(hypervisor.copy_to_guest(
                f"/tmp/{filename}", f"/tmp/{filename}"))
            recs.append(hypervisor.run_command_on_guest(
                f"/tmp/fastlink /tmp/{filename} placeholder"))
            return recs

        with ThreadPoolExecutor() as executor:
            futures = []
            records = []

            for vmid, meta_list in meta_dict.items():
                vm = self.id2vm[vmid]
                futures.append(
                    executor.submit(_fastlink_create, vm, meta_list)
                )

            for future in as_completed(futures):
                result = future.result()
                records += result

        return records

    @staticmethod
    def run_command_on_guest(ip_addr, cmds):
        if isinstance(cmds, list):
            records = []
            for cmd in cmds:
                guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{ip_addr} '{cmd}'"
                records.append(run_command(guest_cmd))
            return records

        guest_cmd = f"ssh -o StrictHostKeyChecking=no -i id_rsa root@{ip_addr} '{cmds}'"

        record = run_command(guest_cmd)
        return record

    def network_setup_commands(self, hypervisor_dict: dict):
        vm2cmds = defaultdict(list)

        for k, meta_list in hypervisor_dict.items():
            for meta in meta_list:
                type = meta["type"]
                assert type in ["external", "internal"]
                if type == "internal":
                    cmds = self.create_internal_link(meta)
                else:
                    cmds = self.create_external_link(meta)

                vm2cmds[k].append(cmds)

        for k in vm2cmds.keys():
            if len(vm2cmds[k]) < COMMAND_SPLIT_THRESHOLD:
                vm2cmds[k] = ";".join(vm2cmds[k])
            else:
                pass

        return vm2cmds

    def create_internal_link(self, meta):

        peer1, peer2 = meta["peer1"], meta["peer2"]
        ip1, ip2 = peer1["ip"], peer2["ip"]
        pid1, pid2 = peer1["netns"], peer2["netns"]
        veth1_name, veth2_name = peer1["ifname"], peer2["ifname"]
        port1 = veth1_name
        port2 = veth2_name
        # cmds = [
        #     f"ip link add {veth1_name} type veth peer name {veth2_name}",
        #     f"ip link set {veth1_name} netns {pid1}",
        #     f"ip netns exec {pid1} ip link set {veth1_name} name {port1}",
        #     f"ip netns exec {pid1} ip link set {port1} up",
        #     f"ip netns exec {pid1} ip addr add {ip1} dev {port1}",
        #     f"ip link set {veth2_name} netns {pid2}",
        #     f"ip netns exec {pid2} ip link set {veth2_name} name {port2}",
        #     f"ip netns exec {pid2} ip link set {port2} up",
        #     f"ip netns exec {pid2} ip addr add {ip2} dev {port2}",
        # ]
        cmds = [
            f"ip link add {veth1_name} type veth peer name {veth1_name}_bb",
            f"ip link add {veth2_name} type veth peer name {veth2_name}_bb",
            f"ip link set {veth1_name} netns {pid1}",
            f"ip netns exec {pid1} ip link set {veth1_name} name {port1}",
            f"ip netns exec {pid1} ip link set {port1} up",
            f"ip netns exec {pid1} ip addr add {ip1} dev {port1}",
            f"ip link set {veth2_name} netns {pid2}",
            f"ip netns exec {pid2} ip link set {veth2_name} name {port2}",
            f"ip netns exec {pid2} ip link set {port2} up",
            f"ip netns exec {pid2} ip addr add {ip2} dev {port2}",
            f"ip link add {veth1_name}_br type bridge",
            f"ip link set {veth1_name}_br up",
            f"ip link set {veth1_name}_bb master {veth1_name}_br",
            f"ip link set {veth2_name}_bb master {veth1_name}_br",
            f"ip link set {veth1_name}_bb up",
            f"ip link set {veth2_name}_bb up",

        ]

        cmds = ";".join(cmds)

        return cmds

    def create_external_link(self, meta):
        veth_in_mac, veth_out_mac = idx2mac(
            self.mac_idx), idx2mac(self.mac_idx+1)

        self.mac_idx += 2

        mynic, ip, local_ip, peerip, vid = meta['ifname'], meta[
            "ip"], meta["local_ip"], meta["remote_ip"], meta['vid']
        link_idx = meta["linkidx"]
        vxlan = f'vxlan_{meta["linkidx"]}'
        veth_in = f'{meta["ifname"]}'
        veth_out = f'{meta["ifname"]}o'
        netns = meta["netns"]
        br_name = f"br_{link_idx}"
        vlanif = meta.get("vlanif", "eth0")

        cmd = [
            f"ip link add {vxlan} type vxlan id {vid} dev {vlanif} dstport 4789 remote {peerip} learning",
            f"ip link set {vxlan} up",
            f"ip link add {br_name} type bridge",
            f"ip link add {veth_in} type veth peer name {veth_out}",
            f"ip link set dev {veth_in} address {veth_in_mac}",
            f"ip link set dev {veth_out} address {veth_out_mac}",
            f"ip link set {veth_in} netns {netns}",
            f"ip link set {vxlan} master {br_name}",
            f"ip link set {vxlan} up",
            f"ip link set {veth_out} master {br_name}",
            f"ip link set {br_name} up",
            f"ip link set {veth_out} up",
            f"ip netns exec {netns} ip link set {veth_in} up",
            f"ip netns exec {netns} ip addr add {ip} dev {veth_in}"
        ]
        cmd = ";".join(cmd)
        return cmd


class VirtContainerFactory(LoggingMixin):
    def __init__(self, output_dir, mode, num_containers, container_per_vm, vm_config):
        self.init_logging(output_dir, "factory.log")

        assert mode in ["fork", "vanilla"]
        self.mode = mode
        self.num_containers = num_containers
        self.container_per_vm = container_per_vm
        self.num_vms = (num_containers+container_per_vm-1)//container_per_vm
        self.output_dir = output_dir
        self.vm_config = vm_config
        self.tap_manager = None
        self.is_destroy = False

    def get_bulk_containers_and_vms(self):
        assert not self.is_destroy
        if self.mode == "fork":
            return self.create_containers_with_fork()

        return self.create_containers_vanilla()

    def create_containers_with_fork(self):
        template = FirecrackerTemplate(
            0, self.output_dir, self.vm_config, "172.16.0.2")
        template.set_logging(True)
        template.create()
        template.start()

        template.run_command_on_guest("echo hello world")
        template.copy_to_guest("./docker_net_emulation/agent/server", "/tmp")

        if args.use_fastlink:
            template.copy_to_guest(
                "./docker_net_emulation/fastlink/fastlink", "/tmp")
        template.run_command_on_guest(
            'nohup /tmp/server >/tmp/server.log 2>&1 &')

        template.dump_log()

        template_containers: list[CrpdContainer] = []

        for container_idx in range(self.container_per_vm):
            container = CrpdContainer(
                container_idx, container_idx, output_dir=self.output_dir, executor=template)
            container.set_logging(False)
            records = container.create()
            self.append_records(records)

            template_containers.append(container)

        time.sleep(10)

        template.pause()
        template.snapshot()
        template.shutdown()
        num_child_vm = self.num_vms
        vms = {}
        vm_list = []

        tap_manager = TapManager(num_child_vm, self.output_dir)
        record_ts(VM_NETWORK_START)
        tap_manager.init()
        record_ts(VM_NETWORK_END)
        tap_manager.dump_log()
        record_ts(RESUME_START)

        self.tap_manager = tap_manager

        for idx in range(1, num_child_vm+1):
            tap_name, host_ip, guest_ip = tap_manager.get_tap_info(idx)
            child = FirecrackerChild(
                idx, self.output_dir, template, tap_name, guest_ip, host_ip)
            child.set_logging(False)
            vms[idx] = child
            vm_list.append(child)

        containers = []
        for container_idx in range(self.num_containers):
            vm_idx = (container_idx//self.container_per_vm)+1
            local_idx = container_idx % self.container_per_vm
            new_container = CrpdContainer(
                container_idx, local_idx, self.output_dir, vms[vm_idx], template_containers[local_idx].container_pid())
            containers.append(new_container)

        with ThreadPoolExecutor() as executor:
            futures = []
            records = []

            for idx, vm in vms.items():

                vm: Hypervisor = vm
                futures.append(
                    executor.submit(vm.create_and_start)
                )

            for future in as_completed(futures):
                records += future.result()

            self.append_records(records)

        record_ts(RESUME_END)
        print("Fork done")
        self.dump_log()

        return containers, vm_list

    def create_containers_vanilla(self):
        raise NotImplementedError()

    def destroy(self):
        assert not self.is_destroy
        self.tap_manager.cleanup()
        self.is_destroy = True


class eNSPFactory(LoggingMixin):
    def __init__(self, output_dir, num_containers, container_per_vm):
        self.init_logging(output_dir, "factory.log")

        self.num_containers = num_containers
        self.container_per_vm = container_per_vm
        self.num_vms = (num_containers+container_per_vm-1)//container_per_vm
        self.output_dir = output_dir
        self.tap_manager = None
        self.is_destroy = False

    def get_bulk_containers_and_vms(self, deploy_files: bool = False, verbose: bool = False, run_pre_fork: bool = False):
        assert not self.is_destroy

        return self.create_containers_with_fork(deploy_files=deploy_files, verbose=verbose, run_pre_fork=run_pre_fork)

    def create_containers_with_fork(self, deploy_files: bool = False, verbose: bool = False, run_pre_fork: bool = False):
        # 如果要求执行pre_fork，必须同时部署文件
        if run_pre_fork and not deploy_files:
            raise ValueError(
                "run_pre_fork requires deploy_files=True to ensure scripts are available in guest VM")

        template = QEMUTemplate(0, self.output_dir, QEMU_DEFAULT_CONFIG)
        template.set_logging(True)
        template.create()
        template.start()
        time.sleep(10)

        result = template.run_command_on_guest("echo hello world")

        # 部署必要文件到template VM（可选）
        if deploy_files:
            self._deploy_files_to_template(template)

        # 执行pre_fork.py脚本启动vpnf设备（可选）
        if run_pre_fork:
            # 参考post_fork.py的调用方式，脚本应已通过_deploy_files_to_template部署到/opt/emufork/
            script_to_run = "/opt/emufork/pre_fork.py"

            # 计算需要启动的vpnf设备数量
            # 每个VM中的容器数量作为vpnf设备数量
            device_count = self.container_per_vm

            # 构建命令
            cmd = f"python3 {script_to_run} --count {device_count} --retries 5"
            if verbose:
                cmd += " --verbose"

            print(f"Executing pre_fork.py on template VM: {cmd}")

            pre_fork_result = template.run_command_on_guest(cmd)
            self.append_record(pre_fork_result)

            if pre_fork_result.rc != 0:
                print(
                    f"Warning: pre_fork.py exited with non-zero code: {pre_fork_result.rc}")
                print(f"stdout: {pre_fork_result.stdout}")
                print(f"stderr: {pre_fork_result.stderr}")
            else:
                print(f"pre_fork.py executed successfully")

        template.copy_to_guest("./EmuFork/agent/server_qemu", "./")
        template.run_command_on_guest(
            "nohup ./server_qemu >/tmp/server.log 2>&1 &")
        template.dump_log()

        template.dump_log()

        time.sleep(30)
        assert result.rc == 0

        template_containers: list[DummyContainer] = []
        childs = []

        for container_idx in range(self.container_per_vm):
            container = DummyContainer(
                container_idx, container_idx, output_dir=self.output_dir, executor=template)
            container.set_logging(False)
            records = container.create()
            self.append_records(records)

            template_containers.append(container)

        time.sleep(10)

        template.pause()
        template.snapshot()
        template.shutdown()
        num_child_vm = self.num_vms
        vms = {}
        vm_list = []

        tap_manager = TapManager(num_child_vm, self.output_dir)
        tap_manager.init()
        tap_manager.dump_log()

        self.tap_manager = tap_manager
        output_dir = self.output_dir
        for idx in range(1, num_child_vm+1):

            mgmt_name, mgmt_host_ip, mgmt_guest_ip = tap_manager.get_tap_info(
                idx)
            child = QEMUChild(idx, output_dir=output_dir, mgmt_name=mgmt_name,
                              guest_side_ip=mgmt_guest_ip, host_side_ip=mgmt_host_ip, template=template)
            childs.append(child)
            child.create()
            child.dump_log()
            child.start()

            child.run_command_on_guest("echo hello on forked vm")
            child.dump_log()
            vms[idx] = child
            vm_list.append(child)

        containers = []
        for container_idx in range(self.num_containers):
            vm_idx = (container_idx//self.container_per_vm)+1
            local_idx = container_idx % self.container_per_vm
            new_container = DummyContainer(
                container_idx, local_idx, self.output_dir, vms[vm_idx], template_containers[local_idx].container_pid())
            containers.append(new_container)

        self.dump_log()

        return containers, vm_list

    def _deploy_files_to_template(self, template):
        """部署必要文件到template VM的guest OS中。

        包括：
        1. 所有nodes/ensp目录下的*.py脚本
        2. 确保目标目录存在

        返回：所有命令执行记录的列表
        """
        import os
        import glob
        records = []

        # 1. 确保/opt/emufork目录存在
        rec = template.run_command_on_guest("mkdir -p /opt/emufork")
        records.append(rec)
        self.append_record(rec)

        # 2. 部署nodes/ensp目录下的所有Python脚本
        local_scripts_dir = os.path.join(
            os.path.dirname(__file__), "nodes", "ensp")
        local_scripts_dir = os.path.abspath(local_scripts_dir)

        if os.path.exists(local_scripts_dir):
            # 查找所有Python文件
            python_files = glob.glob(os.path.join(local_scripts_dir, "*.py"))

            for local_script_path in python_files:
                script_name = os.path.basename(local_script_path)
                guest_script_path = f"/opt/emufork/{script_name}"

                rec = template.copy_to_guest(
                    local_script_path, guest_script_path)
                records.append(rec)
                self.append_record(rec)
                # 设置可执行权限
                rec = template.run_command_on_guest(
                    f"chmod +x {guest_script_path}")
                records.append(rec)
                self.append_record(rec)
                print(
                    f"Deployed {script_name} to template VM at {guest_script_path}")

            print(
                f"Deployed {len(python_files)} Python files from {local_scripts_dir}")
        else:
            print(
                f"Warning: scripts directory not found at {local_scripts_dir}")

        # 3. 确保/etc/emufork/network_config目录存在（用于存放网络配置文件）
        rec = template.run_command_on_guest(
            "mkdir -p /etc/emufork/network_config")
        records.append(rec)
        self.append_record(rec)

        # 4. 可选：部署其他依赖文件
        # 例如，如果有其他配置模板或脚本，可以在这里添加

        return records

    def destroy(self):
        assert not self.is_destroy
        self.tap_manager.cleanup()
        self.is_destroy = True


class VMController(LoggingMixin):
    """控制单个VM内的所有容器"""

    def __init__(self, vm: Hypervisor, containers: list[VirtContainer]):
        self.vm = vm
        self.containers = containers
        self.container_map = {c.global_id(): c for c in containers}
        self.network_config = None  # 保存网络配置
        self.init_logging(vm.work_dir(), f"vm_{vm.id()}_controller.log")

    def set_network_config(self, network_meta_list: list[dict]):
        """设置网络配置但不执行，用于后续获取或dump配置"""
        self.network_config = network_meta_list

    def setup_network(self, network_meta_list: list[dict]) -> list[CmdRecord]:
        """为VM内的容器设置网络连接"""
        # 保存网络配置
        self.set_network_config(network_meta_list)

        records = []

        # 分离内部和外部链接
        internal_links = [
            m for m in network_meta_list if m["type"] == "internal"]
        external_links = [
            m for m in network_meta_list if m["type"] == "external"]

        # 执行内部链接设置（同一VM内容器间）
        for meta in internal_links:
            cmd = self._create_internal_link_cmd(meta)
            records.append(self.vm.run_command_on_guest(cmd))

        # 执行外部链接设置（跨VM容器间）
        for meta in external_links:
            cmd = self._create_external_link_cmd(meta)
            records.append(self.vm.run_command_on_guest(cmd))

        return records

    def _create_internal_link_cmd(self, meta: dict) -> str:
        """生成内部链接命令，将两个接口连接到同一个bridge上"""
        # 使用带有local_idx后缀的接口名
        ifname1_base = meta["ifname1"]
        ifname2_base = meta["ifname2"]
        local_idx1 = meta["local_idx1"]
        local_idx2 = meta["local_idx2"]
        link_idx = meta["linkidx"]

        # 创建带后缀的接口名
        ifname1 = f"{ifname1_base}_{local_idx1}"
        ifname2 = f"{ifname2_base}_{local_idx2}"

        # 创建bridge名称
        br_name = f"br_{link_idx}"

        # 创建bridge并连接两个接口
        cmds = [
            f"ip link add {br_name} type bridge",
            f"ip link set {br_name} up",
            f"ip link set {ifname1} master {br_name}",
            f"ip link set {ifname2} master {br_name}",
            f"ip link set {ifname1} up",
            f"ip link set {ifname2} up",
        ]

        return ";".join(cmds)

    def _create_external_link_cmd(self, meta: dict) -> str:
        """生成外部链接命令，直接将ifname连接到bridge"""
        # 必需字段
        peerip = meta["remote_ip"]
        vid = meta['vid']
        link_idx = meta["linkidx"]
        ifname_base = meta["ifname"]
        local_idx = meta["local_idx"]

        # 创建带后缀的接口名
        ifname = f"{ifname_base}_{local_idx}"

        # 可选字段
        vlanif = meta.get("vlanif", "eth0")

        vxlan = f'vxlan_{link_idx}'
        br_name = f"br_{link_idx}"

        cmd = [
            f"ip link add {vxlan} type vxlan id {vid} dev {vlanif} dstport 4789 remote {peerip} learning",
            f"ip link set {vxlan} up",
            f"ip link add {br_name} type bridge",
            f"ip link set {br_name} up",
            f"ip link set {vxlan} master {br_name}",
            f"ip link set {ifname} master {br_name}",
            f"ip link set {ifname} up",
        ]

        return ";".join(cmd)

    def change_internal_link_mac(self, meta: dict) -> str:
        """
        为internal link生成改变MAC地址的命令。
        根据meta中的信息，改变位于netns中的ifname的MAC地址为对应的mac值。

        meta格式（internal link）：
            {
                "type": "internal",
                "linkidx": int,
                "node1_name": str,
                "node2_name": str,
                "ifname1": str,    # 接口1的名称
                "ifname2": str,    # 接口2的名称
                "netns1": int,     # 容器1的netns pid
                "netns2": int,     # 容器2的netns pid
                "local_idx1": int, # 容器1的local_idx
                "local_idx2": int, # 容器2的local_idx
                "mac1": str,       # 接口1的MAC地址
                "mac2": str        # 接口2的MAC地址
            }

        返回：可执行的shell命令字符串
        """
        if meta.get("type") != "internal":
            raise ValueError(
                f"Expected internal link meta, got type: {meta.get('type')}")

        # 直接使用ifname1和ifname2（不加local_idx后缀）
        ifname1 = meta['ifname1']
        ifname2 = meta['ifname2']

        # 生成改变MAC地址的命令
        cmds = [
            f"ip netns exec {meta['netns1']} ip link set {ifname1} address {meta['mac1']}",
            f"ip netns exec {meta['netns2']} ip link set {ifname2} address {meta['mac2']}"
        ]

        return ";".join(cmds)

    def change_external_link_mac(self, meta: dict) -> str:
        """
        为external link生成改变MAC地址的命令。
        根据meta中的信息，改变位于netns中的ifname的MAC地址为mac_in。

        meta格式（external link）：
            {
                "type": "external",
                "linkidx": int,
                "node_name": str,  # 当前节点名称
                "vid": int,        # VXLAN ID
                "ifname": str,     # 容器接口名
                "netns": int,      # 容器netns pid
                "local_idx": int,  # 容器的local_idx
                "remote_ip": str,  # 对端VM IP地址
                "local_vm_id": int, # 本地VM ID
                "_mac_idx": int,   # MAC地址起始索引
                "mac_in": str,     # veth_in的MAC地址
                "mac_out": str     # veth_out的MAC地址
            }

        返回：可执行的shell命令字符串
        """
        if meta.get("type") != "external":
            raise ValueError(
                f"Expected external link meta, got type: {meta.get('type')}")

        # 直接使用ifname（不加local_idx后缀）
        ifname = meta["ifname"]

        # 生成改变MAC地址的命令，使用mac_in
        cmd = f"ip netns exec {meta['netns']} ip link set {ifname} address {meta['mac_in']}"

        return cmd

    def get_status(self) -> dict:
        """返回VM控制器状态"""
        return {
            "vm_id": self.vm.id(),
            "vm_ip": self.vm.ip_addr(),
            "container_count": len(self.containers),
            "containers": [c.container_name() for c in self.containers]
        }

    def get_network_config(self) -> dict:
        """获取网络配置（dict形式）"""
        if self.network_config is None:
            return {"error": "Network config not set"}

        return {
            "vm_id": self.vm.id(),
            "vm_ip": self.vm.ip_addr(),
            "config_count": len(self.network_config),
            "network_config": self.network_config
        }

    def dump_network_config(self, filepath: str = None) -> str:
        """将网络配置dump到文件，返回文件路径"""
        if self.network_config is None:
            raise ValueError(
                "Network config not set, call set_network_config() or setup_network() first")

        if filepath is None:
            filepath = os.path.join(
                self.vm.work_dir(), f"network_config_vm_{self.vm.id()}.json")

        config_data = self.get_network_config()

        with open(filepath, 'w') as f:
            json.dump(config_data, f, indent=2)

        return filepath

    def setup_network_via_config_file(self, config_dir: str = None) -> list:
        """通过配置文件方式设置网络，将配置保存为文件并复制到guest执行。

        此方法将网络配置保存为JSON文件，复制到guest VM，然后调用guest中的
        post_fork.py脚本来应用配置。

        Args:
            config_dir: 配置文件保存目录，默认为vm.work_dir() + "/network_configs"

        Returns:
            命令执行记录列表（包含文件复制和脚本执行的记录）。
        """
        import json
        import os

        if self.network_config is None:
            raise ValueError(
                "Network config not set, call set_network_config() or setup_network() first")

        # 1. 确定配置文件保存目录
        if config_dir is None:
            config_dir = os.path.join(self.vm.work_dir(), "network_configs")

        os.makedirs(config_dir, exist_ok=True)

        # 2. 保存网络配置为JSON文件
        config_filename = f"network_config_vm_{self.vm.id()}.json"
        host_config_path = os.path.join(config_dir, config_filename)

        # 保存配置为简单列表格式，便于guest脚本解析
        config_data = {
            "vm_id": self.vm.id(),
            "vm_ip": self.vm.ip_addr(),
            "network_config": self.network_config
        }

        with open(host_config_path, 'w') as f:
            json.dump(config_data, f, indent=2)

        # 3. 复制配置文件到guest（放在/etc/emufork/network_config/目录下）
        guest_config_dir = "/etc/emufork/network_config"
        guest_config_path = f"{guest_config_dir}/{config_filename}"

        records = []

        # 确保guest上的配置目录存在
        mkdir_cmd = f"mkdir -p {guest_config_dir}"
        records.append(self.vm.run_command_on_guest(mkdir_cmd))

        # 复制配置文件
        records.append(self.vm.copy_to_guest(
            host_config_path, guest_config_path))

        # 4. 执行guest中的配置脚本（假设脚本已存在于/opt/emufork/post_fork.py）
        script_to_run = "/opt/emufork/post_fork.py"

        # 5. 在guest中执行脚本
        cmd = f"python3 {script_to_run} {guest_config_path}"
        records.append(self.vm.run_command_on_guest(cmd))

        # 记录日志
        self.append_records(records)
        print(
            f"VM {self.vm.id()}: network configuration via config file completed, {len(records)} records")

        return records


class MultiVMCoordinator(LoggingMixin):
    """协调多个VM控制器，管理整个集群"""

    def __init__(self, output_dir, vm_controllers: list[VMController], default_vlanif: str = "eth0"):
        self.output_dir = output_dir
        self.vm_controllers = vm_controllers
        self.vm_controller_map = {c.vm.id(): c for c in vm_controllers}
        self.default_vlanif = default_vlanif
        self.init_logging(output_dir, "cluster_controller.log")

        # 构建全局映射
        self.id2container = {}
        self.id2vm = {}
        for vmc in vm_controllers:
            for container in vmc.containers:
                self.id2container[container.global_id()] = container
                self.id2vm[container.global_id()] = vmc.vm.id()

        # MAC地址索引，确保全局唯一
        self.mac_idx = 0

        # 网络配置
        self.network_config = None  # 保存集群网络配置

    def create_cluster_network(self, blueprint: dict) -> dict:
        """
        生成整个集群的网络拓扑配置描述（不执行实际网络配置）

        返回的配置包含：
        - blueprint: 原始蓝图
        - hypervisor_dict: 每个VM的网络配置列表
        - generated_at: 生成时间戳
        - total_links: 总链接数

        内部连接配置格式：
            {
                "type": "internal",
                "linkidx": int,
                "node1_name": str, # 节点1名称
                "node2_name": str, # 节点2名称
                "ifname1": str,    # 容器1的接口名
                "ifname2": str,    # 容器2的接口名
                "netns1": int,     # 容器1的netns pid
                "netns2": int,     # 容器2的netns pid
                "local_idx1": int, # 容器1的local_idx
                "local_idx2": int, # 容器2的local_idx
                "mac1_idx": int,   # 接口1的MAC地址索引
                "mac2_idx": int,   # 接口2的MAC地址索引
                "mac1": str,       # 接口1的MAC地址
                "mac2": str        # 接口2的MAC地址
            }

        外部连接配置格式：
            {
                "type": "external",
                "linkidx": int,
                "node_name": str,  # 当前节点名称
                "vid": int,        # VXLAN ID
                "ifname": str,     # 容器接口名
                "netns": int,      # 容器netns pid
                "local_idx": int,  # 容器的local_idx
                "remote_ip": str,  # 对端VM IP地址
                "local_vm_id": int, # 本地VM ID
                "_mac_idx": int,   # MAC地址起始索引
                "mac_in": str,     # veth_in的MAC地址
                "mac_out": str     # veth_out的MAC地址
            }
        """
        # 生成网络元数据（只包含拓扑连接信息）
        hypervisor_dict = self._generate_network_metadata(blueprint)

        # 保存网络配置
        self.network_config = {
            "blueprint": blueprint,
            "hypervisor_dict": hypervisor_dict,
            "generated_at": time.time(),
            "total_links": sum(len(meta_list) for meta_list in hypervisor_dict.values())
        }

        # 为每个VM控制器设置网络配置
        for vmid, meta_list in hypervisor_dict.items():
            if vmid in self.vm_controller_map:
                vmc = self.vm_controller_map[vmid]
                # 设置VMController的网络配置（但不执行）
                vmc.set_network_config(meta_list)

        self.dump_log()
        return self.network_config

    def load_all_configs(self, topo: str) -> bool:
        """并行加载所有配置"""
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(vmc.load_configs, topo)
                for vmc in self.vm_controllers
            ]

            all_success = True
            records = []
            for future in as_completed(futures):
                vm_records = future.result()
                records.extend(vm_records)
                if any(r.rc != 0 for r in vm_records):
                    all_success = False

            self.append_records(records)

        self.dump_log()
        return all_success

    def _generate_network_metadata(self, blueprint: dict) -> dict:
        """
        生成网络元数据（只包含拓扑连接信息，不包含IP配置）
        支持新的blueprint格式：
        {
            "routers": [
                {
                    "name": "node1",
                    "peers": [
                        {
                            "name": "node2",
                            "peer_interface": "eth0",
                            "self_interface": "eth1"
                        }
                    ]
                }
            ]
        }

        假设blueprint["routers"]列表的顺序对应容器的global_id()顺序：
        - routers[0] 对应 global_id()=0 的容器
        - routers[1] 对应 global_id()=1 的容器
        以此类推。

        根据蓝图生成每个VM的网络连接配置，只包含拓扑信息：
        - 内部连接：同一VM内的容器间veth连接
        - 外部连接：跨VM的容器间VXLAN连接

        返回格式：{vm_id: [meta1, meta2, ...]}
        """
        # 建立从容器全局ID到容器对象的映射（已经存在self.id2container）
        # 建立从节点名到容器对象的映射（用于通过名称查找）
        name_to_container = {}
        routers_list = blueprint["routers"]

        for i, router in enumerate(routers_list):
            node_name = router["name"]
            if i in self.id2container:
                container = self.id2container[i]
                name_to_container[node_name] = container
            else:
                print(
                    f"Warning: No container found for router index {i} (name: {node_name})")

        hypervisors_dict = defaultdict(list)
        link_idx_counter = 0
        link_idx_map = {}  # 映射节点对到link_idx: {(node1, node2): link_idx}
        mac_idx_counter = self.mac_idx  # 从当前的mac_idx开始
        link_idx_to_mac_idx = {}  # 映射link_idx到mac_idx起始值

        for i, router in enumerate(routers_list):
            node1_name = router["name"]
            if node1_name not in name_to_container:
                print(
                    f"Warning: Node {node1_name} not found in containers, skipping")
                continue

            container1: VirtContainer = name_to_container[node1_name]

            for peer in router.get("peers", []):
                node2_name = peer["name"]
                if node2_name not in name_to_container:
                    print(
                        f"Warning: Peer node {node2_name} not found in containers, skipping")
                    continue

                container2: VirtContainer = name_to_container[node2_name]

                self_ifname = peer["self_interface"]  # 本节点接口
                peer_ifname = peer["peer_interface"]  # 对端节点接口

                internal = (container1.hypervisor_id() ==
                            container2.hypervisor_id())

                # 确定节点对键（有序，避免重复）
                pair_key = (node1_name, node2_name) if node1_name < node2_name else (
                    node2_name, node1_name)

                # 获取或分配link_idx和mac_idx
                if pair_key not in link_idx_map:
                    link_idx_map[pair_key] = link_idx_counter
                    # 为每个link分配两个连续的mac_idx（用于veth两端）
                    link_idx_to_mac_idx[link_idx_counter] = mac_idx_counter
                    mac_idx_counter += 2  # 内部连接需要两个MAC地址，外部连接也需要两个
                    link_idx_counter += 1

                link_idx = link_idx_map[pair_key]

                if internal:
                    # 内部连接：同一VM内的容器间veth连接
                    # 每个内部连接只需要一个配置（包含两个接口）
                    # 确保只添加一次（当node1_name < node2_name时）
                    if node1_name < node2_name:
                        # 获取该link的mac_idx起始值
                        mac_idx_start = link_idx_to_mac_idx[link_idx]
                        meta = {
                            "type": "internal",
                            "linkidx": link_idx,
                            "node1_name": node1_name,  # 节点1名称（当node1_name < node2_name时）
                            "node2_name": node2_name,  # 节点2名称
                            "ifname1": self_ifname,    # 容器1接口
                            "ifname2": peer_ifname,    # 容器2接口
                            "netns1": container1.container_pid(),
                            "netns2": container2.container_pid(),
                            "local_idx1": container1.local_idx,  # 容器1的local_idx
                            "local_idx2": container2.local_idx,  # 容器2的local_idx
                            "mac1_idx": mac_idx_start,      # 接口1的MAC地址索引
                            "mac2_idx": mac_idx_start + 1,  # 接口2的MAC地址索引
                            "mac1": idx2mac(mac_idx_start),    # 接口1的MAC地址
                            "mac2": idx2mac(mac_idx_start + 1)  # 接口2的MAC地址
                        }

                        vm_id = container1.hypervisor_id()
                        hypervisors_dict[vm_id].append(meta)

                else:
                    # 外部连接：跨VM的容器间VXLAN连接
                    # 每个VM需要自己的配置
                    vm1_id = container1.hypervisor_id()
                    vm2_id = container2.hypervisor_id()

                    if vm1_id not in self.vm_controller_map:
                        print(
                            f"Warning: VM {vm1_id} not found in controller map, skipping connection")
                        continue
                    if vm2_id not in self.vm_controller_map:
                        print(
                            f"Warning: VM {vm2_id} not found in controller map, skipping connection")
                        continue

                    vm1_ip = self.vm_controller_map[vm1_id].vm.ip_addr()
                    vm2_ip = self.vm_controller_map[vm2_id].vm.ip_addr()

                    # 为当前节点（node1）生成配置
                    # 当前节点总是container1（正在遍历其peers的节点）
                    # ifname是当前节点的接口（self_interface）
                    # remote_ip是对端VM的IP（container2所在VM的IP）
                    # 为external link分配两个MAC地址（veth_in和veth_out）
                    mac_idx_start = mac_idx_counter
                    mac_idx_counter += 2
                    meta = {
                        "type": "external",
                        "linkidx": link_idx,
                        "node_name": node1_name,    # 当前节点名称
                        "vid": link_idx + 100,      # VXLAN ID
                        "ifname": self_ifname,      # 本容器接口名（当前节点的接口）
                        "netns": container1.container_pid(),
                        "local_idx": container1.local_idx,  # 容器的local_idx
                        "remote_ip": vm2_ip,        # 对端VM的IP（container2所在VM）
                        "local_vm_id": vm1_id,      # 本地VM ID（当前VM）
                        "_mac_idx": mac_idx_start,  # MAC地址起始索引
                        "mac_in": idx2mac(mac_idx_start),      # veth_in的MAC地址
                        # veth_out的MAC地址
                        "mac_out": idx2mac(mac_idx_start + 1),
                        "vlanif": self.default_vlanif  # VXLAN使用的物理接口
                    }

                    # 添加到对应VM的配置列表
                    hypervisors_dict[container1.hypervisor_id()].append(meta)

        # 更新全局MAC地址索引
        self.mac_idx = mac_idx_counter

        return hypervisors_dict

    def get_cluster_status(self) -> dict:
        """返回集群状态"""
        return {
            "total_vms": len(self.vm_controllers),
            "total_containers": len(self.id2container),
            "vms": [vmc.get_status() for vmc in self.vm_controllers]
        }

    def get_network_config(self) -> dict:
        """获取集群网络配置（dict形式）"""
        if self.network_config is None:
            return {"error": "Network config not set, call create_cluster_network() first"}

        # 添加额外的集群信息
        config = self.network_config.copy()
        config.update({
            "cluster_info": {
                "total_vms": len(self.vm_controllers),
                "total_containers": len(self.id2container),
                "mac_idx": self.mac_idx,  # 注意：只生成配置时不分配MAC地址，此字段为0
                "note": "只生成拓扑配置，不执行实际网络设置"
            }
        })
        return config

    def setup_network_via_ssh(self, parallel: bool = False) -> list:
        """通过SSH调用每个VMController的setup_network来创建网络。

        此方法遍历所有VM控制器，调用其setup_network方法（使用已设置的network_config），
        收集所有命令执行记录，并保存日志。

        Args:
            parallel: 是否并行执行各VM的网络设置，默认False。

        Returns:
            所有VMController返回的CmdRecord列表。
        """
        from concurrent.futures import ThreadPoolExecutor
        all_records = []

        if parallel:
            # 使用线程池并行执行
            with ThreadPoolExecutor() as executor:
                futures = []
                for vmc in self.vm_controllers:
                    if vmc.network_config:
                        future = executor.submit(
                            vmc.setup_network, vmc.network_config)
                        futures.append((vmc, future))

                for vmc, future in futures:
                    try:
                        records = future.result()
                        all_records.extend(records)
                        self.append_records(records)
                        # 每个VM完成后立即dump日志，确保日志及时保存
                        self.dump_log()
                        print(
                            f"VM {vmc.vm.id()} network setup completed, {len(records)} records")
                    except Exception as e:
                        print(f"VM {vmc.vm.id()} network setup failed: {e}")
        else:
            # 串行执行
            for vmc in self.vm_controllers:
                if vmc.network_config:
                    try:
                        records = vmc.setup_network(vmc.network_config)
                        all_records.extend(records)
                        self.append_records(records)
                        # 每个VM完成后立即dump日志
                        self.dump_log()
                        print(
                            f"VM {vmc.vm.id()} network setup completed, {len(records)} records")
                    except Exception as e:
                        print(f"VM {vmc.vm.id()} network setup failed: {e}")

        return all_records

    def setup_network_via_config_file(self, parallel: bool = False) -> list:
        """通过配置文件方式设置网络，调用每个VMController的setup_network_via_config_file。

        此方法遍历所有VM控制器，调用其setup_network_via_config_file方法，
        将网络配置保存为文件并复制到guest执行。

        Args:
            parallel: 是否并行执行各VM的网络设置，默认False。

        Returns:
            所有VMController返回的CmdRecord列表。
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        all_records = []

        if parallel:
            # 使用线程池并行执行
            with ThreadPoolExecutor() as executor:
                futures = []
                for vmc in self.vm_controllers:
                    if vmc.network_config:
                        future = executor.submit(
                            vmc.setup_network_via_config_file)
                        futures.append((vmc, future))

                for vmc, future in futures:
                    try:
                        records = future.result()
                        all_records.extend(records)
                        self.append_records(records)
                        # 每个VM完成后立即dump日志，确保日志及时保存
                        self.dump_log()
                        print(
                            f"VM {vmc.vm.id()} network setup via config file completed, {len(records)} records")
                    except Exception as e:
                        print(
                            f"VM {vmc.vm.id()} network setup via config file failed: {e}")
        else:
            # 串行执行
            for vmc in self.vm_controllers:
                if vmc.network_config:
                    try:
                        records = vmc.setup_network_via_config_file()
                        all_records.extend(records)
                        self.append_records(records)
                        # 每个VM完成后立即dump日志
                        self.dump_log()
                        print(
                            f"VM {vmc.vm.id()} network setup via config file completed, {len(records)} records")
                    except Exception as e:
                        print(
                            f"VM {vmc.vm.id()} network setup via config file failed: {e}")

        return all_records

    def dump_network_config(self, filepath: str = None) -> str:
        """将集群网络配置dump到文件，返回文件路径"""
        if self.network_config is None:
            raise ValueError(
                "Network config not set, call create_cluster_network() first")

        if filepath is None:
            filepath = os.path.join(
                self.output_dir, f"network_config_cluster.json")

        config_data = self.get_network_config()

        with open(filepath, 'w') as f:
            json.dump(config_data, f, indent=2)

        return filepath


def create_cluster_from_containers(containers: list[VirtContainer],
                                   vms: list[Hypervisor],
                                   output_dir: str,
                                   default_vlanif: str = "eth0") -> MultiVMCoordinator:
    """从容器和VM列表创建多VM协调器

    Args:
        containers: 容器列表
        vms: VM列表
        output_dir: 输出目录
        default_vlanif: 默认VXLAN物理接口名，默认为"eth0"
    """
    # 按VM分组容器
    vm_to_containers = defaultdict(list)
    for container in containers:
        vm_to_containers[container.hypervisor_id()].append(container)

    # 为每个VM创建VMController
    vm_controllers = []
    for vm in vms:
        vm_containers = vm_to_containers.get(vm.id(), [])
        if vm_containers:  # 只创建有容器的VM控制器
            vmc = VMController(vm, vm_containers)
            vm_controllers.append(vmc)

    # 创建多VM协调器
    cluster = MultiVMCoordinator(
        output_dir, vm_controllers, default_vlanif=default_vlanif)
    return cluster


# 示例用法：
# 1. 使用现有工厂创建容器和VM
#    factory = VirtContainerFactory(output_dir, mode="fork", ...)
#    containers, vms = factory.get_bulk_containers_and_vms()
# 2. 创建多VM协调器
#    cluster = create_cluster_from_containers(containers, vms, output_dir)
# 3. 生成网络配置（只生成配置描述，不执行实际网络配置）
#    network_config = cluster.create_cluster_network(blueprint)  # 返回配置字典
# 4. 获取网络配置
#    config_dict = cluster.get_network_config()  # 获取字典形式
#    config_file = cluster.dump_network_config()  # 保存到文件
# 5. 获取单个VM的网络配置
#    for vmc in cluster.vm_controllers:
#        vm_config = vmc.get_network_config()  # 如果VMController已设置网络配置
#        vm_config_file = vmc.dump_network_config()  # 保存单个VM配置
# 6. 加载配置
#    cluster.load_all_configs(topo)
# 7. 获取状态
#    status = cluster.get_cluster_status()


def test_firecracker_template(args):
    output_dir = args.output_dir
    config_file = args.hypervisor_config

    template = FirecrackerTemplate(0, output_dir, config_file, "172.16.0.2")

    rec = template.create()

    rec = template.start()
    time.sleep(5)

    template.run_command_on_guest("echo hello world")
    template.copy_to_guest("./docker_net_emulation/agent/server", "/tmp")
    rec = template.run_command_on_guest(
        'nohup /tmp/server >/tmp/server.log 2>&1 &')

    template.dump_log()

    input("Enter to continue\n")

    rec = template.pause()
    rec = template.snapshot()
    template.dump_log()
    rec = template.shutdown()

    num_child_vm = 2
    childs = []
    tap_manager = TapManager(num_child_vm, output_dir)

    tap_manager.init()

    tap_manager.dump_log()

    for idx in range(1, num_child_vm+1):

        tap_name, host_ip, guest_ip = tap_manager.get_tap_info(idx)

        child = FirecrackerChild(
            idx, output_dir, template, tap_name, guest_ip, host_ip)
        child.create()
        child.start()
        childs.append(child)
        child.run_command_on_guest("echo hello world")
        child.dump_log()

    input("forked done!\n")

    input("add container done")

    tap_manager.cleanup()
    template.shutdown()
    for child in childs:
        child.shutdown()
    print("test done")


def cleanup():
    run_command("pkill firecracker")


def cleanup_qemu():
    run_command("pkill qemu")


def load_blueprint(topo, image):

    blueprint_path = f"./conf/{image}/{topo}/blueprint.json"

    with open(blueprint_path, "r") as f:
        blueprint = json.load(f)

    return blueprint


def collect_stat_for_fork():
    container_network = TS_DICT[CONNTAINER_NETWORK_END] - \
        TS_DICT[CONTAINER_NETWORK_START]

    vm_network = TS_DICT[VM_NETWORK_END] - TS_DICT[VM_NETWORK_START]

    resume = TS_DICT[RESUME_END] - TS_DICT[RESUME_START]
    return {"resume": resume, "network": vm_network+container_network, "container_network": container_network, "vm_network": vm_network}


def test_container_factory(args):
    vm_config = args.hypervisor_config

    bluerpint = load_blueprint(args.topo, args.image)
    factory = VirtContainerFactory(
        args.output_dir, mode="fork", num_containers=len(bluerpint["routers"]), container_per_vm=args.containers_per_vm, vm_config=vm_config)

    collector = MemoryUsageCollector(args.output_dir, 1)

    collector.start()
    time.sleep(2)

    containers, vms = factory.get_bulk_containers_and_vms()

    print("Containers done")

    controller = VirtContainerController(args.output_dir, vms, containers)

    record_ts(CONTAINER_NETWORK_START)
    controller.create_network(bluerpint)
    record_ts(CONNTAINER_NETWORK_END)
    controller.dump_log()

    print("network done")

    controller.load_config(args.topo)
    converge_start = time.monotonic()
    time.sleep(40)

    collector.end()

    result = controller.wait_converge(bluerpint)

    converge_end = controller.get_max_converge_ts()

    print("converge time", converge_end-converge_start)

    print(result)

    print("converge done!")

    stats = collect_stat_for_fork()

    stats["converge"] = converge_end - converge_start
    print(stats)

    with open(f"{args.output_dir}/stat.json", "w") as f:
        json.dump(stats, f)

    input("Wait for debug")

    cleanup()

    factory.destroy()
    exit(0)


def test_ensp_cluster(args):
    """
    python3.9 ./docker_net_emulation/virtcontainer.py --topoloy example.yaml --container_per_vm 2 --output__dir ./qemu_log
    mkdir -p test_emufork
    sudo python3 ./EmuFork/virtcontainer.py --topology ./EmuFork/topo/example/topology_example.yaml  --containers_per_vm 2 --output_dir ./test_emufork
    """
    assert args.topology
    topology = load_topology(args.topology)
    factory = eNSPFactory(
        args.output_dir, num_containers=len(topology["routers"]), container_per_vm=args.containers_per_vm)

    collector = MemoryUsageCollector(args.output_dir, 1)

    collector.start()
    time.sleep(2)

    containers, vms = factory.get_bulk_containers_and_vms(deploy_files=False)
    input("fork done")

    # 创建多VM协调器
    print(
        f"Creating MultiVMCoordinator with {len(containers)} containers and {len(vms)} VMs")
    # TODO: modify vlanif according to guest os config
    cluster = create_cluster_from_containers(
        containers, vms, args.output_dir, "ens3")

    # 生成集群网络配置（只生成配置，不执行）
    print("Generating cluster network configuration...")
    network_config = cluster.create_cluster_network(topology)
    print(
        f"Generated network configuration with {network_config.get('total_links', 0)} total links")

    # 获取集群状态
    status = cluster.get_cluster_status()
    print(
        f"Cluster status: {status.get('total_vms', 0)} VMs, {status.get('total_containers', 0)} containers")

    # 保存网络配置到文件
    config_file = cluster.dump_network_config()
    print(f"Network configuration saved to: {config_file}")

    # 也可以获取单个VM的网络配置
    for vmc in cluster.vm_controllers:
        vm_config = vmc.get_network_config()
        print(
            f"VM {vmc.vm.id()}: {vm_config.get('config_count', 0)} network configs")
        # 可选：保存单个VM配置
        # vm_config_file = vmc.dump_network_config()

    print("MultiVMCoordinator initialization and configuration complete")

    collector.end()
    input("Dump config done!")

    cluster.setup_network_via_ssh()

    input("setup_network_via_ssh done!")
    cleanup_qemu()

    factory.destroy()
    exit(0)


def parse_args():
    parser = argparse.ArgumentParser("emufork")

    parser.add_argument("--topo", type=str, default="fattree2")
    parser.add_argument("--image", type=str, default="crpd")
    parser.add_argument("--containers_per_vm", type=int,
                        help="number of containers per VM", default=1)

    parser.add_argument("--hypervisor_config", type=str)
    parser.add_argument("--output_dir", type=str)
    parser.add_argument("--use_fastlink", default=False, action="store_true")
    parser.add_argument("--topology", default="", type=str)
    return parser.parse_args()


def set_outputdir_name(args):
    time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{args.image}_{args.topo}_{time_str}_c{args.containers_per_vm}"
    path = args.output_dir + f"/{name}"

    os.makedirs(path)

    args.output_dir = path
    print(f"output path is {path}")


if __name__ == "__main__":
    args = parse_args()

    set_outputdir_name(args)
    # test_firecracker_template(args)
    # test_container_factory(args)
    test_ensp_cluster(args)
    # cleanup()
