#!/bin/env python3
from concurrent.futures import ThreadPoolExecutor, as_completed
from vm_utils import run_commands
import json
import time
import os
NUM_MAX_LINK = 256*64


class Link:
    def __init__(self, tap0_name, tap1_name, br_name):
        self.tap0_name = tap0_name
        self.tap1_name = tap1_name
        self.br_name = br_name


class MgmtLink:
    def __init__(self, tap_name, host_side_ip, guest_side_ip, mask):
        self.tap_name = tap_name
        self.host_side_ip = host_side_ip
        self.guest_side_ip = guest_side_ip
        self.mask = mask


class LinkPool:
    def __init__(self, netns, num_mgmt_links, num_normal_links, num_unused_tap, result_dir):
        assert num_mgmt_links <= NUM_MAX_LINK
        init_start = time.monotonic()
        self.netns = netns
        self.result_dir = result_dir

        if self.netns == None:
            self.netns_prefix = ""
        else:
            self.netns_prefix = f"ip netns exec {netns} "
        self.mgmt_links: list[MgmtLink] = [None]*num_mgmt_links
        self.normal_links: list[Link] = [None]*num_normal_links
        self.unused_tap_names = [None] * num_unused_tap
        for idx in range(num_mgmt_links):
            tap_name = f"mgmt{idx}"
            host_side, guest_side = self.idx2mgmt_ip(idx)
            mask = "/30"
            self.mgmt_links[idx] = MgmtLink(
                tap_name, host_side, guest_side, mask)

        for idx in range(num_normal_links):
            tap0_name = f"L{idx}_0"
            tap1_name = f"L{idx}_1"
            bridge = f"b_{idx}"

            self.normal_links[idx] = Link(tap0_name, tap1_name, bridge)

        for idx in range(num_unused_tap):
            unused_tap = f"unused_{idx}"
            self.unused_tap_names[idx] = unused_tap

        self.cur_mgmt_link_idx = 0
        self.cur_link_idx = 0
        self.cur_unused_tap = 0
        init_end = time.monotonic()
        print("Link Pool init time", init_end-init_start)

    def get_link(self) -> Link:
        assert self.cur_link_idx < len(self.normal_links)
        result = self.normal_links[self.cur_link_idx]
        self.cur_link_idx += 1
        return result

    def get_mgmt_link(self) -> MgmtLink:
        assert self.cur_mgmt_link_idx < len(self.mgmt_links)
        result = self.mgmt_links[self.cur_mgmt_link_idx]
        self.cur_mgmt_link_idx += 1
        return result

    def get_unused_tap(self) -> str:
        assert self.cur_unused_tap < len(self.unused_tap_names)

        result = self.unused_tap_names[self.cur_unused_tap]
        self.cur_unused_tap += 1
        return result

    def idx2mgmt_ip(self, idx):
        offset0 = idx // 64
        offset1 = idx % 64
        host_side = f"172.17.{offset0}.{4*offset1+1}"
        guest_side = f"172.17.{offset0}.{4*offset1+2}"
        return host_side, guest_side

    def preallocate(self):
        if os.path.exists("pool.json"):
            print("Skip allocate")
            return

        mgmt_cmds = []

        link_cmds = []
        unused_tap_cmds = []
        start = time.monotonic()

        for mgmt_link in self.mgmt_links:
            cmd = [f"ip tuntap add dev {mgmt_link.tap_name} mode tap",
                   f"ip addr add {mgmt_link.host_side_ip}{mgmt_link.mask} dev {mgmt_link.tap_name}",
                   f"ip link set {mgmt_link.tap_name} up"]

            cmd = ";".join(cmd)

            cmd = [f"{self.netns_prefix} bash -c '{cmd}' "]
            link_cmds.append(cmd)

        for link in self.normal_links:
            tap0 = link.tap0_name
            tap1 = link.tap1_name
            br = link.br_name
            cmd = [f"ip link add name {br} type bridge",
                   f"ip tuntap add dev {tap0} mode tap",
                   f"ip tuntap add dev {tap1} mode tap",
                    f"sysctl -w net.ipv6.conf.{br}.autoconf=0;sysctl -w net.ipv6.conf.{br}.accept_ra=0",
                    f"sysctl -w net.ipv6.conf.{tap0}.autoconf=0;sysctl -w net.ipv6.conf.{tap0}.accept_ra=0",
                    f"sysctl -w net.ipv6.conf.{tap1}.autoconf=0;sysctl -w net.ipv6.conf.{tap1}.accept_ra=0",
                   f"ip link set {br} up",
                   f"ip link set {tap0} up",
                   f"ip link set {tap1} up",
                   f"ip link set dev {tap0} master {br}",
                   f"ip link set dev {tap1} master {br}"]

            cmd = ";".join(cmd)

            cmd = [f"{self.netns_prefix} bash -c '{cmd}'"]

            link_cmds.append(cmd)

        for tap_name in self.unused_tap_names:
            cmd = [
                f"ip tuntap add dev {tap_name} mode tap",
                f"ip link set {tap_name} up"
            ]
            cmd = ";".join(cmd)
            cmd = [f"{self.netns_prefix} bash -c '{cmd}'"]
            unused_tap_cmds.append(cmd)

        records = []

        records += self.cocurrent_run_command(mgmt_cmds)
        records += self.cocurrent_run_command(link_cmds)
        records += self.cocurrent_run_command(unused_tap_cmds)

        end = time.monotonic()

        print("allocation time", end-start)

        with open(f"{self.result_dir}/pool.log", "w") as f:
            f.writelines([str(rec) for rec in records])

        print("preallocate done")

        with open(f"pool.json", "w") as f:
            data = {"num_unused": len(self.unused_tap_names), "num_mgmt": len(
                self.mgmt_links), "num_links": len(self.normal_links), "netns": self.netns}
            json.dump(data, f)

    def cocurrent_run_command(self, cmds):
        with ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    lambda c: run_commands(c),
                    cmd
                )
                for cmd in cmds
            ]
        records = []
        for future in as_completed(futures):
            records += future.result()

        return records


def calculate_resource_demand(blueprint):
    max_num_nics = 1
    for router in blueprint["routers"]:
        max_num_nics = max(max_num_nics, len(router["neighbors"]))

    unused, used = 0, 0

    for router in blueprint["routers"]:
        unused += (max_num_nics-len(router["neighbors"]))
        assert max_num_nics-len(router["neighbors"]) >= 0
        used += len(router["neighbors"])
    assert used % 2 == 0
    num_normal_links = used//2
    num_mgmt_links = len(blueprint["routers"])
    num_unused = unused

    print(num_normal_links, num_mgmt_links, num_unused)
    return num_normal_links, num_mgmt_links, num_unused


if __name__ == "__main__":
    blueprint_path = "./conf/crpd/fattree20/blueprint.json"

    with open(blueprint_path) as f:
        blueprint = json.load(f)

    num_normal_links, num_mgmt_links, num_unused = calculate_resource_demand(
        blueprint)

    if not os.path.exists("./pool"):
        os.mkdir("pool")

    # pool = LinkPool(netns="pool", num_mgmt_links=num_mgmt_links,
    #                 num_normal_links=num_normal_links, num_unused_tap=num_unused, result_dir="./pool")
    # start = time.monotonic()
    # pool.preallocate()
    # end = time.monotonic()
    # print(end-start)
        # pool = LinkPool(netns="pool", num_mgmt_links=num_mgmt_links,

    # pool = LinkPool(netns="pool", num_mgmt_links=0,
    #                num_normal_links=28000, num_unused_tap=0, result_dir="./pool")
    
    # pool.preallocate()
