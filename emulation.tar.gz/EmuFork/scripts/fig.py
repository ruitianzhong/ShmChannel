import csv
import json
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import scienceplots


def make_plot(func, file_name,fig_size=None):
    plt.style.use(["science", "grid", "no-latex"])
    import matplotlib as mpl
    from cycler import cycler

    vivid_colors = [
        "#1F77B4",
        "#FF7F0E",
        "#2CA02C",
        "#D62728",
        "#9467BD",
        "#8C564B",
        "#E377C2",
        "#7F7F7F",
    ]

    old_cycle = mpl.rcParams["axes.prop_cycle"]
    markers = None
    for c in old_cycle:
        if "marker" in c:
            markers = [d["marker"] for d in old_cycle]
            break

    new_cycle = cycler(color=vivid_colors) + \
        cycler(marker=markers) if markers else cycler(color=vivid_colors)

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [
                "Lucida Sans Unicode",
                "DejaVu Serif",
                "Times New Roman",
                "Nimbus Roman",
            ],
        }
    )
    mpl.rcParams["axes.prop_cycle"] = new_cycle

    Path(file_name).parent.mkdir(parents=True, exist_ok=True)

    _ = plt.figure(figsize=fig_size)
    ax = plt.gca()

    legend_kwargs = func() or {}
    if "nolegend" not in legend_kwargs:
        legend = plt.legend(fancybox=False, edgecolor="black", **legend_kwargs)
        legend.get_frame().set_linewidth(0.5)

    width = 0.5
    ax.spines["left"].set_linewidth(width)
    ax.spines["bottom"].set_linewidth(width)
    ax.spines["right"].set_linewidth(width)
    ax.spines["top"].set_linewidth(width)
    ax.tick_params(width=width)

    plt.savefig(file_name)
    plt.close()


def bg_boot_breakdown():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20']
    converge_time = [25.1, 22.83, 23, 22.09]    # 蓝色 Converge 时间（秒）
    boot_time = [250.73, 290.23, 394.34, 469.08]
    network_time = [5.98, 9.20, 11.47, 18.45]

    # config_agnostic_time = [211.38, 242.62, 325.33, 375.06]
    # others_time = [network+converge+boot-agnostic for network,
    #                converge, boot, agnostic in zip(network_time, converge_time, boot_time, config_agnostic_time)]
    config_agnostic_time = boot_time
    others_time = [network+converge for network,
                   converge, boot, agnostic in zip(network_time, converge_time, boot_time, config_agnostic_time)]
    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    rects1 = ax.bar(x - width/2, config_agnostic_time, width,
                    label='In-image Init', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, others_time, width,
                    label='Others', color='#ff7f0e', zorder=2)

    ax.set_xlabel('Topology', fontsize=12)  # 黄色标签
    ax.set_ylabel('Time (Seconds)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)
    ax.set_yscale('log')
    ax.set_ylim(8, 2000)
    # ax.set_yticks(list(range(100, 600, 100)))
    # ax.legend(loc='upper left')
    ax.tick_params(axis="x", rotation=0)
    print(boot_time, others_time)
    boot_percent = [boot/(boot+other)
                    for boot, other in zip(boot_time, others_time)]
    print("boot percent", boot_percent)
    # plt.ylim(top=600)
    # ax.tick_params(axis='y', linestyle='--')


def bg_boot_breakdown_triple():
    topologies = ['FT10', 'FT12', 'FT14', 'FT16', 'FT18', 'FT20']

    lwc_converge_time = [25.93, 27.7, 25.1, 22.83, 23.00, 22.09]
    lwc_boot_time = [124,	180, 250.73, 290.23, 394.34, 469.08]
    lwc_network_time = [3.7, 5.77, 5.98, 9.20, 11.47, 18.45]

    vm_network, vm_boot, vm_converge = [3.33,	5.25,	9.04, 0, 0, 0], [
        38.83, 67.11,	78.28, 0, 0, 0], [25.2, 25.2,	30, 0, 0, 0]

    # config_agnostic_time = [211.38, 242.62, 325.33, 375.06]
    # others_time = [network+converge+boot-agnostic for network,
    #                converge, boot, agnostic in zip(network_time, converge_time, boot_time, config_agnostic_time)]

    vm_total = [converge+boot+network for converge, boot,
                network in zip(vm_converge, vm_boot, vm_network)]
    vm_other = [converge+network for converge, boot,
                network in zip(vm_converge, vm_boot, vm_network)]

    lwc_total = [converge+boot+network for converge, boot,
                 network in zip(lwc_converge_time, lwc_boot_time, lwc_network_time)]
    lwc_other = [converge+network for converge, boot,
                 network in zip(lwc_converge_time, lwc_boot_time, lwc_network_time)]

    x = np.arange(len(topologies))
    width = 0.35
    


    ax = plt.gca()


    rects2 = ax.bar(x - width/2, vm_total, width,
                    label='VM', color='#ff7f0e')
    rects1 = ax.bar(x + width/2, lwc_total, width,
                    label='Container', color='#1f77b4')

    ax.bar(x + width/2, lwc_boot_time, width, edgecolor="black",
           label='In-image init', color='none', hatch='///')

    ax.bar(x - width/2, vm_boot, width, edgecolor="black",
           color='none', hatch='///')

    ax.bar(x + width/2, lwc_other, width, bottom=lwc_boot_time,
           label='Others', edgecolor="black", color='none', hatch=None)

    ax.bar(x - width/2, vm_other, width, bottom=vm_boot,
           color='none', edgecolor="black", hatch=None)

    ax.set_xlabel('Topology', fontsize=12)  # 黄色标签
    ax.set_ylabel('Time (Seconds)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)
    # ax.set_yscale('log')
    # ax.set_ylim(8, 2000)
    # ax.set_yticks(list(range(100, 600, 100)))
    # ax.legend(loc='upper left')
    ax.tick_params(axis="x", rotation=0)

    # boot_percent = [boot/(boot+other)
    #                 for boot, other in zip(boot_time, others_time)]
    # print("boot percent", boot_percent)
    # plt.ylim(top=600)
    # ax.tick_params(axis='y', linestyle='--')


def bg_memory_breakdown_triple():
    topologies = ['FT10', 'FT12', 'FT14', 'FT16', 'FT18', 'FT20']

    vm_total, vm_dirty = [704.51, 705.42, 702.17,
                          0, 0, 0], [117.05, 119, 122, 0, 0, 0]

    lwc_total, lwc_dirty = [203.4,
                            203.6,
                            205.62,
                            209.02,
                            211.37,
                            214.81], [70.38,
                                      73.6,
                                      79.13,
                                      86.08,
                                      88.43,
                                      92.07
                                      ]

    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()

    rects2 = ax.bar(x - width/2, vm_total, width,
                    label='VM', color='#ff7f0e')
    rects1 = ax.bar(x + width/2, lwc_total, width,
                    label='Container', color='#1f77b4')
    
    
    ax.bar(x - width/2, vm_dirty, width, edgecolor="black",
           color='none', hatch='///')

    ax.bar(x + width/2, lwc_dirty, width, edgecolor="black",
           label='Dirtied Memory', color='none', hatch='///')


    ax.set_xlabel('Topology', fontsize=12)  # 黄色标签
    ax.set_ylabel('Memory Usage (MB)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)
    # ax.set_yscale('log')
    # ax.set_ylim(8, 2000)
    # ax.set_yticks(list(range(100, 600, 100)))
    # ax.legend(loc='upper left')
    ax.tick_params(axis="x", rotation=0)

    # boot_percent = [boot/(boot+other)
    #                 for boot, other in zip(boot_time, others_time)]
    # print("boot percent", boot_percent)
    # plt.ylim(top=600)
    # ax.tick_params(axis='y', linestyle='--')
    # return {"fontsize":10}


def bg_vm_boot_breakdown():
    topologies = ['FT10', 'FT12', 'FT14']

    vm_network, vm_boot, vm_converge = [3.33,	5.25,	9.04], [
        38.83, 67.11,	78.28], [25.2, 25.2,	30]

    others_time = [network+converge for network,
                   converge in zip(vm_network, vm_converge)]
    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    rects1 = ax.bar(x - width/2, vm_boot, width,
                    label='In-image Init', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, others_time, width,
                    label='Others', color='#ff7f0e', zorder=2)

    ax.set_xlabel('Topology', fontsize=12)  # 黄色标签
    ax.set_ylabel('Time (Seconds)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)
    # ax.set_yscale('log')
    # ax.set_ylim(8, 2000)
    # ax.set_yticks(list(range(100, 600, 100)))
    # ax.legend(loc='upper left')
    ax.tick_params(axis="x", rotation=0)
    boot_percent = [boot/(boot+other)
                    for boot, other in zip(vm_boot, others_time)]
    print("vm boot percent", boot_percent)
    plt.ylim(top=100)
    # ax.tick_params(axis='y', linestyle='--')

# 调整布局
    plt.tight_layout()
    return {}


def bg_memory():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20']
    dirty = [79.13, 86.08, 88.43, 92.07]
    pss = [205.62, 209.02, 211.37, 214.81]

    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x - width/2, dirty, width,
                    label='soft-dirty size', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, pss, width,
                    label='PSS', color='#ff7f0e', zorder=2)

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Memory Usage (MB)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=0)
    # ax.tick_params(axis='y', linestyle='--')
    plt.ylim(top=470)

    plt.tight_layout()
    return {}

    # plt.savefig('time_breakdown.png', dpi=300, bbox_inches='tight')


def eval_mem():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    baseline = [49, 65, 84, 106, 152]
    emufork = [35, 47, 59, 74, 107]

    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x - width/2, emufork, width,
                    label='EmuFork', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, baseline, width,
                    label='Default', color='#ff7f0e', zorder=2)

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Peak Memory (GB)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=0)
    # ax.tick_params(axis='y', linestyle='--')
    # plt.ylim(top=470)

    percent = [round((base-fork)/base, 2)
               for base, fork in zip(baseline, emufork)]

    print("Memory percentage", percent)

    plt.tight_layout()
    return {}


def eval_total_time():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    baseline_network, baseline_boot, baseline_converge = [
        5.98, 9.20, 11.47, 18.45, 6.96], [250.73, 290.23, 394.34, 469.08, 700.87], [25.1, 22.83, 23.00, 22.09, 22.66]
    emufork_network, emufork_boot, emufork_converge = [
        9.78, 15.02, 22.60, 31.47, 23.06], [19.41, 26.71, 37.69, 53.59, 58.29], [30.86, 27.09, 24.60, 27.00, 23.83]
    baseline_total = [network+boot+converge for network, boot,
                      converge in zip(baseline_network, baseline_boot, baseline_converge)]
    emufork_total = [network+boot+converge for network, boot,
                     converge in zip(emufork_network, emufork_boot, emufork_converge)]
    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x - width/2, emufork_total, width,
                    label='EmuFork', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, baseline_total, width,
                    label='Default', color='#ff7f0e', zorder=2)

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Total Time (s)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=0)
    # ax.tick_params(axis='y', linestyle='--')
    # plt.ylim(top=470)

    plt.tight_layout()
    print(emufork_total, baseline_total)
    percentage = [round((baseline-emufork)/baseline, 2)
                  for emufork, baseline in zip(emufork_total, baseline_total)]
    print("time percentage", percentage)
    return {}


def eval_mem_triple():
    topologies = ['FT10', 'FT12', 'FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    baseline = [24, 36, 49, 65, 84, 106, 152]
    emufork = [17, 25, 35, 47, 59, 74, 107]
    vm = [86, 124,	168, 0, 0, 0, 0]

    x = np.arange(len(topologies))
    width = 0.3

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)

    rects1 = ax.bar(x-width, emufork, width,
                    label='EmuFork', color='#1f77b4', zorder=2)
    ax.bar(x+width, vm, width,
           label='VM', color="green", zorder=2)
    rects2 = ax.bar(x, baseline, width,
                    label='Container', color='#ff7f0e', zorder=2)

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Peak Memory (GB)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=30)
    # ax.tick_params(axis='y', linestyle='--')
    plt.ylim(top=250)

    percent = [round((base-fork)/base, 2)
               for base, fork in zip(baseline, emufork)]

    print("Memory percentage", percent)

    plt.tight_layout()
    return {"fontsize": 8}


def eval_total_time_stacked_bar():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    baseline_network, baseline_boot, baseline_converge = [
        5.98, 9.20, 11.47, 18.45, 6.96], [250.73, 290.23, 394.34, 469.08, 700.87], [25.1, 22.83, 23.00, 22.09, 22.66]
    emufork_network, emufork_boot, emufork_converge = [
        9.78, 15.02, 22.60, 31.47, 23.06], [19.41, 26.71, 37.69, 53.59, 58.29], [30.86, 27.09, 24.60, 27.00, 23.83]
    baseline_total = [network+boot+converge for network, boot,
                      converge in zip(baseline_network, baseline_boot, baseline_converge)]
    emufork_total = [network+boot+converge for network, boot,
                     converge in zip(emufork_network, emufork_boot, emufork_converge)]
    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x - width/2, emufork_total, width,
                    label='EmuFork', color='#1f77b4')
    rects2 = ax.bar(x + width/2, baseline_total, width,
                    label='Default', color='#ff7f0e')

    baseline_other = [total-boot for total,
                      boot in zip(baseline_total, baseline_boot)]

    emufork_other = [total-boot for total,
                     boot in zip(emufork_total, emufork_boot)]
    # ax.bar(x - width/2, emufork_other, width,
    #                 label='Others', color='none', edgecolor='black', hatch='')
    # ax.bar(x + width/2, baseline_other, width,
    #          label='Others', color='white', edgecolor='black', hatch='')

    ax.bar(x - width/2, emufork_boot, width,
           label='Resume', color='none', edgecolor='black', hatch='//')
    ax.bar(x + width/2, baseline_boot, width,
           color='none', edgecolor='black', hatch='xx', label="In-image Init")

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Total Time (s)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=0)
    # ax.tick_params(axis='y', linestyle='--')
    # plt.ylim(top=470)

    plt.tight_layout()
    print(emufork_total, baseline_total)
    percentage = [round((baseline-emufork)/baseline, 2)
                  for emufork, baseline in zip(emufork_total, baseline_total)]
    print("time percentage", percentage)
    return {"fontsize": 9}


def eval_total_time_three_stacked_bar():
    topologies = ['FT10', 'FT12', 'FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    baseline_network, baseline_boot, baseline_converge = [3.7, 5.77, 5.98, 9.20, 11.47, 18.45, 6.96], [
        124,	180, 250.73, 290.23, 394.34, 469.08, 700.87], [25.93, 27.7, 25.1, 22.83, 23.00, 22.09, 22.66]
    emufork_network, emufork_boot, emufork_converge = [3.37,	5.95,
                                                       9.78, 15.02, 22.60, 31.47, 23.06], [9.21, 13.87, 19.41, 26.71, 37.69, 53.59, 58.29], [27.32, 28.16, 30.86, 27.09, 24.60, 27.00, 23.83]

    vm_network, vm_boot, vm_converge = [3.33,	5.25,	9.04, 0, 0, 0, 0], [
        38.83, 67.11,	78.28, 0, 0, 0, 0], [25.2, 25.2,	30, 0, 0, 0, 0]
    baseline_total = [network+boot+converge for network, boot,
                      converge in zip(baseline_network, baseline_boot, baseline_converge)]
    emufork_total = [network+boot+converge for network, boot,
                     converge in zip(emufork_network, emufork_boot, emufork_converge)]

    vm_total = [network+boot+converge for network, boot,
                converge in zip(vm_network, vm_boot, vm_converge)]

    vm_other = [network+converge for network, boot,
                converge in zip(vm_network, vm_boot, vm_converge)]
    x = np.arange(len(topologies))
    width = 0.3

    ax = plt.gca()

    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x-width, emufork_total, width,
                    label='EmuFork', color='#1f77b4')
    ax.bar(x+width, vm_total, width,
           label='VM', color='green')

    rects2 = ax.bar(x, baseline_total, width,
                    label='Container', color='#ff7f0e')

  

    baseline_other = [total-boot for total,
                      boot in zip(baseline_total, baseline_boot)]

    emufork_other = [total-boot for total,
                     boot in zip(emufork_total, emufork_boot)]

    # ax.bar(x + width/2, baseline_other, width,
    #          label='Others', color='white', edgecolor='black', hatch='')

    ax.bar(x-width, emufork_boot, width,
           label='Resume', color='none', edgecolor='black', hatch='////')
    ax.bar(x, baseline_boot, width,
           color='none', edgecolor='black', hatch='xx', label="In-image Init")
    ax.bar(x+width, vm_boot, width,
           color='none', edgecolor='black', hatch='xx')

    ax.bar(x - width, emufork_other, width, bottom=emufork_boot,
           label='Others', color='none', edgecolor='black', hatch='')

    ax.bar(x, baseline_other, width, bottom=baseline_boot,
           color='none', edgecolor='black', hatch='')

    ax.bar(x+width, vm_other, width, bottom=vm_boot,
           color='none', edgecolor='black', hatch='')

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Total Time (s)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=30)

    # ax.tick_params(axis='y', linestyle='--')
    # plt.ylim(top=470)

    plt.tight_layout()
    print(emufork_total, baseline_total)
    percentage = [round((baseline-emufork)/baseline, 2)
                  for emufork, baseline in zip(emufork_total, baseline_total)]
    print("time percentage", percentage)
    return {"fontsize": 8}


def eval_mitigation():
    topologies = ['FT14', 'FT16', 'FT18', 'FT20', 'KDL']
    without_mitigation = [25.88, 42.93, 74.10, 130.72, 66.98]
    with_mitigation = [19.41, 26.71, 37.69, 53.59, 58.29]

    x = np.arange(len(topologies))
    width = 0.35

    ax = plt.gca()
    # ax.grid(True, which="both", ls="--", axis="y", zorder=0)
    rects1 = ax.bar(x - width/2, with_mitigation, width,
                    label='w/ Mitigation', color='#1f77b4', zorder=2)
    rects2 = ax.bar(x + width/2, without_mitigation, width,
                    label='w/o Mitigation', color='#ff7f0e', zorder=2)

    # ax.set_yscale('log')
    # ax.set_ylim(8, 4000)

    ax.set_xlabel('Topology', fontsize=12)
    ax.set_ylabel('Resume Time (s)', fontsize=12)
    ax.set_xticks(x)
    ax.set_xticklabels(topologies)

    ax.tick_params(axis="x", rotation=0)
    # ax.tick_params(axis='y', linestyle='--')
    # plt.ylim(top=470)

    plt.tight_layout()
    return {}


def load_data(path):
    with open(path) as f:
        return json.load(f)


def dump_cpu_csv(input_file, output_file):
    data = load_data(input_file)

    with open(output_file, "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp", "usage"])
        for ts, usage in zip(data["ts"], data["guest"]):
            writer.writerow([ts, usage])


def eval_cpu_usage():
    emufork_path = "../../crpd_fattree14_single_ns_result_mitigation/cpu.json"
    vm_share_path = "../../crpd_fattree14_single_ns_share_vm_result_mitigation/cpu.json"
    no_fork_path = "../../crpd_fattree14_single_ns_no_fork_result_mitigation/cpu.json"
    # lwc_path = "../../REAL-artifact-evaluation/results/baseline_crpd_fattree14_cpu-profile_0-47_2026-03-08_15-26-13/cpu.json"
    lwc_path = "../../REAL-artifact-evaluation/results/baseline_crpd_fattree14_cpu-profile_0-47_2026-03-08_15-56-36/cpu.json"
    ax = plt.gca()

    dump_cpu_csv(emufork_path, "ft14_emufork_cpu.csv")
    dump_cpu_csv(no_fork_path, "ft14_vm_cpu.csv")

    emufork_data = load_data(emufork_path)
    vm_share_data = load_data(vm_share_path)
    no_fork_data = load_data(no_fork_path)

    lwc_data = load_data(lwc_path)

    ax.plot(
        emufork_data["ts"],
        emufork_data["guest"],
        marker='o',
        linestyle='-',
        color="#10A330",
        linewidth=1,
        markersize=1,
        markeredgewidth=1,

        label='Emufork'
    )

    # ax.plot(
    #     vm_share_data["ts"],
    #     vm_share_data["guest"],
    #     marker='o',
    #     linestyle='-',
    #     color='#2E86AB',
    #     linewidth=1,
    #     markersize=1,
    #     markeredgewidth=1,

    #     label='start after fork'
    # )

    ax.plot(
        no_fork_data["ts"],
        no_fork_data["guest"],
        marker='o',
        linestyle='-',
        color='orange',
        linewidth=1,
        markersize=1,
        markeredgewidth=1,
        label='VM'
    )

    # ax.plot(
    #     lwc_data["ts"],
    #     lwc_data["guest"],
    #     marker='o',
    #     linestyle='-',
    #     color="#DE2156",
    #     linewidth=1,
    #     markersize=1,
    #     markeredgewidth=1,

    #     label='lwc'
    # )

    legend = plt.legend(fancybox=False, edgecolor="black",
                       loc='upper right')
    # legend.get_frame().set_linewidth(0.5)

    # ax.set_title('Dirty memory', fontsize=16, pad=20)
    ax.set_xlabel('Time (s)', fontsize=12, labelpad=10)
    ax.set_ylabel('CPU Usage (%)', fontsize=12, labelpad=10)

    return {"nolegend"}


def dump_dirty_data(output_file, input_file):
    with open(input_file) as f:
        data = json.load(f)
    with open(output_file, "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp", "dirty "])
        for idx, ts in enumerate(data["ts"]):
            dirty = data["dirty"][idx]["anon"]
            writer.writerow([ts, dirty])


def ascending_order(arr):
    idx = 1
    while idx < len(arr):
        assert arr[idx-1] <= arr[idx]
        idx += 1


def eval_dirty_mem():
    ax = plt.gca()

    topo = ["fattree18", "fattree"]

    ft20_path = "../../crpd_fattree20_single_ns_result_mitigation/dirty.json"
    kdl_path = "../../crpd_topozoo_Kdl_single_ns_result_mitigation/dirty.json"
    ft18_path = "../../crpd_fattree18_single_ns_result_mitigation/dirty.json"
    ft16_path = "../../crpd_fattree16_single_ns_result_mitigation/dirty.json"

    dump_dirty_data("fp18_dirty.csv", ft18_path)
    dump_dirty_data("fp20_dirty.csv", ft20_path)
    dump_dirty_data("kdl_dirty.csv", kdl_path)

    ft20_dict = load_data(ft20_path)
    kdl_dict = load_data(kdl_path)
    ft18_dict = load_data(ft18_path)
    ft16_dict = load_data(ft16_path)

    ft20_ts = ft20_dict["ts"]
    ft20_dirty = ft20_dict["dirty"]
    kdl_dirty = kdl_dict["dirty"]
    kdl_ts = kdl_dict["ts"]
    ft18_dirty = ft18_dict["dirty"]
    ft18_ts = ft18_dict["ts"]
    ft16_dirty = ft16_dict["dirty"]
    ft16_ts = ft16_dict["ts"]

    ft20_anon = [e["anon"] for idx, e in enumerate(ft20_dirty) if idx % 2 == 0]
    ft20_ts = [e+49.40 for idx, e in enumerate(ft20_ts) if idx % 2 == 0]
    kdl_ts = [e+31.41 for idx, e in enumerate(
        kdl_ts) if idx % 2 == 0 and kdl_dict["ts"][idx] <= 70]
    kdl_anon = [e["anon"]
                for idx, e in enumerate(kdl_dirty) if idx % 2 == 0 and kdl_dict["ts"][idx] <= 70]

    ft18_ts = [e+30.68 for idx, e in enumerate(
        ft18_ts) if idx % 2 == 0]
    ft18_anon = [e["anon"]
                 for idx, e in enumerate(ft18_dirty) if idx % 2 == 0]

    # ft16_ts = [e+15.02 for idx, e in enumerate(
    #     ft16_ts) if idx % 2 == 0 ]
    # ft16_anon = [e["anon"]
    #              for idx, e in enumerate(ft16_dirty) if idx % 2 == 0]

    # print(kdl_ts)
    ascending_order(ft16_ts)
    ascending_order(ft18_ts)
    ascending_order(ft18_anon)
    ascending_order(ft20_anon)
    ascending_order(kdl_anon)
    ascending_order(ft20_ts)
    ascending_order(kdl_ts)

    # ax.plot(
    #     ft16_ts,
    #     ft16_anon,
    #     marker='o',
    #     linestyle='-',
    #     color="#C2112F",
    #     linewidth=1,
    #     markersize=1,
    #     markeredgewidth=2,

    #     label='FT16'
    # )
    print(kdl_ts)

    ax.plot(
        ft18_ts,
        ft18_anon,
        marker='o',
        linestyle='-',
        color="#10A330",
        linewidth=1,
        markersize=1,
        markeredgewidth=2,

        label='FT18'
    )

    ax.plot(
        ft20_ts,
        ft20_anon,
        marker='o',
        linestyle='-',
        color='#2E86AB',
        linewidth=1,
        markersize=1,
        markeredgewidth=2,

        label='FT20'
    )

    ax.plot(
        kdl_ts,
        kdl_anon,
        marker='o',
        linestyle='-',
        color='orange',
        linewidth=1,
        markersize=1,
        markeredgewidth=2,

        label='KDL'
    )

    # ax.set_title('Dirty memory', fontsize=16, pad=20)
    ax.set_xlabel('Time (s)', fontsize=12, labelpad=10)
    ax.set_ylabel('Dirty Memory (MB)', fontsize=12, labelpad=10)

#     ax.axhline(
#     y=205,                # 纵坐标位置（关键参数）
#     color='red',          # 横线颜色（可自定义，比如'#FF0000'）
#     linestyle='--',       # 线型（虚线更醒目，也可用'-'实线）
#     linewidth=1.5,        # 线宽
#     # label='Baseline dirty mem after init'  # 图例标签（可选）
# )


make_plot(bg_boot_breakdown, "bg_breakdown.pdf")
# make_plot(bg_memory, "bg_memory.pdf")
make_plot(eval_mem, "eval_mem.pdf")
make_plot(eval_total_time, "eval_total_time.pdf")
make_plot(eval_mitigation, "eval_mitigation.pdf")

make_plot(eval_dirty_mem, "eval_dirty_mem.pdf",(5.5,3))

make_plot(eval_cpu_usage, "eval_cpu_usage.pdf",(5.5,3))
make_plot(eval_total_time_stacked_bar, "eval_total_time_breakdown.pdf")

make_plot(eval_total_time_three_stacked_bar,
          "eval_total_time_vm_emufork_container.pdf")
make_plot(eval_mem_triple, "eval_mem_vm_emufork_container.pdf")
make_plot(bg_vm_boot_breakdown, "bg_vm_boot_breakdown.pdf")
make_plot(bg_boot_breakdown_triple,
          "bg_boot_breakdown_triple.pdf",(5,2.8))

make_plot(bg_memory_breakdown_triple,
          "bg_mem_breakdown_triple.pdf",(5,2.8))


if __name__ == "__main__":
    pass
