#!/usr/bin/env python3
import json
import argparse
import glob
import os
import sys
import time
import subprocess
import struct
from typing import Dict, Optional, Tuple, List
import time

# Page size (Linux default is 4KB, verify with getconf PAGESIZE)
PAGE_SIZE = 4096
# Each entry in pagemap file occupies 8 bytes
PAGEMAP_ENTRY_SIZE = 8
# softdirty flag position in pagemap entry (bit 55)
SOFTDIRTY_BIT = 1 << 55


def check_root():
    """Check if running as root user, exit if not"""
    if os.geteuid() != 0:
        print("Error: This script requires root privileges to run!", file=sys.stderr)
        sys.exit(1)


def clear_softdirty(pid: int):
    """Write to /proc/PID/clear_refs to clear softdirty flags"""
    clear_refs_path = f"/proc/{pid}/clear_refs"
    if not os.path.exists(clear_refs_path):
        print(
            f"Error: Process {pid} does not exist, or {clear_refs_path} is inaccessible", file=sys.stderr)
        return

    try:
        # Writing 1 clears softdirty flags (defined in official documentation)
        with open(clear_refs_path, "w") as f:
            f.write("4")
        print(f"Cleared softdirty flags for process {pid}")
    except Exception as e:
        print(f"Failed to clear softdirty flags: {e}", file=sys.stderr)
        # sys.exit(1)
        return


def parse_pmap(pid: int) -> Tuple[List[Dict], int]:
    """
    Execute pmap -x PID and parse output
    Returns: (list of memory region info, total RSS in KB)
    """
    try:
        # Execute pmap -x and get output
        result = subprocess.check_output(
            ["pmap", "-x", str(pid)],
            text=True,
            stderr=subprocess.STDOUT
        )
        print(result, file=sys.stderr)
    except subprocess.CalledProcessError as e:
        print(f"Failed to execute pmap -x {pid}: {e.output}", file=sys.stderr)
        return None, None

    memory_regions = []
    total_rss_kb = 0
    lines = result.strip().split("\n")
    # Skip first two lines (pmap header), parse memory region lines
    for line in lines[2:]:
        line = line.strip()
        # Skip empty lines
        if not line:
            continue

        # Parse total RSS from summary line (e.g., "total kB  12345  6789  1011")
        if "total" in line:
            total_parts = line.split()
            if len(total_parts) >= 4:
                try:
                    # 4th column is total RSS in KB
                    total_rss_kb = int(total_parts[3])
                except ValueError:
                    print(
                        "Warning: Failed to parse total RSS from pmap output", file=sys.stderr)
            continue

        # Split line content (format: address perms size_rss dirty device inode mapped_file)
        # pmap -x columns: Address Perms Size RSS Dirty Mode Mapping
        parts = line.split()
        if len(parts) < 6:  # Ensure at least 6 columns (add RSS column check)
            continue

        # Extract address

        start_addr = int(parts[0], 16)
        addr_len_kb = int(parts[1])
        end_addr = start_addr+addr_len_kb*1024

        # Calculate number of pages in this region
        page_count = (end_addr - start_addr) // PAGE_SIZE

        # Parse RSS (3rd column, unit: KB) and convert to pages (RSS_KB / (PAGE_SIZE/1024))
        try:
            region_rss_kb = int(parts[2])  # 4th element (index 3) is RSS in KB
            region_dirty_kb = int(parts[3])
            # 4KB per page → divide by 4
            region_rss_pages = region_rss_kb // (PAGE_SIZE // 1024)
            region_dirty_pages = region_dirty_kb // (PAGE_SIZE//1024)
        except ValueError:
            region_rss_kb = 0
            region_rss_pages = 0
            print(
                f"Warning: Failed to parse RSS for region {line}", file=sys.stderr)
        region = {
            "start_addr": start_addr,
            "end_addr": end_addr,
            "page_count": page_count,
            "permissions": parts[4],
            "mapping": parts[-1] if len(parts) == 6 else parts[-2],
            "rss_kb": region_rss_kb,       # RSS in KB
            # RSS in pages (aligned with page size)
            "rss_pages": region_rss_pages,
            "region_dirty_kb": region_dirty_kb,
            "dirty_pages": region_dirty_pages
            # "original_output": line
        }
        memory_regions.append(region)

    if not memory_regions:
        print(
            f"No memory region information parsed for process {pid}", file=sys.stderr)
        return None, None
    print(
        f"Number of memory regions parsed for process {pid}: {len(memory_regions)}")
    print(
        f"Total RSS for process {pid}: {total_rss_kb} KB ({total_rss_kb // (PAGE_SIZE//1024)} pages)")
    return memory_regions, total_rss_kb


def get_pid_namespace_inode(pid):
    ns_path = f"/proc/{pid}/ns/pid"
    try:
        ns_link = os.readlink(f"/proc/{pid}/ns/pid")
        # 格式示例：pid:[4026531836]，提取括号内的inode
        inode = ns_link.split(":")[1].strip("[]")
        print(inode)
        return inode
    except (FileNotFoundError, PermissionError) as e:
        print(f"Cannot access namespace for PID {pid}: {e}", file=sys.stderr)
        return None


def get_all_pids_in_namespace(target_inode):
    namespace_pids = []
    for proc_dir in glob.glob("/proc/[0-9]*"):

        pid = int(os.path.basename(proc_dir))
        try:
            ns_link = os.readlink(f"/proc/{pid}/ns/pid")
            inode = ns_link.split(":")[1].strip("[]")
            if inode == target_inode:
                namespace_pids.append(pid)
        except (FileNotFoundError, PermissionError, OSError):
            continue
    return namespace_pids


def calculate_total_pss(pid_list: List[int]):
    """
    Calculate the total PSS (Proportional Set Size) sum for a list of PIDs (in MB, 2 decimal places).

    Args:
        pid_list: List of process IDs (can be int type)

    Returns:
        Total PSS sum in MB (float, 2 decimal places) if successful; None if all PIDs are invalid/failed.

    Raises:
        OSError: If running on non-Linux system (no /proc filesystem)
        PermissionError: If no read access to /proc/[pid]/smaps (run with sudo)
    """
    # Validate Linux platform (PSS relies on /proc/smaps)
    if not os.path.exists("/proc"):
        raise OSError(
            "This function only works on Linux (requires /proc filesystem)")

    total_pss_kb = 0.0

    for pid in pid_list:
        try:
            pid_int = int(pid)
            smaps_path = f"/proc/{pid_int}/smaps"

            # Skip if PID does not exist or smaps is inaccessible
            if not os.path.exists(smaps_path):
                print(
                    f"[WARNING] PID {pid_int}: smaps file not found (process may be terminated)")
                continue

            # Parse smaps to sum PSS (KB)
            with open(smaps_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("Pss:"):
                        total_pss_kb += float(line.split()[1])

        except ValueError:
            print(f"[WARNING] '{pid}' is not a valid PID (must be integer)")
            continue
        except PermissionError:
            raise PermissionError(
                f"[ERROR] No permission to read smaps (run with sudo)")
        except Exception as e:
            print(f"[WARNING] PID {pid}: Failed to parse PSS - {str(e)}")
            continue

    # Convert KB to MB (1 MB = 1024 KB) and round to 2 decimal places
    total_pss_mb = round(total_pss_kb / 1024, 2)

    # Return None if no valid PSS data (all PIDs failed)
    return total_pss_mb if total_pss_mb > 0 else None


def count_softdirty_pages(pid: int, regions: List[Dict], pfn_set: set, overall_stat: dict) -> List[Dict]:
    """Read /proc/PID/pagemap and count softdirty pages for each memory region"""
    pagemap_path = f"/proc/{pid}/pagemap"
    if not os.path.exists(pagemap_path):
        print(f"Error: {pagemap_path} is inaccessible", file=sys.stderr)
        sys.exit(1)

    # Initialize softdirty page count for each region
    for region in regions:
        region["softdirty_count"] = 0

    try:
        with open(pagemap_path, "rb") as f:
            for region in regions:
                start_addr = region["start_addr"]
                end_addr = region["end_addr"]

                # Calculate starting page index of this region (address / page size)
                start_page_idx = start_addr // PAGE_SIZE
                end_page_idx = end_addr // PAGE_SIZE

                # Move file pointer to the pagemap entry position of the starting page
                f.seek(start_page_idx * PAGEMAP_ENTRY_SIZE)

                # Iterate through all pages in this region
                for page_idx in range(start_page_idx, end_page_idx):
                    # Read 8-byte pagemap entry
                    entry_data = f.read(PAGEMAP_ENTRY_SIZE)
                    if len(entry_data) != PAGEMAP_ENTRY_SIZE:
                        print(hex(start_addr))
                        print("Out of file range")
                        break  # Out of file range, stop reading

                    # Parse as 64-bit unsigned integer
                    entry = struct.unpack("<Q", entry_data)[0]
                    present = (entry >> 63) & 1
                    swapped = (entry >> 62) & 1
                    pfn = entry & ((1 << 55) - 1)
                    if present == 1 and pfn != 0 and (pfn not in pfn_set) and (entry & SOFTDIRTY_BIT):
                        pfn_set.add(pfn)
                        overall_stat["dedup_softdirty"] += 1

                    # Check if softdirty bit is set
                    if entry & SOFTDIRTY_BIT and present == 1 and pfn != 0:
                        region["softdirty_count"] += 1

                if region["softdirty_count"] > region["rss_pages"]:
                    print("weird thing", region, file=sys.stderr)

    except Exception as e:
        print(f"Failed to read pagemap: {e}", file=sys.stderr)
        sys.exit(1)

    return regions


def get_pid_list(init_pid):
    inode = get_pid_namespace_inode(init_pid)
    return get_all_pids_in_namespace(inode)


class MemoryProfiler:
    def __init__(self, init_pid, result_dir):
        self.init_pid = init_pid
        check_root()
        self.pids = get_pid_list(self.init_pid)
        print("pids", self.pids, file=sys.stderr)
        self.result_dir = result_dir

    def collect_before_clear_stat(self):
        pfn_set = set()
        result = {"dedup_softdirty": 0}
        total_pg_cnt = 0
        total_dirty = 0
        result_lists = []
        for pid in self.pids:
            regions, total_rss_kb = parse_pmap(pid)
            if regions is None:
                print(f"pid {pid} is None", file=sys.stderr)
                continue
            result_lists.append(regions)
            regions = count_softdirty_pages(pid, regions, pfn_set, result)
            for region in regions:
                if "w" in region["permissions"]:
                    total_pg_cnt += region["rss_pages"]
                    total_dirty += region["softdirty_count"]

        print("mem before", total_pg_cnt, total_dirty,
              result["dedup_softdirty"], file=sys.stderr)
        with open(f"{self.result_dir}/memory_before.log", "w") as f:
            json.dump(result_lists, f)
        return total_pg_cnt, total_dirty

    def clear_softdirty(self):
        self.pids = get_pid_list(self.init_pid)
        for pid in self.pids:
            clear_softdirty(pid)

    def collect_after_clear_stat(self):
        self.pids = get_pid_list(self.init_pid)
        time.sleep(120)
        pfn_set = set()
        result = {"dedup_softdirty": 0}
        total_pg_cnt = 0
        total_dirty = 0
        total_all_dirty = 0
        result_lists = []
        for pid in self.pids:
            regions, total_rss_kb = parse_pmap(pid)
            if regions is None:
                print(f"after pid {pid} is None", file=sys.stderr)
                continue
            regions = count_softdirty_pages(pid, regions, pfn_set, result)
            result_lists.append(regions)
            for region in regions:
                if "w" in region["permissions"]:
                    # if True:
                    total_pg_cnt += region["rss_pages"]
                    total_dirty += region["softdirty_count"]
                total_all_dirty += region["dirty_pages"]
        print("mem after stat", total_pg_cnt, total_dirty,
              result["dedup_softdirty"], f"total_all_dirty_pages={total_all_dirty}", file=sys.stderr)
        with open(f"{self.result_dir}/memory_after.log", "w") as f:
            json.dump(result_lists, f)

        total_pss_mb = calculate_total_pss(self.pids)
        print("total_pss_mb=", total_pss_mb, file=sys.stderr)
        return total_pg_cnt, total_dirty


def main():
    """Main function"""
    pid = 4040377
    # Check root privileges
    check_root()

    # Step 1: Clear softdirty flags
    clear_softdirty(pid)

    # Step 2: Wait for specified time

    # Step 3: Parse pmap to get memory regions and total RSS
    regions, total_rss_kb = parse_pmap(pid)

    # # Step 4: Count softdirty pages for each region
    regions = count_softdirty_pages(pid, regions)

    for region in regions:
        start = hex(region["start_addr"])

        soft_dirty = region["softdirty_count"]
        mapping = region["mapping"]
        pg_cnt = region["page_count"]
        print(start, soft_dirty, pg_cnt, mapping)


if __name__ == "__main__":
    # main()
    parser = argparse.ArgumentParser("mem_profiler")

    parser.add_argument("--pid")
    parser.add_argument("--mode")

    args = parser.parse_args()

    if args.mode == "clear":
        pass
