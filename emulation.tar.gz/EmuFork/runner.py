import time

from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess


class CmdRecord:
    def __init__(self, cmd, node, t0, t1, result):
        self.ts_start = t0
        self.duration = t1 - t0
        self.cmd = cmd
        self.node = node
        self.r = result
        self.rc = result.returncode
        self.stdout = str(result.stdout) if result.stdout is not None else ""
        self.stderr = str(result.stderr) if result.stderr is not None else ""

    def __str__(self) -> str:
        s = f"{self.ts_start}: [{self.node}] {self.cmd}"
        if self.stdout:
            s += f"\nstdout: {self.stdout}"
        if self.stderr:
            s += f"\nstderr: {self.stderr}"
        return s + "\n"


def run_command(cmd, node=-1, timeout=None):
    t0 = time.monotonic()
    result = subprocess.run(
        cmd, shell=True, capture_output=True, text=True, timeout=timeout
    )
    t1 = time.monotonic()
    return CmdRecord(cmd, node, t0, t1, result)


def run_commands_for_routers(routers, get_cmd_list, *args, **kwargs):
    with ThreadPoolExecutor() as executor:
        futures = [
            executor.submit(
                lambda r: [
                    run_command(cmd, node=r["idx"])
                    for cmd in get_cmd_list(r, *args, **kwargs)
                ],
                router,
            )
            for router in routers
        ]
        records = []
        for future in as_completed(futures):
            records += future.result()
        return records


def run_func_for_routers(routers, func, *args, **kwargs):
    with ThreadPoolExecutor() as executor:
        futures = [executor.submit(func, router, *args, **kwargs)
                   for router in routers]
        records = []
        for future in as_completed(futures):
            records += future.result()
        return records


def container_pid(blueprint):
    pid_dict = {}
    records = run_commands_for_routers(
        blueprint["routers"],
        lambda r: [
            "docker inspect -f '{{.State.Pid}}' "+Runner.container_name(r)],
    )
    for rec in records:
        pid = rec.stdout.strip()
        pid_dict[rec.node] = pid

    return pid_dict, records


def getcmd_create_veth_pernode(router, pid_dict):
    idx1 = router["idx"]
    pid1 = pid_dict[idx1]

    commands = []
    for neighbor in router["neighbors"]:
        idx2 = neighbor["peeridx"]
        pid2 = pid_dict[idx2]

        if idx1 > idx2:
            continue

        veth1_name = neighbor["ifname"]
        veth2_name = neighbor["peerifname"]

        port1 = neighbor["ifname"]
        port2 = neighbor["peerifname"]

        ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
        ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"

        commands += [
            f"ln -sf /proc/{pid1}/ns/net /var/run/netns/{pid1}",
            f"ln -sf /proc/{pid2}/ns/net /var/run/netns/{pid2}",
            f"ip link add {veth1_name} type veth peer name {veth2_name}",
            f"ip link set {veth1_name} netns {pid1}",
            f"ip netns exec {pid1} ip link set {veth1_name} name {port1}",
            f"ip netns exec {pid1} ip link set {port1} up",
            f"ip netns exec {pid1} ip addr add {ip1} dev {port1}",
            f"ip link set {veth2_name} netns {pid2}",
            f"ip netns exec {pid2} ip link set {veth2_name} name {port2}",
            f"ip netns exec {pid2} ip link set {port2} up",
            f"ip netns exec {pid2} ip addr add {ip2} dev {port2}",
        ]

    return commands


def create_network_veth(blueprint):
    rec = run_command("mkdir -p /var/run/netns")
    pid_dict, records = container_pid(blueprint)

    records += run_commands_for_routers(
        blueprint["routers"], getcmd_create_veth_pernode, pid_dict
    )

    return [rec] + records


class Runner:
    def __init__(self, image, topo, blueprint):
        self.image = image
        self.topo = topo
        self.blueprint = blueprint

    @staticmethod
    def container_name(router):
        return f'emu-real-{router["idx"]}'

    def config_filename(self, router):
        return f'conf/{self.image}/{self.topo}/node_{router["idx"]}.conf'

    @staticmethod
    def ipc_path(self, router):
        return f"/opt/lwc/volumes/ripc/{self.container_name(router)}"

    @staticmethod
    def log_path(router):
        return f"/opt/lwc/containers/{Runner.container_name(router)}/rootfs/var/log/real"

    def env_dir(self, r):
        raise "Not implemented yet"

    @staticmethod
    def neigh_str(r):
        return ",".join(
            [
                f'{neigh["self_ip"]}:{neigh["neighbor_ip"]}:{neigh["peeridx"]}'
                for neigh in r.get("neighbors", [])
            ]
            + [""]  # trailing comma! Our C file checks for it.
        )

    def create_containers(self):
        return []

    def create_network(self):
        return create_network_veth(self.blueprint)

    def start_daemons(self):
        return []

    def stop_container(self):
        return self.run_commands_forall(
            lambda r: [f'docker stop {self.container_name(r)}']
        )

    def remove_container(self):
        return self.run_commands_forall(
            lambda r: [
                f'docker rm {self.container_name(r)}'
            ]
        )

    def run_commands_forall(self, get_cmd_list):
        routers_filtered = [
            r for r in self.blueprint["routers"]]
        return run_commands_for_routers(routers_filtered, get_cmd_list)

    def run_func_forall(self, get_cmd_list):
        routers_filtered = [r for r in self.blueprint["routers"]]
        return run_func_for_routers(routers_filtered, get_cmd_list)


class FrrBaseline(Runner):
    def create_containers(self):
        return self.run_commands_forall(
            lambda r: [
                # need to add --privileged
                f"docker create --privileged --name {self.container_name(r)} real-frr tini -- sleep infinity",
                f"docker cp {self.config_filename(r)} {self.container_name(r)}:/etc/frr/frr.conf",
                f"docker cp ./daemons {self.container_name(r)}:/etc/frr/daemons",
                f"docker start {self.container_name(r)}"
            ],
        )

    def start_daemons(self):
        return self.run_commands_forall(
            lambda r: [
                f'docker exec -u root -d {self.container_name(r)} '
                + f"bash -c 'mkdir -p /var/log/real/; chmod 777 /var/log/real/; /usr/lib/frr/frrinit.sh start &> /var/log/real/frrinit.log'"
            ]
        )

    def stop_container(self):
        return self.run_commands_forall(
            lambda r: [f'docker stop {self.container_name(r)}']
        )

    def remove_container(self):
        return self.run_commands_forall(
            lambda r: [
                f'docker rm {self.container_name(r)}'
            ]
        )


class CrpdBaseline(Runner):
    def create_containers(self):
        return self.run_commands_forall(
            lambda r: [
                f"docker create --name {self.container_name(r)} --privileged  real-crpd /sbin/runit-init.sh",
                f"docker cp {self.config_filename(r)} {self.container_name(r)}:/etc/crpd/crpd.conf",
                f"docker start {self.container_name(r)}",
            ]
        )

    def start_daemons(self):
        def boot_single_router(r):
            records = [
                run_command(
                    f"docker exec {self.container_name(r)} mkdir -p /var/license/"
                ),
                run_command(
                    f"docker cp ./crpd-license {self.container_name(r)}:/var/license/crpd-license"
                ),
            ]
            while True:
                rec = run_command(
                    f"docker exec {self.container_name(r)} cli -c 'request system license add /var/license/crpd-license'"
                    # f"docker exec {self.container_name(r)} strace -ttt -ff -o /strace.log cli -c 'request system license add /var/license/crpd-license'"
                )
                records.append(rec)
                if "add license complete" in rec.stdout:
                    break
                time.sleep(0.5)

            records.append(
                run_command(
                    f"docker exec {self.container_name(r)} bash -c 'cli << EOF\nconfig\nload override /etc/crpd/crpd.conf\ncommit\nEOF\n'"
                )
            )
            return records

        return self.run_func_forall(boot_single_router)


class BirdBaseline(Runner):
    def create_containers(self):
        return self.run_commands_forall(
            lambda r: [
                f"docker create --name {self.container_name(r)} real-bird tini -- sleep infinity",
                f"docker cp {self.config_filename(r)} {self.container_name(r)}:/etc/bird/bird.conf",
                f"docker start {self.container_name(r)}",
                f"docker exec {self.container_name(r)} bash -c 'mkdir -p /var/log/real/; chmod 777 /var/log/real/'",
            ]
        )

    def start_daemons(self):
        return self.run_commands_forall(
            lambda r: [f"docker exec {self.container_name(r)} bird"],
        )


class UbuntuRunner(Runner):
    def create_containers(self):
        return self.run_commands_forall(
            lambda r: [
                f"docker run -itd --name {self.container_name(r)} ubuntu"
            ]
        )

    def start_daemons(self):
        return []
