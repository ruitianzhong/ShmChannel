#!/usr/bin/env python3
"""
check_bgp_summary.py

Check whether there are any down BGP neighbors in the bgp_summary-final.log files of each node under the specified results_dir.
Supports three image formats: crpd, frr, and bird.

Usage:
    python check_bgp_summary.py -d <path> -i <crpd|frr|bird> -t <topology_name>
"""

import re

from pathlib import Path
from typing import List, Tuple, Set
from runner import Runner
import time


def find_node_logs(results_dir: Path) -> List[Path]:
    node_logs_dir = results_dir / "node_logs"
    if not node_logs_dir.exists():
        raise FileNotFoundError(
            f"{node_logs_dir} not found under {results_dir}")
    return [p for p in node_logs_dir.iterdir() if p.is_dir()]


def parse_crpd_summary(node_id: int, file: Path, blueprint: dict) -> Tuple[bool, str]:
    """Return (is_all_up, reason)"""
    if isinstance(file, Path):
        text = file.read_text(errors="ignore")
    else:
        text = file
    m = re.search(r"Down peers:\s*(\d+)", text)
    if not m:
        return False, "No 'Down peers' field found"
    down_peers = int(m.group(1))
    if down_peers > 0:
        return False, f"{down_peers} down peers detected"
    return True, "All peers established"


def parse_frr_summary(node_id: int, file: Path, blueprint: dict) -> Tuple[bool, str]:
    text = file.read_text(errors="ignore")
    if re.search(r"State/PfxRcd\s+", text) is None:
        return False, "No FRR peer section found"
    down_lines = []
    npeers = 0
    for line in text.splitlines():
        if re.search(r"^([0-9]+\.){3}[0-9]+\b", line) is None:
            continue
        if not line.split()[-3].isdigit():
            down_lines.append(line.strip())
        else:
            npeers += 1

    npeers_expected = len(blueprint["routers"][node_id - 1]["neighbors"])
    if npeers != npeers_expected:
        return False, f"Expected {npeers_expected} peers, found {npeers}"

    if down_lines:
        return False, f"{len(down_lines)} peer(s) not established"
    return True, "All peers established"


def parse_bird_summary(node_id: int, file: Path, blueprint: dict) -> Tuple[bool, str]:
    text = file.read_text(errors="ignore")
    npeers = 0
    for line in text.splitlines():
        if "BGP" not in line:
            continue
        if re.search(r"BGP\s+.*\bup\b.*Established", line) is None:
            return False, f"BGP peer {line.split()[0]} not up"
        npeers += 1

    npeers_expected = len(blueprint["routers"][node_id - 1]["neighbors"])
    if npeers != npeers_expected:
        return False, f"Expected {npeers_expected} peers, found {npeers}"
    return True, "All peers established"


def check_node_str(image: str, blueprint: dict, node_id, summary_str):
    if image == "crpd":
        return parse_crpd_summary(node_id, summary_str, blueprint)
    elif image == "frr":
        return parse_frr_summary(node_id, summary_str, blueprint)
    elif image == "bird":
        return parse_bird_summary(node_id, summary_str, blueprint)
    else:
        raise ValueError(f"Unsupported image type: {image}")


def check_node(node_dir: Path, image: str, blueprint: dict) -> Tuple[str, bool, str]:
    node_id = int(node_dir.name.replace("emu-real-", ""))
    summary_file = node_dir / "bgp_summary-final.log"
    assert summary_file.exists()
    if image == "crpd":
        return node_dir.name, *parse_crpd_summary(node_id, summary_file, blueprint)
    elif image == "frr":
        return node_dir.name, *parse_frr_summary(node_id, summary_file, blueprint)
    elif image == "bird":
        return node_dir.name, *parse_bird_summary(node_id, summary_file, blueprint)
    else:
        raise ValueError(f"Unsupported image type: {image}")


def find_node_logs(results_dir: Path) -> List[Path]:
    node_logs_dir = results_dir / "node_logs"
    if not node_logs_dir.exists():
        raise FileNotFoundError(
            f"{node_logs_dir} not found under {results_dir}")
    return [p for p in node_logs_dir.iterdir() if p.is_dir()]


# ---------------------------------------------------------------------------
# Route parsing logic for each image type
# ---------------------------------------------------------------------------


def parse_frr_routes(file) -> Set[str]:
    """Extract advertised/learned network prefixes from FRR output."""
    if isinstance(file, Path):
        text = file.read_text(errors="ignore")
    else:
        text = file
    routes = set()
    in_table = False
    for line in text.splitlines():
        if line.startswith("For address family"):
            in_table = True
            continue
        if in_table:
            if line.strip().startswith("Displayed"):
                break
            m = re.match(
                r"^\s*[*>=]+\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+)", line)
            if m:
                routes.add(m.group(1))
    return routes


def parse_crpd_routes(file) -> Set[str]:
    """Extract learned prefixes from crpd output (inet.0 table only)."""
    if isinstance(file, str):
        text = file
    else:
        text = file.read_text(errors="ignore")
    routes = set()
    for line in text.splitlines():
        m = re.match(r"^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+)", line.strip())
        if m:
            routes.add(m.group(1))
    return routes


def parse_bird_routes(file: Path) -> Set[str]:
    """Extract routes from BIRD's Table master4."""
    text = file.read_text(errors="ignore")
    routes = set()
    in_table = False
    for line in text.splitlines():
        if line.startswith("Table master4:"):
            in_table = True
            continue
        if in_table:
            if not line.strip() or line.startswith("Table"):
                break
            m = re.match(
                r"^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+)", line.strip())
            if m:
                routes.add(m.group(1))
    return routes


def expected_prefixes(blueprint: dict) -> Set[str]:
    """Return all prefixes this node should learn."""
    routers = blueprint["routers"]
    prefixes = set()
    for r in routers:
        for n in r.get("networks", []):
            prefixes.add(f"{n}/24")
    return prefixes


def check_node_routes_str(expected: Set[str], image: str, route_str: str):

    if image == "crpd":
        routes = parse_crpd_routes(route_str)
    elif image == "frr":
        routes = parse_frr_routes(route_str)
    elif image == "bird":
        routes = parse_bird_routes(route_str)
    else:
        raise ValueError(f"Unsupported image type: {image}")

    missing = expected - routes
    # extra = routes - expected

    if missing:
        return False, f"Missing prefixes: {', '.join(sorted(missing))}"
    # Optional: if strict matching is desired, also check for extra prefixes
    return True, f"All {len(routes)} prefixes present"


def check_node_routes(
    expected: Set[str], node_dir: Path, image: str
) -> Tuple[str, bool, str]:
    routes_file = node_dir / "bgp_routes-final.log"
    assert routes_file.exists()

    if image == "crpd":
        routes = parse_crpd_routes(routes_file)
    elif image == "frr":
        routes = parse_frr_routes(routes_file)
    elif image == "bird":
        routes = parse_bird_routes(routes_file)
    else:
        raise ValueError(f"Unsupported image type: {image}")

    missing = expected - routes
    # extra = routes - expected

    if missing:
        return node_dir.name, False, f"Missing prefixes: {', '.join(sorted(missing))}"
    # Optional: if strict matching is desired, also check for extra prefixes
    return node_dir.name, True, f"All {len(routes)} prefixes present"


def collect_bgp_routes(runner: Runner, result_dir):
    image = runner.image
    record = []
    if image == "frr":
        record += runner.run_commands_forall(lambda r: [
            f"mkdir -p {result_dir}/node_logs/{runner.container_name(r)}/",
            f"timeout -k 100 1 docker exec -u root {runner.container_name(r)} bash -c \"vtysh -c 'show ip bgp summary' &> /var/log/real/bgp_summary-final.log\" || true",
            f"docker cp {runner.container_name(r)}:/var/log/real/bgp_summary-final.log  \"{result_dir}/node_logs/{runner.container_name(r)}/bgp_summary-final.log\" || true",
            f"timeout -k 100 1 docker exec -u root {runner.container_name(r)} bash -c \"vtysh -c 'show bgp all' &> /var/log/real/bgp_routes-final.log\" || true",
            f"docker cp {runner.container_name(r)}:/var/log/real/bgp_routes-final.log  \"{result_dir}/node_logs/{runner.container_name(r)}/bgp_routes-final.log\" || true"
        ])
    elif image == "crpd":
        record += runner.run_commands_forall(lambda r: [
            f"mkdir -p {result_dir}/node_logs/{runner.container_name(r)}/",
            f"docker exec -u root {runner.container_name(r)} cli -c \"show route\" > {result_dir}/node_logs/{runner.container_name(r)}/bgp_routes-final.log || true",
            f"docker exec -u root {runner.container_name(r)} cli -c \"show bgp summary\" > {result_dir}/node_logs/{runner.container_name(r)}/bgp_summary-final.log || true"
        ])
    elif image == "bird":
        record += runner.run_commands_forall(lambda r: [
            f"mkdir -p {result_dir}/node_logs/{runner.container_name(r)}/",
            f"docker exec {runner.container_name(r)} bash -c \"birdc show route &> /var/log/real/bgp_routes-final.log\" || true",
            f"docker exec {runner.container_name(r)} bash -c \"birdc show protocols &> /var/log/real/bgp_summary-final.log\" || true",
            f"docker cp {runner.container_name(r)}:/var/log/real/bgp_routes-final.log \"{result_dir}/node_logs/{runner.container_name(r)}/bgp_routes-final.log\" || true",
            f"docker cp {runner.container_name(r)}:/var/log/real/bgp_summary-final.log \"{result_dir}/node_logs/{runner.container_name(r)}/bgp_summary-final.log\" || true"
        ])
    else:
        raise "Not implemented"

    return record


def check_bgp_summary_for_routers(blueprint, image, results_dir) -> None:
    results_dir = Path(results_dir).resolve()

    failed = []
    passed = []
    node_dirs = find_node_logs(results_dir)

    for node_dir in sorted(node_dirs):
        summary_file = node_dir / "bgp_summary-final.log"
        if not summary_file.exists():
            continue
        name, ok, msg = check_node(node_dir, image, blueprint)
        if not ok:
            # print(f"{name:15s} FAIL {msg}")
            failed.append(name)
        else:
            passed.append(name)

    if failed:
        return False, f"Summary: {len(failed)} node(s) have issues: {', '.join(failed)}"
    elif len(passed) == 0:
        print("Summary: No bgp_summary-final.log found.")
        raise BaseException("No bgp log")
    else:
        print("Summary: All nodes are healthy.")
    return True, ""


def check_bgp_route_for_routers(result_dir, blueprint, image):

    results_dir = Path(result_dir).resolve()

    passed = []
    failed = []
    node_dirs = find_node_logs(results_dir)

    prefixes = expected_prefixes(blueprint)
    for node_dir in sorted(node_dirs):
        routes_file = node_dir / "bgp_routes-final.log"
        if not routes_file.exists():
            continue
        name, ok, msg = check_node_routes(prefixes, node_dir, image)
        if not ok:
            # print(f"{name:15s} FAIL {msg}")
            failed.append(name)
        else:
            passed.append(name)

    if failed:
        print("Number of route failed", len(failed))
        return False, f"Summary: {len(failed)} node(s) have route issues: {', '.join(failed)}"
    elif len(passed) == 0:
        print("Summary: No bgp_routes-final.log found.")
        raise BaseException("No bgp_route log found")
    else:
        print("Summary: All nodes have complete routes.")

    return True, ""


def check_bgp(runner: Runner, results_dir: str) -> list:
    records = []
    idx = 0
    while True:
        records += collect_bgp_routes(runner, results_dir)
        ok1, msg1 = check_bgp_route_for_routers(
            results_dir, runner.blueprint, runner.image)
        ok2, msg2 = check_bgp_summary_for_routers(
            runner.blueprint, runner.image, results_dir)

        if ok1 and ok2:
            print("route converge")
            break
        print("wait converge {}".format(idx))
        time.sleep(30)
        idx += 1
        if idx == 40:
            raise BaseException("Converged timeout")

    return records
