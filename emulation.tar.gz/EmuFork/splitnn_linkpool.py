
from concurrent.futures import ThreadPoolExecutor, as_completed

from vm_utils import run_commands
from runner import run_command
import json
import time


def concurrent_run_command(cmds):
    with ThreadPoolExecutor() as executor:
        futures = [
            executor.submit(
                lambda c: run_commands(c),
                cmd
            )
            for cmd in cmds
        ]
        records = []
        for future in as_completed(futures):
            records += future.result()

        # records = []

        # for cmd in cmds:
        #     records += run_commands(cmd)

        return records


class SplitLink:
    #    veth10<->veth00<->bridge<->veth01<->veth11
    def __init__(self, base_netns, base0, base1, bridge, router0, router1):
        self.veth_base0 = base0
        self.veth_base1 = base1
        self.bridge = bridge
        self.veth_router0 = router0
        self.veth_router1 = router1
        self.base_netns = base_netns

        self.created = False

    def create(self):
        if self.created:
            return
        self.created = True
        prefix = f"ip netns exec {self.base_netns}"
        cmds = [
            f"ip link add name {self.bridge} type bridge",
            f"ip link add {self.veth_base0} type veth peer name {self.veth_router0}",
            f"ip link add {self.veth_base1} type veth peer name {self.veth_router1}",
            f"ip link set {self.veth_base0} up",
            f"ip link set {self.veth_base1} up ",
            f"ip link set {self.bridge} up",
            f"ip link set dev {self.veth_base0} master {self.bridge}",
            f"ip link set dev {self.veth_base1} master {self.bridge}",
        ]

        cmd = ";".join(cmds)

        cmd = f"{prefix} bash -c '{cmd}'"

        rec = run_command(cmd)
        return rec


class SplitNamespaceLinkPool:
    def __init__(self, blueprint: dict):

        num_links = 0
        num_nodes = len(blueprint["routers"])
        for router in blueprint["routers"]:
            num_links += len(router["neighbors"])

        num_links = num_links//2

        links_per_netns = 100
        records = []
        self.links = []

        num_base_netns = (num_nodes+links_per_netns)//links_per_netns
        self.base_netns = []
        for base_netns_idx in range(num_base_netns):
            cur_num_links = num_links - base_netns_idx*links_per_netns

            # Create namespace
            netns_name = f"base_{base_netns_idx}"

            rec = run_command(f"ip netns add {netns_name}")
            records.append(rec)
            for link_idx in range(cur_num_links):
                link = SplitLink(netns_name, base0=f"{base_netns_idx}_{link_idx}_b0", base1=f"{base_netns_idx}_{link_idx}_b1",
                                 bridge=f"br{link_idx}", router0=f"{base_netns_idx}_{link_idx}_r0", router1=f"{base_netns_idx}_{link_idx}_r1")
                records.append(link.create())
                self.links.append(link)
            self.base_netns.append(netns_name)

        self.records = records
        self.current_idx = 0

    def cleanup(self):
        records = []
        for base_netns in self.base_netns:
            records.append(run_command(f"ip netns del {base_netns}"))
            if records[-1].rc != 0:
                print(str(records[-1]))

    def dump(self):
        with open("splitnn.log", "w") as f:
            f.writelines([str(rec) for rec in self.records])

    def get_link(self) -> SplitLink:
        assert self.current_idx < len(self.links)
        link = self.links[self.current_idx]
        self.current_idx += 1
        return link


def create_network(blueprint: dict, netns_list: list, pool: SplitNamespaceLinkPool):
    all_commands = []
    for router in blueprint["routers"]:
        idx1 = router["idx"]
        netns1 = netns_list[idx1-1]

        commands = []
        for neighbor in router["neighbors"]:
            idx2 = neighbor["peeridx"]
            netns2 = netns_list[idx2-1]

            if idx1 > idx2:
                continue
            link = pool.get_link()

            veth1_name = link.veth_router0
            veth2_name = link.veth_router1
            base_netns = link.base_netns

            port1 = neighbor["ifname"]
            port2 = neighbor["peerifname"]

            ip1 = f"{neighbor['self_ip']}/{neighbor['selfip_prefixlen']}"
            ip2 = f"{neighbor['neighbor_ip']}/{neighbor['peerip_prefixlen']}"

            commands += [
                f"ip netns exec {base_netns} ip link set {veth1_name} netns {netns1}",
                f"ip netns exec {base_netns} ip link set {veth2_name} netns {netns2}",

                f"ip netns exec {netns1} ip link set {veth1_name} name {port1}",
                f"ip netns exec {netns1} ip link set {port1} up",
                f"ip netns exec {netns1} ip addr add {ip1} dev {port1}",


                f"ip netns exec {netns2} ip link set {veth2_name} name {port2}",
                f"ip netns exec {netns2} ip link set {port2} up",
                f"ip netns exec {netns2} ip addr add {ip2} dev {port2}",
            ]
        all_commands.append(commands)

    # for commands in all_commands:
    #     for cmd in commands:
    #         rec = run_command(cmd)
    #         if rec.rc != 0:
    #             print(str(rec))

    records = concurrent_run_command(all_commands)

    for rec in records:
        if rec.rc != 0:
            print(str(rec))

    return all_commands


def ping_test(blueprint, netns_list):
    for router in blueprint["routers"]:
        idx = router["idx"]

        for neighbor in router["neighbors"]:
            dest_ip = neighbor['neighbor_ip']
            cmd = f"ip netns exec {netns_list[idx-1]} ping -c 1 {dest_ip}"

            rec = run_command(cmd)

            if rec.rc != 0:
                print(str(rec))

    print("ping test done")


if __name__ == "__main__":
    blueprint_path = "conf/crpd/fattree8/blueprint.json"

    with open(blueprint_path) as f:
        blueprint = json.load(f)

    start = time.monotonic()
    pool = SplitNamespaceLinkPool(blueprint)
    container_netns = []
    records = []
    for idx, router in enumerate(blueprint["routers"]):
        name = f"split_{idx}"

        records += [run_command(f"ip netns add {name}")]
        container_netns.append(name)
    create_base_netns = time.monotonic()
    create_network(blueprint, container_netns, pool)

    end = time.monotonic()
    pool.dump()
    # ping_test(blueprint, container_netns)

    for netns in container_netns:
        run_command(f"ip netns del {netns}")

    pool.cleanup()
    print("create base", create_base_netns-start,
          "create netnwork", end-create_base_netns)
