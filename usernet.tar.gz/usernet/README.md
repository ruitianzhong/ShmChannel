# usernet

纯用户态手搓的**网络协议栈**(raw packet / `AF_PACKET`)用 veth 与**内核常规协议栈**
对擂的实验项目。用户态一侧在 netns 里用 raw socket 充当一个"虚拟网卡上的协议栈",
内核一侧当好它按常规收发的对端基准。当前含 **TCP** 与 **ICMP** 两个示例。

## 原理:为什么用户态 raw 能做到

veth 是一根"虚拟网线",只负责在两端之间**搬运完整以太网帧**,不关心帧是谁
构造、上层协议是什么。你从用户态 raw socket 塞进去的 SYN/ICMP,会原样从对端
veth 出来,被对端**内核**的 L2→L3→L4 正常处理;回包反向同理。所以 veth 两端
实现不同、一端完全跑在用户态,是完全合法的。详见 `examples/tcp/README.md` 的
「raw 收/发路径」与下方「排障」。

## 目录结构

```
usernet/
├── setup.sh / teardown.sh      # 共享拓扑:建 ns1/ns2 + veth + 固定MAC + 静态neigh
└── examples/
    ├── tcp/                    # 用户态 TCP 栈(client) vs 内核 socket(server)
    │   ├── client.c            #   ~250 行极简 TCP 栈:握手/数据/挥手,自算校验和
    │   ├── server.py           #   内核侧普通 socket 服务端(回 PONG)
    │   ├── run_test.sh         #   一键:编译+搭环境+起server+跑client+清理
    │   └── README.md
    └── icmp/                   # 用户态 ICMP server vs ping
        ├── icmp_server.c       #   raw socket 收 echo request → 回 echo reply
        ├── run_ping.sh         #   一键:编译+搭环境+起server+ping+清理
        └── README.md
```

## 拓扑(两版共用)

两个 example 复用同一份共享拓扑,角色方向不同:

- **ns1**(`veth1`,MAC `02:00:00:00:00:01`):用户态栈所在,**不配 IP**;
  `10.0.0.1` 只活在用户态帧里(避免内核抢答)。
- **ns2**(`veth2`,MAC `02:00:00:00:00:02`,`10.0.0.2/24`):内核侧。
- ns2 静态 neigh `10.0.0.1 → 02:00:00:00:00:01` **PERMANENT** → 回包免 ARP;
  → 用户态栈/服务器不需要实现 ARP 应答。

| example | ns1 里跑 | ns2 里跑 |
|---------|----------|----------|
| `tcp/` | `client`(自制 TCP 栈) | `server.py`(内核 socket) |
| `icmp/` | `icmp_server`(自制 ICMP) | `ping`(内核) |

## 用法

```bash
# TCP
cd examples/tcp   && sudo bash run_test.sh [--capture]
# ICMP
cd examples/icmp  && sudo bash run_ping.sh [--capture]
```

`--capture`:让共享 `setup.sh` 后台抓 30s pcap(`veth1_*.pcap` / `veth2_*.pcap`),
默认不抓。各 example 的期望输出见其 README。

## 关键排障:校验和字节序错(byte-swap)

本题项目实际踩过、并同时搞挂 TCP 与 ICMP 两版的头号坑。**现象**:用户态发的帧
对端内核"像是收不到";tcpdump 却显示帧到了对端接口。

**根因**:校验和算出的主机序 `uint16_t` 直接 `=` 给头部字段,忘了 `htons()`。
小端机上字段里放的是反着的字节 → 内核在 L3 `ip_rcv` 校验 IP 头失败 → **静默丢弃**。

**涉及字段(4 处,3 错 1 对)**:

| 位置 | 字段 | 错误写法 | 正确写法 |
|------|------|----------|----------|
| `examples/tcp/client.c` | IPv4 `check` | `i->check = ip_checksum(...)` | `i->check = htons(ip_checksum(...))` |
| `examples/tcp/client.c` | TCP `check`(伪首部) | `t->check = tcp_checksum(...)` | `t->check = htons(tcp_checksum(...))` |
| `examples/icmp/icmp_server.c` | IPv4 `check` | `oi->check = csum(...)` | `oi->check = htons(csum(...))` |
| `examples/icmp/icmp_server.c` | ICMP `checksum` | 手工 `>>8`/`&0xff` 写字节 | **本就正确**(显式大端) |

**定位**:抓 pcap → `tcpdump -r x.pcap -X` 看 hex → 把整段含校验和字段按大端
16 位字累加,标准应为 `0xffff`。request 由内核生成必为 `0xffff`,是很好的对照。

**修**:所有写进头部的校验和包一层 `htons()`。

## 常见坑

- **权限**:raw socket 需 `CAP_NET_RAW`,需 root/`sudo` 运行。
- **甩不掉 ARP 就翻车**:去掉静态 neigh 后内核会发 ARP 找 `10.0.0.1`,用户态不
  应答 → 回包卡住。保留静态 neigh,或补 ARP。
- **校验和字节序**:见上「关键排障」。
- **抓包看帧**:`sudo tcpdump -i vethX -A`(或在可用时 `run_*.sh --capture`)。