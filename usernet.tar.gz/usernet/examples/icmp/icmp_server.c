/*
 * icmp_server.c —— 用户态 ICMP echo 服务端(位于 netns ns1)
 *
 * 用 AF_PACKET, SOCK_RAW 在 veth1 上接收对端(ns2 的 ping)发来的
 * ICMP echo request,拼出 echo reply 回送。与 TCP 版共用同一套拓扑:
 *   固定 MAC + ns2 静态 neigh(10.0.0.1 -> veth1 的 MAC),因此 ping
 *   不需要 ARP 就能直接找到本服务端;本服务端回复时用请求方的 src MAC
 *   作 dst,也无需 ARP。
 *
 * 处理:收到类型=8(echo request)的 ICMP:
 *   1) 把 ICMP type 改成 0(echo reply),清除并重算 ICMP 校验和
 *   2) IP 交换 src/dst 地址,清除并重算 IP 校验和
 *   3) 以太网 dst=请求方 src MAC,src=本端 MAC
 * 其余字节(id/seq/载荷)原样回带,ping 才能认。
 *
 * 编译:  gcc -O2 -Wall -o icmp_server icmp_server.c
 * 运行:  sudo ip netns exec ns1 ./icmp_server    (需 root: CAP_NET_RAW)
 * 对端:  sudo ip netns exec ns2 ping -c 4 -I veth2 10.0.0.1
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>

#define IFNAME   "veth1"
static const unsigned char OUR_MAC[6]  = {0x02,0,0,0,0,1};   /* veth1 */

#define OUR_IPN  htonl(0x0A000001UL)   /* 10.0.0.1, ping 的目标 */
#define PEER_IPN htonl(0x0A000002UL)   /* 10.0.0.2, ns2 端 */

#define ICMP_ECHOREQUEST 8
#define ICMP_ECHOREPLY    0

#pragma pack(push,1)
struct ethh { uint8_t d[6], s[6]; uint16_t proto; };
struct iph  { uint8_t vihl, tos; uint16_t totlen, id, frag;
              uint8_t ttl, proto; uint16_t check; uint32_t saddr, daddr; };
#pragma pack(pop)

/* 互联网校验和:按大端 16 位字累加后取反 */
static uint16_t csum(const uint8_t *d, int n){
    uint32_t s = 0; int i;
    for (i = 0; i + 1 < n; i += 2) s += ((uint16_t)d[i] << 8) | d[i+1];
    if (i < n) s += (uint16_t)d[i] << 8;
    while (s >> 16) s = (s & 0xffff) + (s >> 16);
    return (uint16_t)~s;
}

int main(void){
    int ifidx = if_nametoindex(IFNAME);
    if (!ifidx){ fprintf(stderr, "找不到接口 %s (先跑 setup.sh)\n", IFNAME); return 1; }

    int fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (fd < 0){ perror("socket"); return 1; }
    struct sockaddr_ll ba;
    memset(&ba, 0, sizeof ba);
    ba.sll_family = AF_PACKET;
    ba.sll_protocol = htons(ETH_P_ALL);
    ba.sll_ifindex = ifidx;
    if (bind(fd, (struct sockaddr *)&ba, sizeof ba) < 0){ perror("bind"); return 1; }

    printf("[icmp-server] 监听 veth1(10.0.0.1),等待 echo request...\n");
    fflush(stdout);

    uint8_t buf[2048];
    for (;;){
        struct sockaddr_ll from; socklen_t fl = sizeof from;
        ssize_t rl = recvfrom(fd, buf, sizeof buf, 0, (struct sockaddr *)&from, &fl);
        if (rl <= 0) continue;

        if (rl < 14 + 20) continue;
        struct ethh *e = (struct ethh *)buf;
        if (ntohs(e->proto) != ETH_P_IP) continue;              /* 只处理 IPv4 */
        struct iph *ip = (struct iph *)(buf + 14);
        int ihl = (ip->vihl & 0x0f) * 4;                        /* IP 头长度 */
        if (ihl < 20) continue;
        if (ip->proto != 1) continue;                           /* 只要 ICMP */
        int ip_len = ntohs(ip->totlen);
        if (ip_len < ihl + 8 || ip->daddr != OUR_IPN) continue; /* 发给我们 10.0.0.1 */

        uint8_t *icmp = buf + 14 + ihl;                         /* ICMP 起点 */
        int icmp_len = ip_len - ihl;                            /* ICMP + 数据 */
        if (icmp[0] != ICMP_ECHOREQUEST) continue;              /* 只要 echo request */

        uint8_t out[2048];
        struct ethh *oe = (struct ethh *)out;
        struct iph  *oi = (struct iph  *)(out + 14);

        /* 以太网: dst = 请求方 src MAC, src = 本端 MAC */
        memcpy(oe->d, buf + 6, 6);
        memcpy(oe->s, OUR_MAC, 6);
        oe->proto = htons(ETH_P_IP);

        /* IP: 复制请求的 IP 头,交换 src/dst,重算校验和 */
        memcpy(oi, ip, ihl);
        oi->saddr = ip->daddr;      /* 回复源 = 请求目的(10.0.0.1) */
        oi->daddr = ip->saddr;      /* 回复目的 = 请求源(10.0.0.2) */
        oi->check = 0;
        oi->check = htons(csum(out + 14, ihl));   /* 校验和必须是网络序! */

        /* ICMP: 类型改 0,清校验和,连同 id/seq/载荷原样回带,重算 */
        uint8_t *oic = out + 14 + ihl;
        memcpy(oic, icmp, icmp_len);
        oic[0] = ICMP_ECHOREPLY;
        oic[2] = 0; oic[3] = 0;                       /* 校验和区清零(大端) */
        uint16_t icsum = csum(oic, icmp_len);
        oic[2] = (uint8_t)(icsum >> 8);
        oic[3] = (uint8_t)(icsum & 0xff);

        int flen = 14 + ip_len;
        struct sockaddr_ll so;
        memset(&so, 0, sizeof so);
        so.sll_family  = AF_PACKET;
        so.sll_ifindex = ifidx;
        so.sll_halen   = 6;
        memcpy(so.sll_addr, oe->d, 6);
        ssize_t sr = sendto(fd, out, flen, 0, (struct sockaddr *)&so, sizeof so);
        if (sr < 0) perror("sendto reply");  /* 打出发送是否报错 */

        printf("[icmp-server] echo reply: id=0x%02x%02x seq=%u len=%dB\n",
               oic[4], oic[5], ((uint16_t)oic[6] << 8) | oic[7], icmp_len - 8);
        fflush(stdout);
    }
    close(fd);
    return 0;
}