# 示例:用户态 ICMP server vs ping

用 raw socket 在 `veth1` 上收 `ping`(ns2 内核)发来的 echo request,拼出 echo reply
回送。与 TCP 示例**共用同一套 veth 拓扑**(固定 MAC + 静态 neigh 免 ARP),只是
角色反过来、把上层协议换成 ICMP —— 验证"同一份 veth + 免 ARP 拓扑换协议照样成立"。

## 架构

```
 netns ns1 (用户态 ICMP server)        netns ns2 (ping 客户端)
 ┌───────────────────────┐          ┌───────────────────────┐
 │ ./icmp_server (C,raw) │          │ ping -I veth2         │
 │ AF_PACKET, SOCK_RAW   │   veth   │        10.0.0.1       │
 │ veth1 ←10.0.0.1(虚拟) │◄────────►│ veth2 10.0.0.2/24     │
 │                       │          │  ip neigh: 10.0.0.1   │
 └───────────────────────┘          │        -> 02..:01      │
                                    └───────────────────────┘
```

- ns1 里 `icmp_server` 用 raw socket 收 echo request(ICMP type 8),把 type 改 0、
  交换 IP/以太网地址、重算 IP+ICMP 校验和,回 echo reply。
- ns2 里直接 `ping`(内核)。用户态只在一侧顶起"协议栈",内核只需照常收发。
- **不需要 ARP**:ns2 静态 neigh 直接告诉 ping `10.0.0.1 → veth1 的 MAC`;
  reply 的 dst 用请求方的 src MAC。

## 处理要点

收到 type=8 的 echo request:
1. ICMP `type` 改 0(echo reply),清零并重算 **ICMP 校验和**;
2. IP 交换 `src/dst` 地址,清零并重算 **IP 校验和**(注意 `htons()`,见下);
3. 以太网 `dst`=请求方 src MAC,`src`=本端 MAC;
4. `id/seq/载荷` 原样回带,`ping` 才能认。
5. 每次 reply 打印一行日志。

## 文件

| 文件 | 作用 |
|------|------|
| `icmp_server.c` | 用户态 ICMP echo server(raw socket),约 110 行 |
| `run_ping.sh` | 一键:编译 → 共享 setup → 起 server(ns1) → ping(ns2) → 清理 |
| (共享) `../..` | 根目录的 `setup.sh`/`teardown.sh` 提供拓扑 |

## 用法

```bash
sudo bash run_ping.sh            # 一键(默认不抓包)
sudo bash run_ping.sh --capture  # 后台抓 30s pcap
```

预期输出:

- 服务端(每 request 一条):
  ```
  [icmp-server] 监听 veth1(10.0.0.1),等待 echo request...
  [icmp-server] echo reply: id=0x1234 seq=1 len=56B
  ```
- `ping` 侧应显示 `64 bytes from 10.0.0.1: icmp_seq=N ... time=...`,且 **0% 丢包**。

## 排障

- **校验和字节序**:IP 校验和写头部时必须包 `htons()`,否则字节反了被内核静默
  丢弃 → ping 100% 丢、但 tcpdump 显示 reply 已到对端接口。这是最经典的一个,
  见根目录 README「关键排障」。
- 若 reply 显式写在字节序无误(ICMP 用 `>>8`/`&0xff` 手工写大端),则只需检查
  IP 字段那处 `htons()`。