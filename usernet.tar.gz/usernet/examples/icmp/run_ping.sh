#!/bin/bash
# 一键: 编译ICMP server -> 搭环境 -> 起用户态服务端(ns1) -> ns2 里 ping -> 清理
# 需 root: sudo -E bash run_ping.sh
set -e
cd "$(dirname "$0")"
ROOT="$(cd ../.. && pwd)"   # 仓库根(从 examples/icmp 上两级),共享 setup.sh 在那

echo "=== 编译用户态 ICMP server ==="
gcc -O2 -Wall -o icmp_server icmp_server.c

echo "=== 搭环境(共享拓扑) ==="
sudo bash "$ROOT/setup.sh" "$@"   # 透传 --capture 等参数给 setup.sh

echo "=== 启动用户态 ICMP server(ns1) ==="
sudo ip netns exec ns1 ./icmp_server & SRV=$!
trap 'kill $SRV 2>/dev/null || true' EXIT
sleep 0.8

echo "=== ns2 里 ping 10.0.0.1 ==="
sudo ip netns exec ns2 ping -c 4 -W 1 -I veth2 10.0.0.1
RV=$?

echo "服务端 PID SRV=$SRV"     # $SRV 常是 sudo/ip 层 PID,非真实服务进程
# 直接按命令名 kill -9 真实服务进程($SRV 那层 sudo 不一定转发信号)
pkill -9 -f icmp_server 2>/dev/null || true
wait $SRV 2>/dev/null || true
echo "=== ping 退出码: $RV (0=有收到回复) ==="
exit $RV