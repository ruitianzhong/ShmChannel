#!/usr/bin/env python3
# 内核侧服务端:常规 socket,位于 netns ns2
# 收到数据后回送 "PONG" 并关闭 —— 触发与自定义栈的完整四次挥手
import socket
import signal
import sys

PORT = 8080

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", PORT))
    s.listen(5)
    print(f"[kernel-server] listening on 0.0.0.0:{PORT}", flush=True)
    while True:
        conn, addr = s.accept()
        print(f"[kernel-server] accept {addr}", flush=True)
        try:
            data = conn.recv(4096)
            print(f"[kernel-server] recv {len(data)}B: {data!r}", flush=True)
            conn.sendall(b"PONG")
            print("[kernel-server] sent PONG, closing", flush=True)
        except Exception as e:
            print(f"[kernel-server] err: {e}", flush=True)
        finally:
            conn.close()

if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))
    main()