# 示例:用户态 TCP 栈 vs 内核 socket

自制极简 TCP 栈(`client.c`)用 raw packet 在 `veth1` 上收发整条 Ethernet+IPv4+TCP 帧,
与 ns2 里运行在 `veth2(10.0.0.2)` 上的内核常规 socket 走完整 TCP:
**三次握手 → 发 PING → 收 PONG → 四次挥手**。

## 架构

```
 netns ns1 (自定义 TCP 栈)          netns ns2 (内核常规 socket)
 ┌──────────────────────┐          ┌──────────────────────┐
 │   ./client (C, raw)  │          │ python3 server.py     │
 │   AF_PACKET,SOCK_RAW │  veth    │  socket(AF_INET, .)   │
 │   ┌──────────────┐   │◄────────►│   bind 0.0.0.0:8080   │
 │   │ veth1        │   │ 一根"网线" │   veth2 10.0.0.2/24   │
 │   │ 10.0.0.1(虚拟)│   │          │                      │
 │   │ 02..:01       │   │          │   ip neigh: 10.0.0.1 │
 │   └──────────────┘   │          │        -> 02..:01     │
 └──────────────────────┘          └──────────────────────┘
```

- 自定义栈(客户端)在 **ns1** 里用 raw socket 收发整条帧,自建 IP/TCP 头与校验和,
  自己维护状态机(`snd_nxt`/`rcv_nxt`/三态)。
- 内核侧(服务端)在 **ns2** 里用普通 `socket()`,什么都不用改。
- **固定 MAC**(`02..:01`/`02..:02`)+ **ns2 静态 neigh**(`10.0.0.1→02..:01`)
  → 两端都不需要 ARP,这是把栈做到"最简"的关键取舍。

## raw 的收/发路径(它为什么成立)

```
入向: 帧到 veth1 → ptype_all(packet socket tap 抄一份)→ ip_rcv ...
       tap 在 L3 之前,raw 必收到;内核之后去哪是那份"持续走的副本"的事。
出向: 应用(帧已拼好)→ packet_snd → dev_queue_xmit ─直接进二层,完全绕过 L3/L4。
```
- **收包** = tap 抄副本,与否进协议栈无关。所以`veth1`不配 IP 时,帧在 L3 被弃,
  raw 依然收到;但若`10.0.0.1`恰是本机地址,内核会把 SYN 当本地包回 **RST** 抢答,
  这就是"IP 只活在帧里"的原因。
- **发包** = 从二层冒充,内核既不算校验和也不查路由。所以**校验和必须自己算**。

## 文件

| 文件 | 作用 |
|------|------|
| `client.c` | 自制极简 TCP 栈(握手/数据/挥手,含 IP+TCP 校验和),约 250 行 |
| `server.py` | 内核侧常规 socket 服务端,收下后回 `PONG` 并关闭 |
| `run_test.sh` | 一键:编译 → 共享 setup → 起 server(ns2) → 跑 client(ns1) → 清理 |
| (共享) `../..` | 根目录的 `setup.sh`/`teardown.sh` 提供拓扑 |

## 用法

```bash
sudo bash run_test.sh            # 一键(默认不抓包)
sudo bash run_test.sh --capture  # 后台抓 30s pcap
```

或手动:

```bash
gcc -O2 -Wall -o client client.c
sudo bash ../../setup.sh
# 终端A: sudo ip netns exec ns2 python3 server.py
# 终端B: sudo ip netns exec ns1 ./client
# 结束:   sudo bash ../../teardown.sh
```

预期客户端输出(带分步 log):

```
[stack] 源端口 2xxxx, 尝试连接 10.0.0.2:8080 (src MAC 02..01)
===== [STEP] 初始化完成,已绑定 veth1,开始三次握手 =====
[FLOW] 我方初始序号 ISN=...
[TX] SYN     seq=.....        ack=0           len=0   frame=54B
[RX] SYN+ACK seq=.....        ack=.....       len=0   (来自 SYN段)
===== [STEP] 收到 SYN+ACK,握手第一步完成,发出 ACK+PING 完成握手 =====
[TX] ACK+PSH seq=.....        ack=.....       len=4   frame=58B
[stack] 握手完成,连接已建立 (state 0 -> 1)
===== [STEP] 收到对端数据,打印并回复 ACK =====
[DATA] PONG
===== [STEP] 收到对端 FIN,已发出我方 FIN,进入关闭等待 =====
[TX] ACK+FIN seq=.....        ack=.....       len=0   frame=54B
===== [STEP] 收到对端对我方 FIN 的确认,连接干净关闭 =====
[stack] 连接干净关闭
[stack] 结束:收到载荷 4 字节 (PONG ✓)
```

log 含义:`[TX]/[RX]` 收发帧(标志位+seq/ack+长度);`[STEP]` 流程推进到哪一步;
`[FLOW]` 关键序号;`[RTX]+[STEP]…重传` 1 秒没响应时重发最近一帧。

## 这个 TCP 栈怎么做到"尽量简单"

1. **不实现 ARP** —— 固定 MAC + 静态 neigh,见上。
2. **IP 不配给内核** —— `veth1` 只有 MAC 没 IP,`10.0.0.1` 只活在用户态帧里,
   否则内核把 SYN 当本地包回 RST,和自己的栈抢答。
3. **无选项段** —— TCP 头固定 20 字节,不做 MSS/时间戳/窗口缩放协商。
4. **可靠 veth 乐观假设** —— 只接受 `seq==rcv_nxt`,不做乱序/窗口/拥塞控制,
   丢包靠"重传最近一帧"兜底。
5. **关闭方向** —— 对端 `sendall(PONG)` 后 `close()` 触发对端 FIN,形成真实
   两段式 FIN 交换。

## 排障

校验和字节序是头号坑(见根目录 README「关键排障」):全部写进头部的校验和都要
包 `htons()`,内核弃帧是静默的,tcpdump 看不出来。