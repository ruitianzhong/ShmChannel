#!/bin/bash
# 一键: 搭环境 -> 起内核服务端 -> 跑自定义栈客户端 -> 清理
# 需 root: sudo -E bash run_test.sh
set -e
cd "$(dirname "$0")"
ROOT="$(cd ../.. && pwd)"   # 仓库根(从 examples/tcp 上两级),共享 setup.sh 在那

echo "=== 编译客户端 ==="
gcc -O2 -Wall -o client client.c

echo "=== 搭环境(共享拓扑) ==="
sudo bash "$ROOT/setup.sh" "$@"   # 透传 --capture 等参数给 setup.sh

echo "=== 启动内核服务端(ns2) ==="
sudo ip netns exec ns2 python3 server.py & SRV=$!
trap 'kill $SRV 2>/dev/null || true' EXIT
sleep 0.8

echo "=== 运行自定义 TCP 栈客户端(ns1) ==="
sudo ip netns exec ns1 ./client
RV=$?

echo "服务端 PID SRV=$SRV"     # $SRV 常是 sudo/ip 层 PID,非真实服务进程
# 直接按命令名 kill -9 真实服务进程($SRV 那层 sudo 不一定转发信号)
pkill -9 -f server.py 2>/dev/null || true
wait $SRV 2>/dev/null || true
echo "=== client 退出码: $RV ==="
exit $RV