/*
 * client.c —— 极简自定义 TCP 栈(位于 netns ns1)
 *
 * 用 AF_PACKET, SOCK_RAW 在 veth1 上注入/读取整条 Ethernet+IPv4+TCP 帧，
 * 与 ns2 里运行在 veth2(10.0.0.2) 上的内核常规 socket 走完整 TCP：
 *   三次握手 -> 发送 PING -> 收 PONG -> 四次挥手
 *
 * 设计要点(为“最简”)：
 *  1) MAC 固定为 02:00:00:00:00:01(veth1)，对端固定 02:00:00:00:00:02(veth2)，
 *     由 setup.sh 设定，因此本栈完全不需要实现 ARP。
 *     -> 把本栈的外表 IP(10.0.0.1)到 veth1 MAC 的映射，通过 setup.sh 里的
 *        静态 neigh 告诉 ns2 内核，反向回包也不用 ARP。
 *  2) 校验和均为标准的互联网校验和(按大端 16 位字累加 + 反码)。
 *
 * 编译:  gcc -O2 -Wall -o client client.c
 * 运行:  sudo ip netns exec ns1 ./client      (需 root: CAP_NET_RAW)
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>

#define IFNAME   "veth1"
static const unsigned char OUR_MAC[6]  = {0x02,0x00,0x00,0x00,0x00,0x01}; /* veth1 */
static const unsigned char PEER_MAC[6] = {0x02,0x00,0x00,0x00,0x00,0x02}; /* veth2 */

#define SRC_IPN  htonl(0x0A000001UL)   /* 10.0.0.1, 仅活在自定义栈里 */
#define DST_IPN  htonl(0x0A000002UL)   /* 10.0.0.2, ns2 内核对端 */
#define DST_PORT 8080

static uint16_t SRC_PORT;              /* 每次运行随机 */

/* TCP 标志位 */
enum { F_FIN=0x01, F_SYN=0x02, F_RST=0x04, F_PSH=0x08, F_ACK=0x10 };

#pragma pack(push,1)
struct ethh0 { uint8_t  d[6], s[6]; uint16_t proto; };
struct iph0  { uint8_t  vihl, tos; uint16_t totlen, id, frag;
               uint8_t  ttl, proto; uint16_t check; uint32_t saddr, daddr; };
struct tcph0 { uint16_t sport, dport; uint32_t seq, ack;
               uint8_t  off, flags; uint16_t win, check, urg; };
#pragma pack(pop)

static int fd;            /* raw socket */
static int ifidx;
static uint16_t ip_id = 0;

static uint8_t  last[1600];   /* 最近一次发送的整帧,用于超时重传 */
static ssize_t  last_len = 0;

/* ---- 日志辅助:把标志位按位解析成可读字符串,如 "SYN+ACK" ---- */
static void flags_str(int f, char *out){
    static const int    bits[5] = { F_FIN, F_SYN, F_RST, F_PSH, F_ACK };
    static const char *names[5] = { "FIN", "SYN", "RST", "PSH", "ACK" };
    out[0] = 0;
    for (int i = 0; i < 5; i++)
        if (f & bits[i]){ if (out[0]) strcat(out, "+"); strcat(out, names[i]); }
    if (!out[0]) strcpy(out, "(none)");
}
static void ipstr(uint32_t ip, char *out){
    uint8_t *b = (uint8_t *)&ip;
    sprintf(out, "%u.%u.%u.%u", b[0], b[1], b[2], b[3]);
}

/* ---- 诊断:每收到一帧(无论是否属于本连接)都打印一行 ---- */
static void dump_frame(const uint8_t *buf, int len){
    if (len < 14){ printf("[FRAME] len=%d 过短\n", len); return; }
    const struct ethh0 *e = (const struct ethh0 *)buf;
    printf("[FRAME] len=%-4d eth=0x%04x dst=%02x:%02x:%02x:%02x:%02x:%02x\n",
           len, ntohs(e->proto),
           e->d[0],e->d[1],e->d[2],e->d[3],e->d[4],e->d[5]);
    if (ntohs(e->proto) == ETH_P_IP && len >= 14+20){
        const struct iph0 *ip = (const struct iph0 *)(buf+14);
        char sa[20], da[20]; ipstr(ip->saddr, sa); ipstr(ip->daddr, da);
        printf("      IP %s -> %s proto=%d", sa, da, ip->proto);
        if (ip->proto == 6 && len >= 14+20+20){
            const struct tcph0 *t = (const struct tcph0 *)(buf+14+20);
            char fstr[32]; flags_str(t->flags, fstr);
            printf("  TCP :%d -> :%d %s", ntohs(t->sport), ntohs(t->dport), fstr);
        }
        printf("\n");
    }
    fflush(stdout);
}

/* 步骤横幅,标明流程推进到哪一步 */
static void step(const char *fmt, ...){
    va_list ap;
    printf("\n===== [STEP] ");
    va_start(ap, fmt); vprintf(fmt, ap); va_end(ap);
    printf(" =====\n"); fflush(stdout);
}

/* ---- 互联网校验和(把内存里大端序列当作 16 位字累加,反码) ---- */
static void csum_add(uint32_t *acc, const uint8_t *d, int n){
    int i = 0;
    while (i + 1 < n){ *acc += (((uint16_t)d[i]) << 8) | d[i+1]; i += 2; }
    if (i < n) *acc += ((uint16_t)d[i]) << 8;
}
static uint16_t csum_fin(uint32_t s){
    while (s >> 16) s = (s & 0xffff) + (s >> 16);
    return (uint16_t)~s;
}
static uint16_t ip_checksum(const uint8_t *d, int n){
    uint32_t s = 0; csum_add(&s, d, n); return csum_fin(s);
}
static uint16_t tcp_checksum(const uint8_t *tcp, int tlen,
                             uint32_t sna, uint32_t dna){
    uint32_t s = 0;
    csum_add(&s, (const uint8_t*)&sna, 4);          /* 伪首部:源IP */
    csum_add(&s, (const uint8_t*)&dna, 4);          /*       目的IP */
    uint8_t ph[4] = { 0, 6, 0, 0 };                 /* 保留0 + proto6 + 长度(大端) */
    ph[2] = (uint8_t)(tlen >> 8); ph[3] = (uint8_t)(tlen & 0xff);
    csum_add(&s, ph, 4);
    csum_add(&s, tcp, tlen);                        /* TCP头 + 载荷 */
    return csum_fin(s);
}

/* ---- 组装并发送一个 TCP 帧(Ethernet+IPv4+TCP),并缓存用于重传 ---- */
static void send_tcp(uint32_t seq, uint32_t ack, int flags,
                     const void *data, int dlen){
    int tlen = 20 + dlen, iplen = 20 + tlen, flen = 14 + iplen;
    if (flen > (int)sizeof(last)) { fprintf(stderr,"frame too big\n"); exit(1); }
    uint8_t b[1600]; memset(b, 0, sizeof b);
    struct ethh0 *e = (struct ethh0 *)b;
    struct iph0  *i = (struct iph0 *)(b + 14);
    struct tcph0 *t = (struct tcph0 *)(b + 34);

    memcpy(e->d, PEER_MAC, 6); memcpy(e->s, OUR_MAC, 6);
    e->proto = htons(ETH_P_IP);

    i->vihl   = 0x45;
    i->totlen = htons(iplen);
    i->id     = htons(++ip_id);
    i->frag   = htons(0x4000);            /* 不分片 */
    i->ttl    = 64;
    i->proto  = 6;
    i->saddr  = SRC_IPN;
    i->daddr  = DST_IPN;
    i->check  = htons(ip_checksum(b + 14, 20));   /* 基和须为网络序 */

    t->sport = htons(SRC_PORT); t->dport = htons(DST_PORT);
    t->seq   = htonl(seq);     t->ack   = htonl(ack);
    t->off   = (5 << 4);       /* 无选项 */
    t->flags = flags;
    t->win   = htons(64240);
    if (dlen) memcpy(b + 54, data, dlen);
    t->check = htons(tcp_checksum(b + 34, tlen, SRC_IPN, DST_IPN));

    struct sockaddr_ll so;
    memset(&so, 0, sizeof so);
    so.sll_family  = AF_PACKET;
    so.sll_ifindex = ifidx;
    so.sll_halen   = 6;
    memcpy(so.sll_addr, PEER_MAC, 6);
    if (sendto(fd, b, flen, 0, (struct sockaddr *)&so, sizeof so) < 0)
        perror("sendto");

    memcpy(last, b, flen); last_len = flen;

    char fstr[32]; flags_str(flags, fstr);
    printf("[TX] %-6s seq=%-10u ack=%-10u len=%-3d frame=%dB\n",
           fstr, seq, ack, dlen, flen);
    fflush(stdout);
}

static void resend_last(void){
    struct sockaddr_ll so;
    memset(&so, 0, sizeof so);
    so.sll_family  = AF_PACKET;
    so.sll_ifindex = ifidx;
    so.sll_halen   = 6;
    memcpy(so.sll_addr, PEER_MAC, 6);
    if (last_len){
        printf("[RTX] 重传最近一帧 (%dB)\n", (int)last_len); fflush(stdout);
        sendto(fd, last, last_len, 0, (struct sockaddr *)&so, sizeof so);
    }
}

/* ---- 解析收到的帧;若不是发给本栈的 TCP 段返回非 0 ---- */
static int recv_tcp_segment(uint8_t *seg, int len, uint32_t *seq, uint32_t *ack,
                            int *flags, uint8_t **data, int *dlen){
    if (len < 14 + 20) return -1;
    struct ethh0 *e = (struct ethh0 *)seg;
    if (ntohs(e->proto) != ETH_P_IP) return -1;
    struct iph0 *ip = (struct iph0 *)(seg + 14);
    if ((ip->vihl & 0xf0) != 0x40 || ip->proto != 6) return -1;
    int iplen = ntohs(ip->totlen);
    if (iplen < 20) return -1;
    struct tcph0 *t = (struct tcph0 *)(seg + 14 + 20);
    if (ip->saddr != DST_IPN || ip->daddr != SRC_IPN) return -1;
    if (ntohs(t->sport) != DST_PORT || ntohs(t->dport) != SRC_PORT) return -1;
    int off = (t->off >> 4) * 4;
    if (off < 20) return -1;
    *seq = ntohl(t->seq); *ack = ntohl(t->ack); *flags = t->flags;
    *data = seg + 14 + 20 + off; *dlen = iplen - 20 - off;
    if (*dlen < 0) return -1;
    return 0;
}

int main(void){
    srand((unsigned)time(0) ^ (unsigned)getpid());
    SRC_PORT = 20000 + (uint16_t)(rand() % 30000);

    ifidx = if_nametoindex(IFNAME);
    if (!ifidx){ fprintf(stderr, "找不到接口 %s (先跑 setup.sh)\n", IFNAME); return 1; }

    fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (fd < 0){ perror("socket(AF_PACKET)"); return 1; }
    struct sockaddr_ll ba;
    memset(&ba, 0, sizeof ba);
    ba.sll_family  = AF_PACKET;
    ba.sll_protocol = htons(ETH_P_ALL);
    ba.sll_ifindex = ifidx;
    if (bind(fd, (struct sockaddr *)&ba, sizeof ba) < 0){ perror("bind"); return 1; }

    /* --- 有限状态机:0=等SYN-ACK, 1=已建立, 2=等对端确认我们的FIN --- */
    int state = 0, retry = 0;

    uint32_t isn     = 0x12340000u + (uint32_t)rand();
    uint32_t snd_nxt = isn + 1;      /* 下一个要发给对端的序列号 */
    uint32_t rcv_nxt = 0;            /* 期待从对端收到的下一个序列号 */
    int rx_data = 0;                 /* 统计收到的载荷字节 */

    printf("[stack] 源端口 %u, 尝试连接 %s:%d (src MAC 02..01)\n",
           SRC_PORT, "10.0.0.2", DST_PORT);

    step("初始化完成,已绑定 veth1,开始三次握手");
    printf("[FLOW] 我方初始序号 ISN=%u\n", isn);
    send_tcp(isn, 0, F_SYN, NULL, 0);          /* step1: SYN */

    for (;;){
        fd_set rf; FD_ZERO(&rf); FD_SET(fd, &rf);
        struct timeval tv = { 1, 0 };
        int n = select(fd + 1, &rf, NULL, NULL, &tv);
        if (n < 0){ perror("select"); break; }

        if (n == 0){                                 /* 超时:重传最近一帧 */
            if (++retry > 12){ fprintf(stderr, "[stack] 重传超时,放弃\n"); break; }
            step("1秒无响应,重传最近一帧(第 %d 次)", retry);
            resend_last();
            continue;
        }

        uint8_t buf[2048];
        struct sockaddr_ll from; socklen_t fl = sizeof from;
        ssize_t rl = recvfrom(fd, buf, sizeof buf, 0,
                              (struct sockaddr *)&from, &fl);
        if (rl <= 0) continue;

        /* 诊断:先打印收到的每一帧,再决定是否属于本连接 */
        dump_frame(buf, (int)rl);

        uint32_t seq, ack; int flags; uint8_t *data; int dlen;
        if (recv_tcp_segment(buf, (int)rl, &seq, &ack, &flags, &data, &dlen))
            continue;   /* 不是发给本连接的有效 TCP 段,忽略 */

        /* 每次收到本连接的 TCP 段都打一行日志 */
        {
            char fstr[32]; flags_str(flags, fstr);
            printf("[RX] %-6s seq=%-10u ack=%-10u len=%-3d (来自 %s)\n",
                   fstr, seq, ack, dlen, dlen > 0 ? "数据段" :
                   (flags & F_SYN) ? "SYN段" :
                   (flags & F_FIN) ? "FIN段  " : "纯ACK/控制段");
            fflush(stdout);
        }

        if (state == 0){
            /* step2: 收到 SYN+ACK,校验其 ack 是否确认我们的 SYN */
            if ((flags & (F_SYN|F_ACK)) == (F_SYN|F_ACK) && ack == snd_nxt){
                rcv_nxt = seq + 1;
                step("收到 SYN+ACK,握手第一步完成,发出 ACK+PING 完成握手");
                printf("[FLOW] 对端初始序号=%u, 我方下一序号=%u\n", seq, snd_nxt);
                /* step3: ACK 完成握手,并捎带发送 PING */
                send_tcp(snd_nxt, rcv_nxt, F_ACK|F_PSH, "PING", 4);
                snd_nxt += 4;
                state = 1; retry = 0;
                printf("[stack] 握手完成,连接已建立 (state 0 -> 1)\n");
            }
        } else if (state == 1){
            /* 已建立:只接受 seq 正好等于 rcv_nxt 的段(可靠 veth,不做乱序) */
            if (seq == rcv_nxt){
                int consumed = 0;
                if (dlen > 0){
                    step("收到对端数据,打印并回复 ACK");
                    printf("[DATA] "); fwrite(data, 1, dlen, stdout);
                    printf("\n"); fflush(stdout);
                    rcv_nxt += dlen; rx_data += dlen; consumed = 1;
                }
                if (flags & F_FIN){ rcv_nxt += 1; consumed = 1; }

                if (consumed){
                    int f = F_ACK | ((flags & F_FIN) ? F_FIN : 0);
                    send_tcp(snd_nxt, rcv_nxt, f, NULL, 0);
                    if (flags & F_FIN){
                        snd_nxt += 1;    /* 我们自己的 FIN 也要占一个序号 */
                        state = 2; retry = 0;
                        step("收到对端 FIN,已发出我方 FIN,进入关闭等待 (state 1 -> 2)");
                    }
                }
            } else {
                printf("[WARN] 收到乱序段 seq=%u (期待 %u),忽略\n", seq, rcv_nxt);
                fflush(stdout);
            }
        } else if (state == 2){
            /* 等对端确认我们的 FIN: ack == snd_nxt */
            if ((flags & F_ACK) && ack == snd_nxt){
                step("收到对端对我方 FIN 的确认,连接干净关闭");
                printf("\n[stack] 连接干净关闭\n");
                break;
            }
        }
    }

    close(fd);
    printf("[stack] 结束:收到载荷 %d 字节 (%s)\n",
           rx_data, (state == 2 && rx_data == 4) ? "PONG ✓" : "结果异常");
    return 0;
}