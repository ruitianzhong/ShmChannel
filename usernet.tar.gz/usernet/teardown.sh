#!/bin/bash
# 清理:删除命名空间即删除其内的 veth
set -e
ip netns del ns1 2>/dev/null || true
ip netns del ns2 2>/dev/null || true
ip link del veth1 2>/dev/null || true
echo "已清理"