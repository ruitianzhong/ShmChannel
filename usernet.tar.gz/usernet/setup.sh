#!/bin/bash
# 搭建 veth 对测环境
#   ns1  <- 自定义 TCP 栈(raw packet),  veth1 只有 MAC 不外显 IP
#   ns2  <- 内核常规 socket,            veth2 = 10.0.0.2/24
# 需 root 运行:  sudo -E bash setup.sh
# 抓包为可选:默认不抓;传 --capture(或 -c)才后台抓 30s pcap
set -e
CAPTURE=0
case "$1" in
  --capture|-c) CAPTURE=1;;
esac

# 清理可能残留(容错)
ip netns del ns1 2>/dev/null || true
ip netns del ns2 2>/dev/null || true
ip link del veth1 2>/dev/null || true

ip netns add ns1
ip netns add ns2
ip link add veth1 type veth peer name veth2

ip link set veth1 netns ns1
ip link set veth2 netns ns2

# 固定 MAC —— 这是“不实现 ARP 也能通信”的关键
ip -n ns1 link set veth1 address 02:00:00:00:00:01
ip -n ns2 link set veth2 address 02:00:00:00:00:02

ip -n ns1 link set lo up
ip -n ns2 link set lo up
ip -n ns1 link set veth1 up
ip -n ns2 link set veth2 up

# 关闭两侧 IPv6,减少 ND/MLD 噪音,让抓包与客户端日志只剩相关的帧
ip netns exec ns1 sysctl -q net.ipv6.conf.veth1.disable_ipv6=1
ip netns exec ns2 sysctl -q net.ipv6.conf.veth2.disable_ipv6=1

# 只有内核侧(Ns2)分配 IP;自定义栈的 10.0.0.1 只活在用户态逻辑里
ip -n ns2 addr add 10.0.0.2/24 dev veth2

# 告诉 ns2 内核:发给 10.0.0.1 的包直接走 veth2 到 veth1 的 MAC,永久免 ARP
ip -n ns2 neigh add 10.0.0.1 dev veth2 lladdr 02:00:00:00:00:01 nud permanent

echo "== 环境就绪 =="
echo "  ns1: veth1  10.0.0.1(虚拟)  02:00:00:00:00:01  <- 自定义TCP栈"
echo "  ns2: veth2  10.0.0.2/24     02:00:00:00:00:02  <- 内核socket"

# === 后台自动抓包 30 秒 === 默认关闭,传 --capture 才开
if [ "$CAPTURE" = "1" ]; then
    if command -v tcpdump >/dev/null 2>&1; then
        TS=$(date +%s)
        echo ">> 后台抓包已启动(30s): veth1_$TS.pcap / veth2_$TS.pcap"
        # </dev/null >/dev/null : 与终端断stdio,完全脱离,防卡住/prompt 迟 30s
        timeout 30 ip netns exec ns1 tcpdump -i veth1 -nne -w veth1_$TS.pcap \
            </dev/null >/dev/null 2>veth1_$TS.err &
        T1=$!
        timeout 30 ip netns exec ns2 tcpdump -i veth2 -nne -w veth2_$TS.pcap \
            </dev/null >/dev/null 2>veth2_$TS.err &
        T2=$!
        echo ">> 抓包后台 PID: veth1=$T1  veth2=$T2 (30s 后自动结束)"
        echo ">> 中途想停:  kill $T1 $T2"
    else
        echo ">> 未找到 tcpdump,跳过自动抓包"
    fi
else
    echo ">> 本次不抓包(需要抓包请加 --capture)"
fi